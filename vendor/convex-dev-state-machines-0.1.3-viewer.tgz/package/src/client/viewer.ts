// The viewer's functions: what a page that draws an app's machines reads, and
// (when the app turns it on) an operator's send. Everything is read off the
// catalog: the manifests the runtime runs, the schema's validators and
// indexes, and each row through `survey`, so the page can't drift from the
// rules. `defineMachines` makes them (`machines.viewer(checks)`), and the app
// wraps each in a function of its own:
//
//   overview(ctx)                         the manifests, and how the tables relate (projects → versions)
//   counts(ctx, { machine })              how many rows are in each state
//   rows(ctx, { table, machine?, kind? }) a page of a table's rows, newest first, optionally in one state
//   row(ctx, { table, id })               one row: its doc, each machine's survey and history, its parent and children
//   send(ctx, { machine, id, event })     an operator's send: a role's or the server's event, past the role's check
//   create(ctx, { machine, fields, event })  an operator's create, by a role's or the server's start event
//
// They don't need the internal brand, as a page calls public functions.
// Instead every one runs the app's `read` check first, and answers null when
// it says no. `send` and `create` also need the app's `send` check, and
// without one they always refuse.
import type { Auth, GenericDatabaseReader, GenericDatabaseWriter, GenericDataModel, GenericMutationCtx, GenericQueryCtx, PaginationResult } from "convex/server";
import { ConvexError, v, type GenericId, type Value } from "convex/values";
import type { CreateResult, HistoryEntry, Manifest, SendResult, Survey, SurveyOptions } from "./machine.js";

type Loose = Record<string, unknown>;
type Db = GenericDatabaseWriter<GenericDataModel>;
type AnyValidator = { kind: string; isOptional: "required" | "optional"; fields?: Record<string, AnyValidator>; members?: AnyValidator[]; value?: unknown; tableName?: string };
type ReadCtx = { auth: Auth; db: object; runQuery: GenericQueryCtx<GenericDataModel>["runQuery"] };
type WriteCtx = Omit<GenericMutationCtx<GenericDataModel>, "db"> & { db: object };
type Event = { type: string } & Loose;

/** Who may use the viewer. Each check gets what a guard gets: reads, and who's asking. */
export type ViewerChecks<DM extends GenericDataModel = GenericDataModel> = {
  /** Runs before every one of the viewer's functions. False: it answers null. */
  read: (ctx: { db: GenericDatabaseReader<DM>; auth: Auth }) => boolean | Promise<boolean>;
  /** Who may send and create as an operator, past the roles' checks. Left out, nobody can. */
  send?: (ctx: { db: GenericDatabaseReader<DM>; auth: Auth }) => boolean | Promise<boolean>;
};

/** The args of the app's functions that wrap the viewer's. An event and a new row's fields are checked by the machine. */
export const viewerArgs = {
  overview: {},
  counts: { machine: v.string(), limit: v.optional(v.number()) },
  rows: { table: v.string(), machine: v.optional(v.string()), kind: v.optional(v.string()), limit: v.optional(v.number()) },
  row: { table: v.string(), id: v.string() },
  send: { machine: v.string(), id: v.string(), event: v.any() },
  create: { machine: v.string(), fields: v.any(), event: v.any() },
};

/** A field as a form would ask for it: `table` for an ID's, `options` for a union of literals. Anything else is "json". */
export type ViewerField = { name: string; type: "string" | "number" | "boolean" | "id" | "choice" | "json"; optional: boolean; table?: string; options?: string[] };
export type ViewerTable = {
  table: string;
  machines: string[];
  /** The table its rows belong to: one a machine there `creates` them from, or the first machine table one of its ID fields names. `field`: that ID field, if it has one. */
  parent: { table: string; field: string | null } | null;
  /** Its own fields, not the machines'. */
  fields: ViewerField[];
};
export type ViewerOverview = {
  /** Whether this caller may send and create as an operator. */
  send: boolean;
  machines: Manifest[];
  tables: ViewerTable[];
  /** By machine: whether an index begins with its `<field>.kind`, each event's payload, and the tables its states' ID fields name. */
  details: Record<string, { indexed: boolean; payloads: Record<string, ViewerField[]>; ids: Record<string, Record<string, string>> }>;
};
/** `capped`: some count stopped at `limit`. With an index on `<field>.kind` the limit is per state; without, it's how many rows were scanned, newest first. */
export type ViewerCounts = { counts: Record<string, number>; capped: boolean; limit: number; indexed: boolean };
/** A row in a list: its plain fields, and each machine's state, pending timers and when it entered the state (from history, if it's recent). */
export type ViewerRowSummary = {
  table: string;
  id: string;
  createdAt: number;
  fields: Record<string, Value>;
  states: Record<string, { kind: string; timers: { event: string; dueAt: number }[]; since?: number }>;
};
/** `more`: there are more rows than it returned. `capped`: without an index it stopped scanning, so rows may be missing. */
export type ViewerRows = { rows: ViewerRowSummary[]; more: boolean; capped: boolean };
export type ViewerRow = {
  summary: ViewerRowSummary;
  doc: Loose;
  /** `survey` is null with a `problem` when the row's stored state isn't one the machine knows. History is newest first. */
  machines: { machine: string; survey: Survey | null; problem?: string; history: HistoryEntry[]; historyMore: boolean }[];
  parent: ViewerRowSummary | null;
  children: ({ table: string; field: string } & ViewerRows)[];
};

/** What `defineMachines` hands over: each machine's runtime, narrowed to what the viewer uses. */
export type ViewerRun = {
  name: string;
  table: string;
  field: string;
  timers?: string;
  manifest: Manifest;
  events: Record<string, Record<string, Record<string, AnyValidator>>>;
  survey(ctx: ReadCtx, id: string, options?: SurveyOptions): Promise<Survey | null>;
  history(ctx: ReadCtx, id: string, numItems: number): Promise<PaginationResult<HistoryEntry>>;
  send(ctx: WriteCtx, id: string, event: Event): Promise<SendResult>;
  create(ctx: WriteCtx, fields: Loose, event: Event): Promise<CreateResult>;
};
type Index = { indexDescriptor: string; fields: string[] };
export type ViewerDeps = {
  tables: Record<string, { validator: AnyValidator; indexes: Index[] }>;
  /** Each table's fields that only the library writes. */
  owned: Map<string, string[]>;
  runs: ViewerRun[];
  raw(ctx: { db: unknown }): Db;
};

const ROWS = 25; // a page of rows
const MAX_ROWS = 200;
const CHILDREN = 20; // a row's children, newest first
const PER_STATE = 500; // counted per state, with an index
const SCAN = 2000; // rows read without one
const HISTORY = 50;
const TEXT = 200; // a string field in a list is cut here
const clamp = (value: number | undefined, fallback: number, max: number) => Math.max(1, Math.min(max, Math.floor(value ?? fallback) || fallback));
const refuse = (code: string, message: string): never => {
  throw new ConvexError({ code, message });
};

function describe(name: string, validator: AnyValidator): ViewerField {
  const optional = validator.isOptional === "optional";
  const literals = validator.kind === "union" ? (validator.members ?? []) : validator.kind === "literal" ? [validator] : [];
  if (literals.length && literals.every((member) => member.kind === "literal" && typeof member.value === "string"))
    return { name, type: "choice", optional, options: literals.map((member) => member.value as string) };
  if (validator.kind === "id") return { name, type: "id", optional, table: validator.tableName };
  const type = validator.kind === "string" ? "string" : validator.kind === "float64" ? "number" : validator.kind === "boolean" ? "boolean" : "json";
  return { name, type, optional };
}

export function makeViewer<DM extends GenericDataModel>({ tables, owned, runs, raw }: ViewerDeps, checks: ViewerChecks<DM>) {
  const byName = new Map(runs.map((run) => [run.name, run]));
  const machineTables = [...new Set(runs.map((run) => run.table))];
  const runsOn = (table: string) => runs.filter((run) => run.table === table);
  const runOf = (machine: string) => byName.get(machine) ?? refuse("NOT_FOUND", `No machine "${machine}" in the catalog.`);
  const fieldsOf = (table: string) => Object.entries(tables[table]?.validator.fields ?? {});
  const indexOn = (table: string, first: string) => tables[table].indexes.find((index) => index.fields[0] === first)?.indexDescriptor;

  // A table's parent: where a `creates` and an ID field agree, that. Else what creates it, else its first ID field that names a machine's table.
  const infos: ViewerTable[] = machineTables.map((table) => {
    const creators = new Set(
      runs.filter((run) => run.table !== table && run.manifest.transitions.some((item) => item.creates.some((rule) => byName.get(rule.machine)?.table === table))).map((run) => run.table),
    );
    const refs = fieldsOf(table).flatMap(([field, validator]) =>
      validator.kind === "id" && validator.tableName !== table && machineTables.includes(validator.tableName!) ? [{ table: validator.tableName!, field }] : [],
    );
    const made = [...creators][0];
    const parent = refs.find((ref) => creators.has(ref.table)) ?? (made ? { table: made, field: null } : (refs[0] ?? null));
    const own = fieldsOf(table).filter(([field]) => !owned.get(table)?.includes(field));
    return { table, machines: runsOn(table).map((run) => run.name), parent, fields: own.map(([field, validator]) => describe(field, validator)) };
  });
  const infoOf = (table: string) => infos.find((info) => info.table === table) ?? refuse("NOT_FOUND", `No machine is on "${table}".`);
  const details = Object.fromEntries(
    runs.map((run) => {
      const members = tables[run.table].validator.fields![run.field].members ?? [];
      const ids = members.map((member) => [
        member.fields!.kind.value as string,
        Object.fromEntries(Object.entries(member.fields!).flatMap(([field, validator]) => (validator.kind === "id" ? [[field, validator.tableName!]] : []))),
      ]);
      const payloads = Object.values(run.events).flatMap((events) => Object.entries(events).map(([type, payload]) => [type, Object.entries(payload).map(([field, validator]) => describe(field, validator))]));
      return [run.name, { indexed: !!indexOn(run.table, `${run.field}.kind`), payloads: Object.fromEntries(payloads), ids: Object.fromEntries(ids) }];
    }),
  ) as ViewerOverview["details"];
  // The tables a page may list: the machines', and the ones their ID fields name, on the row (a new row's
  // form picks from them) or in a state's data (a decision's "decided by", shown by name).
  const listable = new Set([
    ...machineTables,
    ...infos.flatMap((info) => info.fields.flatMap((field) => (field.type === "id" && field.table ? [field.table] : []))),
    ...Object.values(details).flatMap((detail) => Object.values(detail.ids).flatMap((fields) => Object.values(fields).filter((table) => !table.startsWith("_")))),
  ]);

  const guardCtx = (ctx: { db: object; auth: Auth }) => ({ db: raw(ctx) as unknown as GenericDatabaseReader<DM>, auth: ctx.auth });
  const reads = async (ctx: ReadCtx) => !!(await checks.read(guardCtx(ctx)));
  const sends = async (ctx: ReadCtx) => !!checks.send && (await reads(ctx)) && !!(await checks.send(guardCtx(ctx)));
  // The operator's functions throw when they're off: a page that offers them was told it could.
  async function operator(ctx: WriteCtx, what: string) {
    if (!(await sends(ctx))) refuse("VIEWER_SEND_OFF", `${what} from the viewer is off: the app's viewer passes no \`send\` check, or it said no.`);
  }

  // A row's plain fields: what a list shows, and a page picks a name from. Not the machines' fields, and nothing nested.
  function plain(table: string, doc: Loose) {
    const fields: Record<string, Value> = {};
    for (const [field, value] of Object.entries(doc)) {
      if (field.startsWith("_") || owned.get(table)?.includes(field)) continue;
      if (typeof value === "string") fields[field] = value.length > TEXT ? `${value.slice(0, TEXT)}…` : value;
      else if (typeof value === "number" || typeof value === "boolean" || value === null) fields[field] = value;
    }
    return fields;
  }
  // When the row entered its state: its newest step that moved it, if that's among its last few facts.
  async function since(ctx: ReadCtx, run: ViewerRun, id: string, kind: string) {
    const { page } = await run.history(ctx, id, 8);
    const moved = page.find((fact) => fact.kind === "step" && fact.from !== fact.to);
    return moved?.to === kind ? moved.at : undefined;
  }
  async function summary(ctx: ReadCtx, table: string, doc: Loose): Promise<ViewerRowSummary> {
    const states: ViewerRowSummary["states"] = {};
    for (const run of runsOn(table)) {
      const kind = String((doc[run.field] as Loose | undefined)?.kind);
      const timers = ((run.timers && (doc[run.timers] as { event: string; dueAt: number }[])) || []).map(({ event, dueAt }) => ({ event, dueAt }));
      const at = await since(ctx, run, doc._id as string, kind);
      states[run.name] = { kind, timers, ...(at === undefined ? {} : { since: at }) };
    }
    return { table, id: doc._id as string, createdAt: doc._creationTime as number, fields: plain(table, doc), states };
  }
  // Rows of `table` where `field` is `value`, newest first: through an index that begins with the field, or else a bounded scan.
  async function where(ctx: ReadCtx, table: string, field: string, value: Value, take: number): Promise<ViewerRows> {
    const db = raw(ctx);
    const index = indexOn(table, field);
    const docs: Loose[] = [];
    let capped = false;
    if (index) docs.push(...((await db.query(table).withIndex(index, (q) => q.eq(field, value as never)).order("desc").take(take + 1)) as Loose[]));
    else {
      let scanned = 0;
      const path = field.split(".");
      for await (const doc of db.query(table).order("desc")) {
        if (scanned++ >= SCAN) {
          capped = true;
          break;
        }
        if (path.reduce<unknown>((at, key) => (at as Loose | undefined)?.[key], doc) === value) docs.push(doc);
        if (docs.length > take) break;
      }
    }
    const rows = [];
    for (const doc of docs.slice(0, take)) rows.push(await summary(ctx, table, doc));
    return { rows, more: docs.length > take, capped };
  }

  return {
    async overview(ctx: ReadCtx): Promise<ViewerOverview | null> {
      if (!(await reads(ctx))) return null;
      return { send: await sends(ctx), machines: runs.map((run) => run.manifest), tables: infos, details };
    },

    async counts(ctx: ReadCtx, args: { machine: string; limit?: number }): Promise<ViewerCounts | null> {
      if (!(await reads(ctx))) return null;
      const run = runOf(args.machine);
      const db = raw(ctx);
      const path = `${run.field}.kind`;
      const index = indexOn(run.table, path);
      const counts: Record<string, number> = Object.fromEntries(run.manifest.states.map((state) => [state.kind, 0]));
      const limit = clamp(args.limit, index ? PER_STATE : SCAN, 5000);
      let capped = false;
      if (index)
        for (const kind of Object.keys(counts)) {
          const found = (await db.query(run.table).withIndex(index, (q) => q.eq(path, kind as never)).take(limit + 1)).length;
          counts[kind] = Math.min(found, limit);
          capped ||= found > limit;
        }
      else {
        const docs = (await db.query(run.table).order("desc").take(limit + 1)) as Loose[];
        capped = docs.length > limit;
        for (const doc of docs.slice(0, limit)) {
          const kind = String((doc[run.field] as Loose | undefined)?.kind);
          counts[kind] = (counts[kind] ?? 0) + 1;
        }
      }
      return { counts, capped, limit, indexed: !!index };
    },

    async rows(ctx: ReadCtx, args: { table: string; machine?: string; kind?: string; limit?: number }): Promise<ViewerRows | null> {
      if (!(await reads(ctx))) return null;
      if (!listable.has(args.table)) refuse("NOT_FOUND", `"${args.table}" isn't a machine's table, or one a machine's row names.`);
      const take = clamp(args.limit, ROWS, MAX_ROWS);
      if (args.machine !== undefined && args.kind !== undefined) {
        const run = runOf(args.machine);
        if (run.table !== args.table) refuse("NOT_FOUND", `${run.name} isn't on "${args.table}".`);
        return await where(ctx, run.table, `${run.field}.kind`, args.kind, take);
      }
      const docs = (await raw(ctx).query(args.table).order("desc").take(take + 1)) as Loose[];
      const rows = [];
      for (const doc of docs.slice(0, take)) rows.push(await summary(ctx, args.table, doc));
      return { rows, more: docs.length > take, capped: false };
    },

    async row(ctx: ReadCtx, args: { table: string; id: string }): Promise<ViewerRow | null> {
      if (!(await reads(ctx))) return null;
      const info = infoOf(args.table);
      const db = raw(ctx);
      const id = db.normalizeId(args.table as never, args.id);
      const doc = id && ((await db.get(id)) as Loose | null);
      if (!doc) return null;
      const children: ViewerRow["children"] = [];
      for (const child of infos)
        if (child.parent?.table === args.table && child.parent.field)
          children.push({ table: child.table, field: child.parent.field, ...(await where(ctx, child.table, child.parent.field, id, CHILDREN)) });
      const parentId = info.parent?.field ? (doc[info.parent.field] as GenericId<string> | undefined) : undefined;
      const parentDoc = parentId ? ((await db.get(parentId)) as Loose | null) : null;
      // The rows that might send this one a link's event: its children and its parent.
      const senders = [
        ...children.flatMap((child) => child.rows.flatMap((row) => runsOn(child.table).map((run) => ({ machine: run.name, id: row.id })))),
        ...(parentDoc ? runsOn(info.parent!.table).map((run) => ({ machine: run.name, id: parentDoc._id as string })) : []),
      ];
      const machines: ViewerRow["machines"] = [];
      for (const run of runsOn(args.table)) {
        // A stored state the machine doesn't know (UNKNOWN_STATE) is shown as a problem, not a broken page.
        const [survey, problem] = await run.survey(ctx, id, { senders }).then(
          (answer) => [answer, undefined] as const,
          (error: unknown) => (error instanceof ConvexError ? ([null, String((error.data as Loose)?.message)] as const) : Promise.reject(error)),
        );
        const history = await run.history(ctx, id, HISTORY);
        machines.push({ machine: run.name, survey, ...(problem ? { problem } : {}), history: history.page, historyMore: !history.isDone });
      }
      return { summary: await summary(ctx, args.table, doc), doc, machines, parent: parentDoc ? await summary(ctx, info.parent!.table, parentDoc) : null, children };
    },

    /** An operator's send: a role's or the server's event, past the role's check. Guards, effects, links and timers run as ever, and history records "operator as <role>". */
    async send(ctx: WriteCtx, args: { machine: string; id: string; event: Event }): Promise<SendResult> {
      await operator(ctx, "Sending");
      return await runOf(args.machine).send(ctx, args.id, args.event);
    },

    /** An operator's create: a row born by a role's or the server's start event, past the role's check. */
    async create(ctx: WriteCtx, args: { machine: string; fields: Loose; event: Event }): Promise<CreateResult> {
      await operator(ctx, "Creating");
      return await runOf(args.machine).create(ctx, args.fields, args.event);
    },
  };
}
