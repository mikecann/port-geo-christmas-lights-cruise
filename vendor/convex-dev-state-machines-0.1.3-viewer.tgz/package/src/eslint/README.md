# Machines lint rules

Guardrails that keep the schema-first design (the root README) intact when an agent, or a person, is in a hurry. A few mistakes undo it quietly: an optional field next to a machine's union, holding data only some states have; a db write that sets a machine's state without the machine; and a delete that skips the machine. They all compile and pass a quick test.

```js
// eslint.config.js
import machines from "@convex-dev/state-machines/eslint";

export default [{ files: ["convex/**/*.ts"], ...machines.configs.recommended }];

// With state fields that aren't machines yet: the list defineMachines has.
export default [{ files: ["convex/**/*.ts"], ...machines.recommended({ notMachines: ["renewals.state"] }) }];
```

| | |
| --- | --- |
| `no-optional-on-machine-tables.js` | No optional or nullable fields next to a machine's state union, however deep, and no `v.any()` or `v.record` there |
| `no-direct-state-writes.js` | No `ctx.db.insert`, `patch`, `replace` or `delete` that writes a machine's state or timers or skips its machine, and no write it can't read |
| `no-brand-bypass.js` | No direct call to the machines' delivery outside `convex/machines.ts`, and no `_handler` outside tests: the two ways round the internal brand |
| `require-disable-reason.js` | An `eslint-disable` that turns any of them off must say why |

`configs.recommended` turns all four on, and `recommended({ notMachines })` does too, with the catalog's list of state fields that aren't machines yet, as `"table.field"`: `no-optional-on-machine-tables` and `no-direct-state-writes` leave those to the app, and each takes the list as its own `notMachines` option. Give them type information (typescript-eslint's `projectService`) and they see further. There's nothing else to configure but where `no-brand-bypass` is off (below). This repo's `eslint.config.js` runs them on the example apps. With types, the rules read the app's `DataModel` (the nearest `_generated/dataModel.d.ts`): a field named `state` or `<name>State` that holds a union of objects tagged with a string `kind` is a machine's. Without types, a field with that name is taken to be one.

## `no-optional-on-machine-tables`

This one is policy, not correctness: an optional nickname next to a union doesn't break the machine. It stays an error because the mistake it catches is the one agents make first when a state needs more data, and because a disable has to say why, which puts the decision in the diff where someone can see it.

A table holds a machine's states if a field named `state` or `<name>State` is a `v.union` of `v.object`s that each have `kind: v.literal(...)` (in the code, or by its type when the union is imported), or has that name and the file doesn't show what it is. That's how the runtime finds a machine's fields: a tagged union under another name (`actor`, `grant`), or as the row, is app data, and so is a field on the `notMachines` list. On such a table it refuses:

```ts
versions: defineTable({
  state: versionState,
  errorMessage: v.optional(v.string()),          // only a failed build has one
  finishedAt: v.union(v.number(), v.null()),     // also v.nullable(...), nullable(...), .optional()
  ...audit,                                      // a spread whose fields are optional
  meta: v.object({ failedAt: v.optional(v.number()) }),   // nested in a plain object
  steps: v.array(v.object({ at: v.optional(v.number()) })),   // in an array's items, or a union's members
  extra: v.any(),                                // v.any() or a v.record: any state's data, unseen
}),
projects: defineTable({ state: v.optional(projectState) }),   // the state itself
deliveries: defineTable({ state: deliveryState, location: v.optional(position) }),   // a live position
```

and, in any state union, a field that's optional in every member, which is the same field moved inside to get past the first check. A union written in a table is a state union only as a state field's value; one in a const may be any table's, so it's checked wherever it is.

What an agent sees:

```
versions.errorMessage is optional, on a table that holds a machine's state (versions.state). If one state has it, put it in that state's member of versionState; if several do, repeat it in each of their members with a shared spread; if every state does, make it a required field here. If it changes every few seconds (a driver's live location), give it a table of its own, keyed by this row's ID: here or in a state, every change rewrites the row the machine and its readers read. Only if it's app data that's optional in every state, keep it and say why: `// eslint-disable-next-line machines/no-optional-on-machine-tables -- <reason>`.
```

It allows optional data inside one state's member (`hint?` on `failed`), a field required in some states and optional in others, a field named `state` that the file shows is something else (`v.string()`), and optional fields, records and `v.any()` on tables no machine holds. It misses "maybe" data that isn't optional (a `""` sentinel, an empty `v.array`), which only review catches.

## `no-direct-state-writes`

Refuses a write that sets a machine's state field, and an insert, replace or delete on a machine's table: an insert skips the start transition (and its guards and timers), a replace rewrites the state, and a delete leaves whatever the machine was doing half done (a building version's project stuck in `building`, its refund never paid). A machine's timers, `stateTimers` or `<name>StateTimers` beside its state, are refused the same way. It follows the db however it's reached (`ctx.db`, `const { db } = ctx`, `({ db }) =>`, `ctx.db as any`, `const { patch } = ctx.db`, `ctx.db.patch.bind(ctx.db)`, `ctx["db"]["patch"]`), and the value however it's built (shorthand, spreads, conditional spreads, computed keys with a const name, `update.state = ...` and `Object.assign(update, ...)` before the call). With types it also reads an ID's table (`patch(projectId, ...)`, `delete(versionId)`) and the fields of any typed value, spread or parameter.

```
This patch writes `state`, a machine's state on projects. Only its machine changes it: send it an event, `<machine>.send(ctx, id, event)`. If no event does what you need, add a transition to the machine.

versions rows hold a machine's state (state), and deleting one skips the machine: a pending timer, a refund or a link never happens. Send it to a final state (a deletion is a transition, like a project's DELETE), or from internal code `<machine>.purge(ctx, id)`, which deletes its timers and records it.
```

In this repo it runs on the example apps, and it's off for their tests, `types.check.ts` and the fixtures, which write it on purpose to prove the guards refuse it. Machine modules aren't exempt.

A write it can't read, it reports rather than passes: a call with spread arguments (`ctx.db.patch(...args)`, what a helper extraction produces), and with types, a value whose type allows any field (`any`, `Record<string, unknown>`) on a machine's table.

Without types it can't tell a delete's table, or a replace whose value it can't see, so it misses those (convex/ is linted with types, which see both). With or without, it misses a key only known at runtime, a helper that wraps the db, and writes in another function through `ctx.runMutation`. The compile-time types and the runtime guard (`STATE_WRITE_OUTSIDE_MACHINE`) still cover the app's mutations. The rule's value on top of them is the cast: when the types refuse a write, an agent's next move is often `ctx.db as any`, and this catches that before a test does.

## `no-brand-bypass`

The internal brand stops a public function from sending `server` events, purging, or running the operator's functions by accident: a type error, and `INTERNAL_ONLY` at runtime. Two ways round it are left, and only deliberate code takes them, as Convex lets any server function call an internal one and keeps a registered function's handler where code can reach it. This rule refuses both:

```ts
await ctx.runMutation(internal.machines.deliver, { machine: "project", id, event: "BUILD_SUCCEEDED", link: { machine: "version", id: versionId, depth: 0, budget: 100 } });   // a forged link's event
await ctx.runMutation(internal.machines.deliver, { machine: "version", id, event: "TIMED_OUT", dueAt });   // a timer, fired early
const ctxWithBrand = await internalMutation({ args: {}, handler: async (ctx) => ctx })._handler(ctx, {});   // the brand, on a public ctx
```

It finds the delivery as `machines.deliver` (the catalog, under any import name or a const that holds it), `internal.machines.deliver`, computed or destructured, and `makeFunctionReference("machines:deliver")`; and `_handler` as any member or destructured key of that name. `convex/machines.ts` registers the delivery, so it has `{ deliver: false }`; the tests, `test.setup.ts`, `types.check.ts` and the fixtures run the delivery and reach for `_handler` on purpose, so it's off for them. It misses a catalog the file can't show is one (a parameter, a property of something else), `Reflect.get`, and a reference built from a string at runtime.

## The escape hatch

```ts
// eslint-disable-next-line machines/no-optional-on-machine-tables -- the kid's own label, the same in every state
nickname: v.optional(v.string()),
```

`require-disable-reason` refuses a disable that turns off a machines rule without `-- <reason>`, and a bare `eslint-disable` with no rule names (it turns these off too) without one. A disable that names only other rules is left alone.

## Tests

`npm test` at the repo root runs them (`vitest.config.ts`, in Node): RuleTester cases for each rule, with the mistakes an agent makes and code that must pass, syntax-only and with types (`fixture/`, which has its own `_generated/dataModel.d.ts`), and the escape hatch end to end.
