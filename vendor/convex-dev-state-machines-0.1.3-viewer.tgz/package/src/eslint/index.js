import noBrandBypass from "./no-brand-bypass.js";
import noDirectStateWrites from "./no-direct-state-writes.js";
import noOptionalOnMachineTables from "./no-optional-on-machine-tables.js";
import requireDisableReason from "./require-disable-reason.js";

// Lint rules that keep a schema-first state machine design intact
// (README.md). Register as `machines`. They find a machine's tables by the
// union's shape and the field's name, and with type information (convex/ is
// linted with it) by the app's DataModel: there's nothing to configure, but
// for state fields that aren't machines yet (`recommended({ notMachines })`)
// and which files may reach round the brand (no-brand-bypass's options).
const plugin = {
  meta: { name: "eslint-plugin-machines", version: "0.4.0" },
  rules: {
    "no-optional-on-machine-tables": noOptionalOnMachineTables,
    "no-direct-state-writes": noDirectStateWrites,
    "no-brand-bypass": noBrandBypass,
    "require-disable-reason": requireDisableReason,
  },
};

/**
 * All four rules as errors. `notMachines` is the list the app gives
 * defineMachines, state fields that aren't machines yet as "table.field":
 * the two rules that find a machine's fields leave those to the app.
 */
plugin.recommended = ({ notMachines = [] } = {}) => ({
  plugins: { machines: plugin },
  rules: {
    "machines/no-optional-on-machine-tables": ["error", { notMachines }],
    "machines/no-direct-state-writes": ["error", { notMachines }],
    "machines/no-brand-bypass": "error",
    "machines/require-disable-reason": "error",
  },
});

plugin.configs = { recommended: plugin.recommended() };

export default plugin;
