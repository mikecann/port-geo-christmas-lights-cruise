/// <reference types="vite/client" />
import { convexTest } from "convex-test";
import { afterEach, beforeEach, describe, expect, test, vi } from "vitest";
import { api } from "./_generated/api.js";
import schema from "./schema.js";

// The component on its own: what the library records, and how it reads and
// prunes it. The library's tests cover it from an app's side.
const modules = import.meta.glob("./**/*.*s");
const fact = (event: string, subject = "row1") => ({ machine: "order", subject, kind: "step" as const, event, from: "a", to: "b", by: "server", reasons: [] });
const page = (t: ReturnType<typeof convexTest>, options: { order?: "asc" | "desc"; cursor?: string | null } = {}) =>
  t.query(api.lib.list, { machine: "order", subject: "row1", order: options.order, paginationOpts: { numItems: 2, cursor: options.cursor ?? null } });

beforeEach(() => vi.useFakeTimers());
afterEach(() => vi.useRealTimers());

describe("history", () => {
  test("record keeps a row's facts in order, and list pages through them, either way", async () => {
    const t = convexTest(schema, modules);
    await t.mutation(api.lib.record, { facts: [fact("ONE"), fact("TWO"), fact("ELSEWHERE", "row2"), fact("THREE")] });
    const first = await page(t);
    expect(first.page.map((entry) => entry.event)).toEqual(["ONE", "TWO"]);
    expect(first.isDone).toBe(false);
    const rest = await page(t, { cursor: first.continueCursor });
    expect(rest.page.map((entry) => entry.event)).toEqual(["THREE"]);
    expect(rest.isDone).toBe(true);
    expect((await page(t, { order: "desc" })).page.map((entry) => entry.event)).toEqual(["THREE", "TWO"]);
    expect(first.page[0]).toEqual({ kind: "step", event: "ONE", from: "a", to: "b", by: "server", reasons: [], at: expect.any(Number) });
  });

  test("prune deletes what was recorded before `before`, and keeps the rest", async () => {
    const t = convexTest(schema, modules);
    await t.mutation(api.lib.record, { facts: [fact("OLD"), fact("OLDER")] });
    vi.advanceTimersByTime(1_000);
    const before = Date.now();
    await t.mutation(api.lib.record, { facts: [fact("NEW")] });
    expect(await t.mutation(api.lib.prune, { before })).toEqual({ deleted: 2, more: false });
    expect((await page(t)).page.map((entry) => entry.event)).toEqual(["NEW"]);
  });
});
