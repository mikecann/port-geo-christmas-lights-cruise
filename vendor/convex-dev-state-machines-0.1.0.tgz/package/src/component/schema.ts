import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

/** One fact about a machine's row, as the library records it. */
export const fact = {
  machine: v.string(),
  subject: v.string(), // the row's ID
  // "step": an event moved the row, or kept it.
  // "refused": its state refused a timer's event, and the timer is spent.
  // "ignored": the step's `ignore` links whose receivers refused, and why.
  // "purged": purge() deleted the row.
  kind: v.union(v.literal("step"), v.literal("refused"), v.literal("ignored"), v.literal("purged")),
  event: v.string(), // "" for a purge
  from: v.string(), // "start" for a birth
  to: v.string(), // "" for a purge
  by: v.string(), // a role, "server", "timer", or "<machine>:<id>" for a link
  reasons: v.array(v.string()),
};

/** A fact as `list` returns it: `at` is when it was recorded. */
export const entry = v.object({
  kind: fact.kind,
  event: fact.event,
  from: fact.from,
  to: fact.to,
  by: fact.by,
  reasons: fact.reasons,
  at: v.number(),
});

// One row per fact, written when it happens, so _creationTime is their order.
export default defineSchema({
  history: defineTable(fact).index("by_subject", ["machine", "subject"]),
});
