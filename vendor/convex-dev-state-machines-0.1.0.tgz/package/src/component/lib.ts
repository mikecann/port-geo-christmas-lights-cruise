import { paginationOptsValidator, paginationResultValidator } from "convex/server";
import { v } from "convex/values";
import { paginator } from "convex-helpers/server/pagination";
import { mutation, query } from "./_generated/server.js";
import schema, { entry, fact } from "./schema.js";

const PRUNE_BATCH = 500;

export const record = mutation({
  args: { facts: v.array(v.object(fact)) },
  returns: v.null(),
  handler: async (ctx, { facts }) => {
    for (const row of facts) await ctx.db.insert("history", row);
    return null;
  },
});

/** One row's history, oldest first by default. A component can't use db.paginate(), so it pages with convex-helpers' paginator. */
export const list = query({
  args: { machine: v.string(), subject: v.string(), order: v.optional(v.union(v.literal("asc"), v.literal("desc"))), paginationOpts: paginationOptsValidator },
  returns: paginationResultValidator(entry),
  handler: async (ctx, { machine, subject, order = "asc", paginationOpts }) => {
    const result = await paginator(ctx.db, schema)
      .query("history")
      .withIndex("by_subject", (q) => q.eq("machine", machine).eq("subject", subject))
      .order(order)
      .paginate(paginationOpts);
    return { ...result, page: result.page.map(({ kind, event, from, to, by, reasons, _creationTime }) => ({ kind, event, from, to, by, reasons, at: _creationTime })) };
  },
});

/** Deletes up to 500 rows written before `before` (ms), oldest first. Run it until `more` is false. */
export const prune = mutation({
  args: { before: v.number() },
  returns: v.object({ deleted: v.number(), more: v.boolean() }),
  handler: async (ctx, { before }) => {
    const rows = await ctx.db
      .query("history")
      .withIndex("by_creation_time", (q) => q.lt("_creationTime", before))
      .take(PRUNE_BATCH);
    for (const row of rows) await ctx.db.delete("history", row._id);
    return { deleted: rows.length, more: rows.length === PRUNE_BATCH };
  },
});
