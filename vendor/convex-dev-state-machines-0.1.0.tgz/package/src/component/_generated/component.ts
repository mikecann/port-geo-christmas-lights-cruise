/* eslint-disable */
/**
 * Generated `ComponentApi` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type { FunctionReference } from "convex/server";

/**
 * A utility for referencing a Convex component's exposed API.
 *
 * Useful when expecting a parameter like `components.myComponent`.
 * Usage:
 * ```ts
 * async function myFunction(ctx: QueryCtx, component: ComponentApi) {
 *   return ctx.runQuery(component.someFile.someQuery, { ...args });
 * }
 * ```
 */
export type ComponentApi<Name extends string | undefined = string | undefined> =
  {
    lib: {
      list: FunctionReference<
        "query",
        "internal",
        {
          machine: string;
          order?: "asc" | "desc";
          paginationOpts: {
            cursor: string | null;
            endCursor?: string | null;
            id?: number;
            maximumBytesRead?: number;
            maximumRowsRead?: number;
            numItems: number;
          };
          subject: string;
        },
        {
          continueCursor: string;
          isDone: boolean;
          page: Array<{
            at: number;
            by: string;
            event: string;
            from: string;
            kind: "step" | "refused" | "ignored" | "purged";
            reasons: Array<string>;
            to: string;
          }>;
          pageStatus?: "SplitRecommended" | "SplitRequired" | null;
          splitCursor?: string | null;
        },
        Name
      >;
      prune: FunctionReference<
        "mutation",
        "internal",
        { before: number },
        { deleted: number; more: boolean },
        Name
      >;
      record: FunctionReference<
        "mutation",
        "internal",
        {
          facts: Array<{
            by: string;
            event: string;
            from: string;
            kind: "step" | "refused" | "ignored" | "purged";
            machine: string;
            reasons: Array<string>;
            subject: string;
            to: string;
          }>;
        },
        null,
        Name
      >;
    };
  };
