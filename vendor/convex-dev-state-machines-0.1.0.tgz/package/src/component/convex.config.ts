import { defineComponent } from "convex/server";

// The machines' history: one row per fact, kept apart from the app's tables.
// An app installs it in convex/convex.config.ts and passes
// `components.stateMachines` to defineMachines. Machines with
// `history: false` never call it.
export default defineComponent("stateMachines");
