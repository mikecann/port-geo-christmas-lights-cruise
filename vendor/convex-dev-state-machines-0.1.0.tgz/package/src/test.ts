/// <reference types="vite/client" />
// Helpers for testing an app's machines with convex-test and vitest:
// `import { register } from "@convex-dev/state-machines/test"`.
import type { TestConvex } from "convex-test";
import { componentsGeneric, type GenericDataModel, type GenericQueryCtx, type GenericSchema, type SchemaDefinition } from "convex/server";
import { vi } from "vitest";
import type { ComponentApi } from "./component/_generated/component.js";
import schema from "./component/schema.js";
const modules = import.meta.glob("./component/**/*.ts");

/**
 * Registers the component with a convex-test instance, under the name it has
 * in the app's convex.config.ts, and returns its API.
 */
export function register<Schema extends SchemaDefinition<GenericSchema, boolean>>(t: TestConvex<Schema>, name: string = "stateMachines") {
  t.registerComponent(name, schema, modules);
  return componentsGeneric()[name] as unknown as ComponentApi;
}

/** A row's history, oldest first, as the component keeps it. */
export async function historyOf(
  t: { run<R>(fn: (ctx: { runQuery: GenericQueryCtx<GenericDataModel>["runQuery"] }) => Promise<R>): Promise<R> },
  component: ComponentApi,
  machine: string,
  subject: string,
) {
  const list = await t.run((ctx) => ctx.runQuery(component.lib.list, { machine, subject, paginationOpts: { numItems: 1000, cursor: null } }));
  return list.page;
}

// The ctx the catalog's internal functions take: the internal brand, typed by the catalog itself.
type InternalOf<Catalog> = Catalog extends { deliver: (ctx: infer Ctx, ...args: never[]) => unknown } ? Ctx : never;
type Catalog = { internalMutation: unknown; deliver: unknown };

/**
 * Runs `handler` as Convex runs the body of a function built with the
 * catalog's internalMutation: the guarded db, the internal brand, and the
 * builder's check when it returns. The catalog keeps the brand inside its
 * builders, so this is a test's way in: the builder's own handler, which a
 * registered function keeps as `_handler` (convex-test calls it so too).
 */
export async function throughInternal<C extends Catalog, Ctx extends object, R>(catalog: C, ctx: Ctx, handler: (ctx: Ctx & InternalOf<C>) => Promise<R>) {
  const fn = (catalog.internalMutation as (fn: object) => { _handler: (ctx: Ctx, args: object) => Promise<R> })({ args: {}, handler });
  return await fn._handler(ctx, {});
}

/** A test's ctx as the app's internalMutation gives it to a handler: how a test sends `server` events and purges. */
export const asInternal = <C extends Catalog, Ctx extends object>(catalog: C, ctx: Ctx) => throughInternal(catalog, ctx, async (inner) => inner);

/**
 * Moves fake time on by `ms` (with `vi.useFakeTimers()`), letting every
 * scheduled function due on the way run. A delivery can arm the next state's
 * timer, so time moves in small steps and each step runs until it settles.
 */
export async function advance(t: { finishInProgressScheduledFunctions(): Promise<void> }, ms: number) {
  const until = Date.now() + ms;
  for (;;) {
    for (let hop = 0; hop < 3; hop++) {
      vi.advanceTimersByTime(0);
      await t.finishInProgressScheduledFunctions();
    }
    if (Date.now() >= until) return;
    vi.advanceTimersByTime(Math.min(STEP_MS, until - Date.now()));
  }
}
const STEP_MS = 50;

export default { register, schema, modules };
