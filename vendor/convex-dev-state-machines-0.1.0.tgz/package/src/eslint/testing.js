import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { RuleTester } from "eslint";
import tseslint from "typescript-eslint";
import { describe, it } from "vitest";

// RuleTester under vitest. The rules need no settings.
RuleTester.describe = describe;
RuleTester.it = it;
RuleTester.itOnly = it.only;

const fixtureDir = fileURLToPath(new URL("./fixture", import.meta.url));

/** Syntax only, as the rules run on a file with no type information. */
export const syntaxTester = new RuleTester({ languageOptions: { parser: tseslint.parser } });

/** With types, as convex/ is linted. The fixture has its own _generated/dataModel.d.ts. */
export const typedTester = new RuleTester({
  languageOptions: { parser: tseslint.parser, parserOptions: { projectService: true, tsconfigRootDir: fixtureDir } },
});

/** Typed cases run as fixture/file.ts, after `prelude`. */
export const typed = (prelude, cases) =>
  cases.map((item) => {
    const test = typeof item === "string" ? { code: item } : item;
    return { ...test, code: `${prelude}\n${test.code}`, filename: join(fixtureDir, "file.ts") };
  });
