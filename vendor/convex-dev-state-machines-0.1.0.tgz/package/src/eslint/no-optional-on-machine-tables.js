import { fieldsFromType, importOf, initOf, isStateName, keyName, memberName, typesOf, unwrap, validatorFromType } from "./utils.js";

// A table that holds a machine's states keeps each state's data in that
// state's union member. An optional or nullable field next to the union is
// state-specific data leaking out of it: `errorMessage?` on a version that
// only a failed build has. This rule refuses one on any table that holds a
// state union, outside the union, however deep (in an object, an array's
// items or a union's members); a `v.any()` or `v.record` there, which can
// carry the same data unseen; and a field that's optional in every member of
// a state union, which is the same thing moved inside.
//
// A table holds a machine's states if one of its fields, or the row, is a
// `v.union` of `v.object`s that each have `kind: v.literal(...)`. The code
// says so for a union written in the schema file; the type says so for one
// imported from another (when the file has type information). Without
// types, a field named `state` or `<name>State` whose validator the file
// doesn't show (an import, a helper's result) is taken to be one: that's the
// name a machine's state has.

const RULE = "machines/no-optional-on-machine-tables";
const disable = `\`// eslint-disable-next-line ${RULE} -- <reason>\``;

export default {
  meta: {
    type: "problem",
    docs: {
      description:
        "Keep state-specific data in a machine's union members, not in optional or nullable fields on its table.",
    },
    schema: [],
    messages: {
      optional: `{{path}} is {{how}}, on a table that holds {{owner}}. If one state has it, put it in that state's member of {{union}}; if several do, repeat it in each of their members with a shared spread; if every state does, make it a required field here. If it changes every few seconds (a driver's live location), give it a table of its own, keyed by this row's ID: here or in a state, every change rewrites the row the machine and its readers read. Only if it's app data that's optional in every state, keep it and say why: ${disable}.`,
      optionalState:
        "{{path}} holds {{owner}}, so it must be required: every row is in exactly one state. For 'not started yet', add a state to {{union}} instead.",
      optionalEverywhere: `{{field}} is {{how}} in every member of {{union}}, so it isn't any state's data. If every state has it, make it required; if only some do, keep it in just those states' members, with a shared spread. Only if it's app data that's optional in every state, keep it and say why: ${disable}.`,
      loose: `{{path}} is {{how}}, on a table that holds {{owner}}, so it can carry any state's data without the schema seeing it. Give it a shape every row has, or put the data in the state's member of {{union}} that has it. Only if it's app data that's the same in every state, keep it and say why: ${disable}.`,
    },
  },

  create(context) {
    const types = typesOf(context);

    // What the rule needs to know about a validator: its kind, whether it's
    // optional or nullable, a union's members and an object's fields. Read
    // from the code, or from the type when the code doesn't say.
    function read(node, depth = 0) {
      node = unwrap(node);
      if (!node || depth > 6) return { kind: null };
      if (node.type === "Identifier") {
        const init = initOf(context, node);
        return init ? read(init, depth + 1) : fromType(node);
      }
      if (node.type === "ObjectExpression") return { kind: "object", fields: fieldsOf(node, depth) };
      if (node.type !== "CallExpression") return fromType(node);
      const callee = unwrap(node.callee);
      const name =
        callee.type === "MemberExpression" ? memberName(callee, context) : callee.type === "Identifier" ? callee.name : null;
      const onV = callee.type === "MemberExpression" && unwrap(callee.object).type === "Identifier" && unwrap(callee.object).name === "v";
      const [first] = node.arguments;
      if (onV && name === "optional") return { ...read(first, depth + 1), optional: "optional" };
      if (onV && name === "nullable") return { ...read(first, depth + 1), optional: "nullable" };
      if (onV && name === "union") {
        const members = node.arguments.map((member) => read(member, depth + 1));
        return { kind: "union", members, optional: members.some((member) => member.kind === "null") ? "nullable" : null };
      }
      if (onV && name === "object") return { kind: "object", fields: first?.type === "ObjectExpression" ? fieldsOf(first, depth) : null };
      if (onV && name === "array") return { kind: "array", element: read(first, depth + 1), optional: null };
      if (onV && name) return { kind: name, optional: null };
      // `v.string().optional()`, and convex-helpers' `nullable(v.string())`.
      if (callee.type === "MemberExpression" && name === "optional" && !node.arguments.length)
        return { ...read(callee.object, depth + 1), optional: "optional" };
      if (callee.type === "Identifier" && name === "nullable") return { ...read(first, depth + 1), optional: "nullable" };
      return fromType(node);
    }

    function fromType(node) {
      return types && node ? validatorFromType(types, types.typeAt(node)) : { kind: null };
    }

    // An object of validators, as defineTable and v.object take. A spread
    // reports at the spread, since its fields are written somewhere else.
    function fieldsOf(object, depth) {
      const fields = [];
      for (const property of object.properties) {
        if (property.type === "Property") {
          const name = keyName(property, context);
          if (name !== null) fields.push({ name, view: read(property.value, depth + 1), node: property, value: property.value });
          continue;
        }
        const spread = unwrap(property.argument);
        const init = spread.type === "Identifier" ? unwrap(initOf(context, spread)) : spread;
        if (init?.type === "ObjectExpression") {
          for (const field of fieldsOf(init, depth + 1)) fields.push({ ...field, node: property });
        } else if (types) {
          for (const field of fieldsFromType(types, types.typeAt(spread)) ?? []) fields.push({ ...field, node: property });
        }
      }
      return fields;
    }

    const isStateUnion = (view) =>
      view.kind === "union" &&
      view.members.length > 0 &&
      view.members.every(
        (member) =>
          member.kind === "object" &&
          member.fields?.some((field) => field.name === "kind" && field.view.kind === "literal"),
      );

    const isV = (callee, name) =>
      callee.type === "MemberExpression" &&
      unwrap(callee.object).type === "Identifier" &&
      unwrap(callee.object).name === "v" &&
      memberName(callee, context) === name;

    const isDefineTable = (callee) =>
      (callee.type === "Identifier" && callee.name === "defineTable") ||
      (callee.type === "MemberExpression" && memberName(callee, context) === "defineTable");

    // Where the union is, for the message: `versionBuild` in ./states.
    function unionName(field, path) {
      const value = field?.value && unwrap(field.value);
      const wrapped =
        value?.type === "CallExpression" &&
        ["optional", "nullable"].includes(unwrap(value.callee).property?.name) &&
        value.arguments[0];
      for (const node of [value, wrapped && unwrap(wrapped)]) {
        if (node?.type !== "Identifier") continue;
        const from = importOf(context, node);
        return from ? `${from.name} in ${from.source}` : node.name;
      }
      return path;
    }

    // `defineSchema({ projects: defineTable({...}).index(...) })`, or a const.
    function tableName(call) {
      let node = call;
      while (
        node.parent.type === "MemberExpression" &&
        node.parent.object === node &&
        node.parent.parent.type === "CallExpression" &&
        node.parent.parent.callee === node.parent
      )
        node = node.parent.parent;
      if (node.parent.type === "Property" && node.parent.value === node) return keyName(node.parent, context);
      if (node.parent.type === "VariableDeclarator" && node.parent.id.type === "Identifier") return node.parent.id.name;
      return null;
    }

    // A `v.union(...)`'s name, for the message: its const, the table it's
    // the row of, or the table field it's written in.
    function unionLabel(call) {
      let node = call;
      while (node.parent.type === "CallExpression" && isV(unwrap(node.parent.callee), "optional")) node = node.parent;
      const parent = node.parent;
      if (parent.type === "VariableDeclarator" && parent.id.type === "Identifier") return parent.id.name;
      if (parent.type === "CallExpression" && isDefineTable(unwrap(parent.callee))) return `the ${tableName(parent) ?? "table"} row`;
      if (parent.type === "Property" && parent.value === node && parent.parent.parent?.type === "CallExpression") {
        const owner = parent.parent.parent;
        const key = keyName(parent, context);
        if (isDefineTable(unwrap(owner.callee))) return `${tableName(owner) ?? "this table"}.${key}`;
      }
      return "this union";
    }

    // A field outside the state union, and whatever it holds: an object's
    // fields, an array's items, a union's members.
    function checkFields(fields, path, owner, union, node) {
      for (const field of fields) check(field.view, `${path}.${field.name}`, field.node ?? node, owner, union);
    }
    function check(view, path, node, owner, union) {
      if (view.optional) return context.report({ node, messageId: "optional", data: { path, how: view.optional, owner, union } });
      if (view.kind === "any" || view.kind === "record")
        return context.report({ node, messageId: "loose", data: { path, how: view.kind === "any" ? "v.any()" : "a v.record", owner, union } });
      if (view.kind === "object" && view.fields) checkFields(view.fields, path, owner, union, node);
      if (view.kind === "array" && view.element) check(view.element, `${path}[]`, node, owner, union);
      if (view.kind === "union") for (const member of view.members ?? []) check(member, path, node, owner, union);
    }

    return {
      CallExpression(call) {
        const callee = unwrap(call.callee);

        // A state union written here, as a field or as the row: a field
        // that's in every member and optional in all of them belongs to no
        // state. Required in some and optional in others is a real
        // per-state shape, and fine.
        if (isV(callee, "union")) {
          const view = read(call);
          if (!isStateUnion(view)) return;
          const lists = view.members.map((member) => member.fields ?? []);
          const label = unionLabel(call);
          for (const first of lists[0]) {
            if (first.name === "kind") continue;
            const same = lists.map((list) => list.find((field) => field.name === first.name));
            if (!same.every((field) => field?.view.optional)) continue;
            const how = same.every((field) => field.view.optional === "nullable") ? "nullable" : "optional";
            context.report({
              node: first.node ?? call,
              messageId: "optionalEverywhere",
              data: { field: first.name, how, union: label },
            });
          }
          return;
        }

        if (!isDefineTable(callee) || !call.arguments[0]) return;
        const table = tableName(call) ?? "this table";
        const doc = read(call.arguments[0]);
        // A row that is the union has no fields outside it. Its members are
        // checked where the union is written.
        if (doc.kind !== "object" || !doc.fields) return;

        // The fields that hold a machine's states: state unions, written here
        // or typed as one, and state-named fields the file can't read.
        const stateFields = new Map();
        for (const field of doc.fields) {
          const view = field.view.optional ? { ...field.view, optional: null } : field.view;
          if (isStateUnion(view) || (isStateName(field.name) && view.kind === null))
            stateFields.set(field.name, isStateName(field.name) ? "a machine's state" : "a state union");
        }
        if (!stateFields.size) return;

        const owner = [...stateFields].map(([name, what]) => `${what} (${table}.${name})`).join(" and ");
        const [firstState] = stateFields.keys();
        const union = unionName(
          doc.fields.find((field) => field.name === firstState),
          `${table}.${firstState}`,
        );
        for (const field of doc.fields) {
          if (!field.view.optional) continue;
          const path = `${table}.${field.name}`;
          if (stateFields.has(field.name))
            context.report({
              node: field.node,
              messageId: "optionalState",
              data: { path, owner: stateFields.get(field.name), union: unionName(field, path) },
            });
        }
        checkFields(
          doc.fields.filter((field) => !stateFields.has(field.name)),
          table,
          owner,
          union,
        );
      },
    };
  },
};
