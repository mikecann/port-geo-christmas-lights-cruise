import { defineConfig } from "vitest/config";

// The lint rules' tests, in Node: ESLint doesn't run in the edge runtime.
export default defineConfig({
  test: {
    name: "eslint",
    include: ["**/*.test.js"],
    environment: "node",
    testTimeout: 30_000,
  },
});
