import rule from "./no-direct-state-writes.js";
import { syntaxTester, typed, typedTester } from "./testing.js";

// The mistakes an agent makes when it wants a project or a version in some
// state and doesn't look for the machine: writing the state field, a whole
// row, or deleting one. Without types, a field named `state` or `<name>State`
// is taken to be a machine's; with them, the fixture's data model says
// (fixture/_generated/dataModel.d.ts: projects.state and versions.state).

syntaxTester.run("no-direct-state-writes", rule, {
  valid: [
    // The app's own fields and tables are the app's.
    `await ctx.db.patch("projects", projectId, { name: "Space dog game" });`,
    `await ctx.db.insert("accounts", { name: "Sam", credits: 10 });`,
    `await ctx.db.patch("accounts", accountId, { credits: account.credits + 9 });`,
    // A machine module's helper, writing the row's app fields in a step (project.ts).
    `await ctx.db.patch("projects", project._id, { nextNumber: project.nextNumber + 1 });`,
    // The way in: events and create().
    `await project.send(ctx, projectId, { type: "EDIT", prompt: "Add lasers" });`,
    `await project.create(ctx, { accountId, name: "Space cat game", nextNumber: 1, state: { kind: "noApp" } });`,
    `await version.create(ctx, { projectId, number: 2, purpose: "edit", request, cost: 5, state: { kind: "building", model: "primary" } });`,
    // Effects return the next state's data, and the library writes it.
    `export const version = defineMachine(rules, {
      effects: {
        finish: async (_ctx, { state }) => ({ model: state.model, builtAt: Date.now() }),
        refundCancel: async (ctx, { row }) => ({ refunded: await refund(ctx, row) }),
      },
    });`,
    `const effects = { useBuild: async (_ctx, { state }) => ({ current: state.building }) };`,
    // Reading state is fine. Without types a delete's table can't be told
    // apart (it's caught with them, below).
    `if (row.state.kind === "ready") await ctx.db.delete("projects", row._id);`,
    // Without types, a replace whose value the file doesn't show (caught with them).
    `await ctx.db.replace("projects", id, { ...project, name: "Renamed" });`,
    // A table the rule can't name, with nothing a machine owns in it.
    `await ctx.db.patch(table, id, { updatedAt: Date.now() });`,
    `await ctx.db.patch(id, { name });`,
    // Not a db.
    `await cache.patch("projects", id, { state: "draft" });`,
    `await ctx.runMutation(internal.projects.patch, { state: "draft" });`,
    // Known misses without types (convex/ is linted with types, which catch
    // the first two): a value from a call, a parameter's keys, and with or
    // without types, a key only known at runtime and a helper that wraps the
    // db. The runtime guard still throws on all of them, in the app's mutations.
    `await ctx.db.patch("projects", id, buildPatch());`,
    `async function save(ctx, id, fields) { await ctx.db.patch("projects", id, fields); }`,
    `await ctx.db.patch("projects", id, { [pickField()]: next });`,
    `await writeRow(ctx, "projects", id, { state: next });`,
  ],
  invalid: [
    // The brief's example: a new mutation, and the older patch(id, value)
    // form. With no types the table's unknown, so any machine's field counts.
    {
      code: `export const markReady = mutation({
        args: { projectId: v.id("projects"), versionId: v.id("versions") },
        handler: async (ctx, { projectId, versionId: current }) => {
          await ctx.db.patch(projectId, { state: { kind: "ready", current } });
        },
      });`,
      errors: [
        {
          messageId: "unknownTable",
          line: 4,
          data: { method: "patch", verb: "writes", via: "", key: "state", named: 'ctx.db.patch("<table>", id, value)' },
        },
      ],
    },
    // The same with the table named.
    {
      code: `await ctx.db.patch("projects", projectId, { state: { kind: "ready", current: versionId } });`,
      errors: [
        {
          message:
            "This patch writes `state`, which belongs to a machine on projects. Only its machine changes it: send it an event, `<machine>.send(ctx, id, event)`. If no event does what you need, add a transition to the machine.",
        },
      ],
    },
    // Marking a stuck build done.
    {
      code: `await ctx.db.patch("versions", versionId, { state: { kind: "ready", model: "primary", builtAt: Date.now() } });`,
      errors: [{ messageId: "patch" }],
    },
    // A state built first, then written: shorthand, a spread, a spread of the old state.
    {
      code: `const state = { kind: "ready", current };
        await ctx.db.patch("projects", id, { state });`,
      errors: [{ messageId: "patch", data: { verb: "writes", via: "", key: "state", table: "projects" } }],
    },
    {
      code: `const next = { state: { kind: "ready", current } };
        await ctx.db.patch("projects", id, { ...next, name });`,
      errors: [{ messageId: "patch", data: { verb: "writes", via: " through `...next`", key: "state", table: "projects" } }],
    },
    {
      code: `await ctx.db.patch("projects", id, { state: { ...project.state, kind: "ready" } });`,
      errors: [{ messageId: "patch" }],
    },
    {
      code: `await ctx.db.patch("projects", id, { name, ...(done ? { state: { kind: "ready", current } } : {}) });`,
      errors: [{ messageId: "patch" }],
    },
    // An update object filled in later.
    {
      code: `const update = {};
        if (args.name) update.name = args.name;
        if (args.versionId) update.state = { kind: "ready", current: args.versionId };
        await ctx.db.patch("projects", args.projectId, update);`,
      errors: [{ messageId: "patch", data: { verb: "writes", via: " through `update`", key: "state", table: "projects" } }],
    },
    // Computed keys.
    {
      code: `const field = "state";
        await ctx.db.patch("projects", id, { [field]: next, ["name"]: name });`,
      errors: [{ messageId: "patch" }],
    },
    // A replace or an insert that writes a state field rewrites the machine's state.
    {
      code: `await ctx.db.replace("projects", id, { ...project, name: "Renamed", state: { kind: "noApp" } });`,
      errors: [
        {
          message:
            "A replace on projects rewrites a machine's state (state). Patch the app's own fields instead, and change the state by sending the machine an event.",
        },
      ],
    },
    {
      code: `await ctx.db.insert("versions", {
          projectId, number: 3, purpose: "edit", request, cost: 0,
          state: { kind: "ready", model: "primary", builtAt: Date.now() },
        });`,
      errors: [
        {
          message:
            "versions rows hold a machine's state (state), so they're born by an event: `<machine>.create(ctx, fields, event)` runs its start transition and arms its timers. Don't insert them directly.",
        },
      ],
    },
    // However the db is reached: destructured, renamed, a handler's
    // parameter, cast, a method pulled off it, optional chaining, a
    // template literal table.
    {
      code: `const { db } = ctx; await db.patch("versions", versionId, { state });`,
      errors: [{ messageId: "patch" }],
    },
    {
      code: `const database = ctx.db; await database.patch("projects", id, { state });`,
      errors: [{ messageId: "patch" }],
    },
    {
      code: `export const fix = internalMutation({ handler: async ({ db }, { id }) => db.patch("projects", id, { state: { kind: "noApp" } }) });`,
      errors: [{ messageId: "patch" }],
    },
    {
      code: `await (ctx.db as any).patch("projects", id, { state: { kind: "noApp" } });`,
      errors: [{ messageId: "patch" }],
    },
    {
      code: `const writer = ctx.db as unknown as Writer; await writer.replace("projects", id, { ...fields, state });`,
      errors: [{ messageId: "replace" }],
    },
    {
      code: `const { patch } = ctx.db; await patch("projects", id, { state });`,
      errors: [{ messageId: "patch" }],
    },
    {
      code: "await ctx.db?.patch(`projects`, id, { state: next });",
      errors: [{ messageId: "patch" }],
    },
    {
      code: `await ctx["db"]["patch"]("projects", id, { state });`,
      errors: [{ messageId: "patch" }],
    },
    // A one-off migration to unstick builds. The table is unknown without
    // types, so any machine's field counts.
    {
      code: `export const unstick = internalMutation({
        handler: async (ctx) => {
          const stuck = await ctx.db.query("versions").withIndex("by_state", (q) => q.eq("state.kind", "building")).collect();
          for (const row of stuck) await ctx.db.patch(row._id, { state: { kind: "failed", model: row.state.model, error: "stuck", refunded: 0 } });
        },
      });`,
      errors: [{ messageId: "unknownTable", line: 4, data: { method: "patch", verb: "writes", via: "", key: "state", named: 'ctx.db.patch("<table>", id, value)' } }],
    },
    // A test helper that makes a project already built, instead of sending
    // CREATE and SUCCEEDED.
    {
      code: `const projectId = await ctx.db.insert("projects", { accountId, name: "Space cat game", nextNumber: 2, state: { kind: "ready", current: versionId } });`,
      errors: [{ messageId: "insert", data: { table: "projects", owned: "state" } }],
    },
    // Object.assign, into an update object or straight into the patch.
    {
      code: `const update = { name };
        Object.assign(update, { state: { kind: "noApp" } });
        await ctx.db.patch("projects", id, update);`,
      errors: [{ messageId: "patch", line: 3, data: { verb: "writes", via: " through `update`", key: "state", table: "projects" } }],
    },
    {
      code: `await ctx.db.patch("projects", id, Object.assign({}, base, { state: next }));`,
      errors: [{ messageId: "patch", data: { verb: "writes", via: "", key: "state", table: "projects" } }],
    },
    // A method taken off the db.
    {
      code: `const write = ctx.db.patch.bind(ctx.db); await write("versions", versionId, { state });`,
      errors: [{ messageId: "patch" }],
    },
    {
      code: `const write = ctx.db.replace; await write("projects", id, { ...project, state: next });`,
      errors: [{ messageId: "replace" }],
    },
    // A machine's timers, beside its state: an agent "fixing" a stuck timer.
    { code: `await ctx.db.patch("versions", id, { stateTimers: [] });`, errors: [{ messageId: "patch", data: { verb: "writes", via: "", key: "stateTimers", table: "versions" } }] },
    { code: `await ctx.db.patch("lamps", id, { powerStateTimers: [] });`, errors: [{ messageId: "patch", data: { verb: "writes", via: "", key: "powerStateTimers", table: "lamps" } }] },
    // A write it can't read is reported, not passed: spread arguments, as a helper extraction makes.
    {
      code: `const args = ["projects", id, { name }]; await ctx.db.patch(...args);`,
      errors: [{ messageId: "unresolved", data: { method: "patch", why: "passes its arguments with a spread" } }],
    },
    // A machine module isn't exempt: an effect gets the guarded db at
    // runtime, so writing another machine's state (or its own) would throw.
    // Links are the transition's `sends`, which the library sends.
    {
      code: `export const version = defineMachine(rules, {
        effects: {
          finish: async (ctx, { row, state }) => {
            await ctx.db.patch("projects", row.projectId, { state: { kind: "ready", current: row._id } });
            return { model: state.model, builtAt: Date.now() };
          },
        },
      });`,
      errors: [{ messageId: "patch", line: 4 }],
    },
  ],
});

// With types, as convex/ is linted: an ID's table, a db by its type, and
// whatever a spread or a value can carry.
const prelude = `
import type { GenericDatabaseWriter } from "convex/server";
import type { GenericId as Id } from "convex/values";
import type { DataModel } from "./_generated/dataModel";
void (0 as unknown as DataModel);
declare const ctx: { db: GenericDatabaseWriter<any> };
declare const projectId: Id<"projects">;
declare const versionId: Id<"versions">;
declare const accountId: Id<"accounts">;
type Project = { name: string; state: { kind: "noApp" } | { kind: "ready"; current: Id<"versions"> } };`;

typedTester.run("no-direct-state-writes, with types", rule, {
  valid: typed(prelude, [
    // The table comes from the ID's type, so the account's own fields are fine.
    `await ctx.db.patch(accountId, { credits: 50 });`,
    `await ctx.db.delete("accounts", accountId);`,
    // drafts.state is a plain string in the data model, not a machine's union.
    `declare const draftId: Id<"drafts">; await ctx.db.patch("drafts", draftId, { state: "published" });`,
    `declare const rename: { name: string }; await ctx.db.patch(projectId, { ...rename });`,
    // Not a db: no insert, query or get.
    `declare const api: { patch(id: string, value: object): Promise<void> }; await api.patch("x", { state: 1 });`,
    // A loose value on a table no machine holds is the app's business.
    `declare const value: Record<string, unknown>; await ctx.db.patch(accountId, value);`,
  ]),
  invalid: typed(prelude, [
    // A version's timers, which the data model has beside its state.
    {
      code: `await ctx.db.patch(versionId, { stateTimers: [] });`,
      errors: [{ messageId: "patch", data: { verb: "writes", via: "", key: "stateTimers", table: "versions" } }],
    },
    // The brief's example again: now the ID's type names the table.
    {
      code: `declare const current: Id<"versions">;
        await ctx.db.patch(projectId, { state: { kind: "ready", current } });`,
      errors: [{ messageId: "patch", data: { verb: "writes", via: "", key: "state", table: "projects" } }],
    },
    // A typed update object, spread in or passed.
    {
      code: `declare const updates: Partial<Project>; await ctx.db.patch(projectId, { ...updates });`,
      errors: [
        { messageId: "patch", data: { verb: "can write", via: " through `...updates` (its type has it)", key: "state", table: "projects" } },
      ],
    },
    {
      code: `declare function finishBuild(): { state: { kind: "ready"; model: string; builtAt: number } };
        await ctx.db.patch(versionId, finishBuild());`,
      errors: [{ messageId: "patch", data: { verb: "can write", via: " (its type has it)", key: "state", table: "versions" } }],
    },
    // A helper's parameter, by its type.
    {
      code: `async function save(id: Id<"projects">, fields: Partial<Project>) {
          await ctx.db.patch(id, fields);
        }`,
      errors: [
        { messageId: "patch", data: { verb: "can write", via: " (its type has it)", key: "state", table: "projects" } },
      ],
    },
    // A db passed to a helper under any name, found by its type.
    {
      code: `async function save(writer: GenericDatabaseWriter<any>, id: Id<"projects">) {
          await writer.patch(id, { state: { kind: "noApp" } });
        }`,
      errors: [{ messageId: "patch" }],
    },
    // A replace through the older form, found by the ID's type, and one whose value the file doesn't show.
    {
      code: `declare const project: Project; await ctx.db.replace(projectId, { ...project, name: "Renamed" });`,
      errors: [{ messageId: "replace" }],
    },
    { code: `declare const fields: Project; await ctx.db.replace("projects", projectId, fields);`, errors: [{ messageId: "replace" }] },
    // Deleting a building version would leave its project building forever.
    {
      code: `await ctx.db.delete("versions", versionId);`,
      errors: [
        {
          message:
            "versions rows hold a machine's state (state), and deleting one skips the machine: a pending timer, a refund or a link never happens. Send it to a final state (a deletion is a transition, like a project's DELETE), or from internal code `<machine>.purge(ctx, id)`, which cancels its timers and records it.",
        },
      ],
    },
    { code: `await ctx.db.delete(projectId);`, errors: [{ messageId: "delete", data: { table: "projects", owned: "state" } }] },
    // A value whose type allows any field, on a machine's table: it could hold the state.
    {
      code: `declare const value: Record<string, unknown>; await ctx.db.patch(projectId, value);`,
      errors: [{ messageId: "unresolved", data: { method: "patch", why: "writes a value whose type allows any field, on projects" } }],
    },
    {
      code: `declare const value: any; await ctx.db.patch("versions", versionId, value);`,
      errors: [{ messageId: "unresolved", data: { method: "patch", why: "writes a value whose type allows any field, on versions" } }],
    },
  ]),
});
