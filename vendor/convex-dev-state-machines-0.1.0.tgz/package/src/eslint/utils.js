// Shared helpers for the machines rules: walking the AST, and asking
// TypeScript when the file has type information. Every rule works without
// types. Types let it see further: which tables hold a machine (read off the
// app's DataModel), an ID's table, a spread's fields, a union imported from
// another file.

/** A machine's state field is named `state`, or `<name>State`. */
export const isStateName = (name) => name === "state" || (typeof name === "string" && name.endsWith("State"));

/** Its timers sit beside it: `stateTimers`, or `<name>StateTimers`. */
export const isTimersName = (name) => typeof name === "string" && name.endsWith("Timers") && isStateName(name.slice(0, -"Timers".length));

/** What only the library writes on a machine's row: its state, and its timers. */
export const isOwnedName = (name) => isStateName(name) || isTimersName(name);

const WRAPPERS = new Set([
  "TSAsExpression",
  "TSNonNullExpression",
  "TSSatisfiesExpression",
  "TSTypeAssertion",
  "TSInstantiationExpression",
  "ChainExpression",
]);

/** `(ctx.db as unknown as Writer)!` is `ctx.db`. */
export function unwrap(node) {
  while (node && WRAPPERS.has(node.type)) node = node.expression;
  return node;
}

/** A string the code spells out: "x", `x`, or a const that holds one. */
export function staticString(node, context, depth = 0) {
  node = unwrap(node);
  if (!node || depth > 5) return null;
  if (node.type === "Literal" && typeof node.value === "string") return node.value;
  if (node.type === "TemplateLiteral" && node.expressions.length === 0) return node.quasis[0].value.cooked;
  if (node.type === "Identifier") {
    const init = initOf(context, node);
    if (init) return staticString(init, context, depth + 1);
  }
  return null;
}

/** A property's name: `{ a: 1 }`, `{ "a": 1 }`, `{ ["a"]: 1 }`, `{ [KEY]: 1 }` with a const KEY. */
export function keyName(property, context) {
  if (!property.computed) {
    if (property.key.type === "Identifier") return property.key.name;
    if (property.key.type === "Literal") return String(property.key.value);
    return null;
  }
  return staticString(property.key, context);
}

/** A member's name: `a.b`, `a["b"]`. */
export function memberName(member, context) {
  if (!member.computed) return member.property.type === "Identifier" ? member.property.name : null;
  return staticString(member.property, context);
}

/** The variable an identifier refers to, innermost scope first. */
export function variableOf(context, identifier) {
  for (let scope = context.sourceCode.getScope(identifier); scope; scope = scope.upper) {
    const found = scope.set.get(identifier.name);
    if (found) return found;
  }
  return null;
}

/**
 * Where a binding's value comes from: its declarator's init (none for a
 * parameter), and the keys destructured on the way, outermost first.
 * `const { db: { patch } } = ctx` is `{ init: ctx, path: ["db", "patch"] }`.
 */
export function bindingOf(variable) {
  const def = variable?.defs.length === 1 ? variable.defs[0] : null;
  if (!def || (def.type !== "Variable" && def.type !== "Parameter")) return null;
  const path = [];
  let node = def.name;
  for (;;) {
    const parent = node.parent;
    if (parent?.type === "Property" && parent.value === node && parent.parent.type === "ObjectPattern") {
      const key = parent.computed ? null : keyName(parent, null);
      if (key === null) return null;
      path.unshift(key);
      node = parent.parent;
    } else if (parent?.type === "AssignmentPattern" && parent.left === node) {
      node = parent;
    } else break;
  }
  if (def.type === "Parameter") return { path, init: null, reassigned: isReassigned(variable) };
  if (def.node.id !== node) return null; // an array pattern or a rest element
  return { path, init: def.node.init, reassigned: isReassigned(variable) };
}

const isReassigned = (variable) => variable.references.some((ref) => ref.isWrite() && !ref.init);

/** The value a variable was declared with, if it's never reassigned. */
export function initOf(context, identifier) {
  const binding = bindingOf(variableOf(context, identifier));
  return binding && !binding.path.length && !binding.reassigned ? binding.init : null;
}

/** The import an identifier comes from, as `name` and `source`, or null. */
export function importOf(context, identifier) {
  const def = variableOf(context, identifier)?.defs[0];
  if (def?.type !== "ImportBinding" || def.parent.type !== "ImportDeclaration") return null;
  return { name: identifier.name, source: def.parent.source.value };
}

/** The node's source, shortened for a message. */
export function textOf(context, node, max = 40) {
  const text = context.sourceCode.getText(node).replace(/\s+/g, " ");
  return text.length > max ? `${text.slice(0, max - 3)}...` : text;
}

// ------------------------------------------------------------------ Types

const ANY_OR_UNKNOWN = 1 | 2; // ts.TypeFlags.Any | ts.TypeFlags.Unknown

/**
 * TypeScript's view of the file, when the config gives the parser a project
 * (`parserOptions.projectService`). Null otherwise.
 */
export function typesOf(context) {
  const services = context.sourceCode.parserServices;
  if (!services?.program || !services.esTreeNodeToTSNodeMap) return null;
  const checker = services.program.getTypeChecker();
  return {
    checker,
    program: services.program,
    typeAt: (node) => checker.getTypeAtLocation(services.esTreeNodeToTSNodeMap.get(node)),
    typeOfSymbol: (symbol) => checker.getTypeOfSymbol(symbol),
  };
}

/**
 * Each table's state fields, and their timer fields, read off the app's
 * DataModel: the nearest `_generated/dataModel.d.ts` above the linted file. A
 * state field is named `state` or `<name>State` and holds a union of objects
 * tagged with a string `kind`, which is what `defineMachine` and the catalog
 * require. Its timers are `<field>Timers`, beside it. Null when there's no
 * type information, or no data model to read.
 */
export function stateFieldsOf(types, filename) {
  if (!types) return null;
  const files = new Map(types.program.getSourceFiles().map((file) => [file.fileName, file]));
  let dir = filename.slice(0, filename.lastIndexOf("/"));
  let file;
  while (dir && !(file = files.get(`${dir}/_generated/dataModel.d.ts`))) dir = dir.slice(0, dir.lastIndexOf("/"));
  const module = file && types.checker.getSymbolAtLocation(file);
  const dataModel = module && types.checker.getExportsOfModule(module).find((symbol) => symbol.name === "DataModel");
  if (!dataModel) return null;
  const owned = new Map();
  const model = types.checker.getDeclaredTypeOfSymbol(dataModel);
  for (const table of model.getProperties()) {
    const document = types.typeOfSymbol(table).getProperty("document");
    if (!document) continue;
    const properties = types.typeOfSymbol(document).getProperties();
    const fields = properties.filter((field) => isStateName(field.name) && isTaggedUnion(types, types.typeOfSymbol(field))).map((field) => field.name);
    const timers = fields.map((field) => `${field}Timers`).filter((name) => properties.some((field) => field.name === name));
    if (fields.length) owned.set(table.name, [...fields, ...timers]);
  }
  return owned;
}

/** A union of objects each with a string-literal `kind` (or one such object). */
function isTaggedUnion(types, type) {
  return partsOf(type).every((part) => {
    const kind = part.getProperty("kind");
    return kind && types.typeOfSymbol(kind).isStringLiteral();
  });
}

const partsOf = (type) => (type.isUnion() ? type.types : [type]);

/** The string literals a type can be: "projects", or "a" | "b". Null for a plain string. */
export function literalsOf(types, type) {
  const values = [];
  for (const part of partsOf(type)) {
    if (!part.isStringLiteral()) return null;
    values.push(part.value);
  }
  return values.length ? values : null;
}

/** The string literals a node's type can be. */
export function literalsAt(types, node) {
  return types ? literalsOf(types, types.typeAt(node)) : null;
}

/** The tables an ID's type names: `Id<"projects">` is a string branded with `__tableName`. */
export function tablesOfId(types, node) {
  if (!types) return null;
  const type = types.checker.getNonNullableType(types.typeAt(node));
  const brand = type.getProperty("__tableName");
  return brand ? literalsOf(types, types.typeOfSymbol(brand)) : null;
}

/** Whether a value's type has a property, in any member of a union. `any` has none. */
export function typeHas(types, node, key) {
  const type = types.typeAt(node);
  if (type.flags & ANY_OR_UNKNOWN) return false;
  return partsOf(type).some((part) => !!types.checker.getApparentType(part).getProperty(key));
}

/** Whether a value's type says nothing about its keys: any, unknown, or an index signature (`Record<string, unknown>`). */
export function isLoose(types, node) {
  if (!types) return false;
  const type = types.typeAt(node);
  return !!(type.flags & ANY_OR_UNKNOWN) || partsOf(type).some((part) => types.checker.getIndexInfosOfType(part).length > 0);
}

/** Whether a node's type looks like a Convex db writer, guarded or not. */
export function looksLikeDb(types, node) {
  if (!types) return false;
  const type = types.checker.getNonNullableType(types.typeAt(node));
  if (type.flags & ANY_OR_UNKNOWN) return false;
  return ["get", "query", "insert", "patch", "replace", "delete"].every((name) => !!type.getProperty(name));
}

/**
 * A Convex validator, read off its type: `{ kind, optional, members, fields }`.
 * Validator classes carry `kind` and `isOptional` as literal types, a
 * union's `members` as a tuple and an object's `fields` as an object type.
 */
export function validatorFromType(types, type, depth = 0) {
  const prop = (name) => {
    const symbol = type.getProperty(name);
    return symbol ? types.typeOfSymbol(symbol) : null;
  };
  const kind = prop("kind");
  if (!kind?.isStringLiteral()) return { kind: null };
  const view = { kind: kind.value, optional: prop("isOptional")?.isStringLiteral() && prop("isOptional").value === "optional" ? "optional" : null };
  if (depth > 3) return view;
  if (view.kind === "union") {
    const members = prop("members");
    const list = members && types.checker.isTupleType(members) ? types.checker.getTypeArguments(members) : [];
    view.members = list.map((member) => validatorFromType(types, member, depth + 1));
    if (!view.optional && view.members.some((member) => member.kind === "null")) view.optional = "nullable";
  }
  if (view.kind === "object") view.fields = fieldsFromType(types, prop("fields"), depth + 1);
  if (view.kind === "array" && prop("element")) view.element = validatorFromType(types, prop("element"), depth + 1);
  return view;
}

/** An object of validators (`{ name: v.string() }`), read off its type. */
export function fieldsFromType(types, type, depth = 0) {
  if (!type || type.flags & ANY_OR_UNKNOWN) return null;
  return type.getProperties().map((symbol) => ({
    name: symbol.name,
    view: validatorFromType(types, types.typeOfSymbol(symbol), depth),
  }));
}
