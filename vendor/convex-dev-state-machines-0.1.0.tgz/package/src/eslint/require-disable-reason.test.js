import { Linter } from "eslint";
import tseslint from "typescript-eslint";
import { describe, expect, test } from "vitest";
import machines from "./index.js";

// The escape hatch end to end, with the rules on as the root config
// has them: a disable with a reason turns a machines rule off for that line,
// and one without a reason, or a bare one, is an error itself.

const linter = new Linter({ configType: "flat" });
const config = [
  {
    files: ["**/*.ts"],
    languageOptions: { parser: tseslint.parser },
    plugins: { machines },
    rules: {
      "machines/no-optional-on-machine-tables": "error",
      "machines/no-direct-state-writes": "error",
      "machines/require-disable-reason": "error",
      "no-console": "error",
    },
  },
];
const lint = (code) =>
  linter.verify(code, config, "convex/file.ts").map(({ ruleId, line, message }) => ({ ruleId, line, message }));

const write = `await ctx.db.patch("projects", id, { state: { kind: "noApp" } });`;

describe("require-disable-reason", () => {
  test("a disable with a reason turns the rule off for its line", () => {
    expect(lint(`// eslint-disable-next-line machines/no-direct-state-writes -- one-off backfill, #42\n${write}`)).toEqual([]);
    expect(
      lint(`defineSchema({
        versions: defineTable({
          state: versionState,
          // eslint-disable-next-line machines/no-optional-on-machine-tables -- the kid's own label, in any state
          nickname: v.optional(v.string()),
        }),
      });`),
    ).toEqual([]);
  });

  test("without a reason, the disable is the error", () => {
    expect(lint(`// eslint-disable-next-line machines/no-direct-state-writes\n${write}`)).toEqual([
      {
        ruleId: "machines/require-disable-reason",
        line: 1,
        message:
          "Say why this turns off machines/no-direct-state-writes: `-- <reason>` at the end of the comment. If there's no good reason, fix the code instead.",
      },
    ]);
    expect(lint(`${write} // eslint-disable-line machines/no-direct-state-writes`)).toMatchObject([
      { ruleId: "machines/require-disable-reason", line: 1 },
    ]);
    expect(lint(`/* eslint-disable machines/no-direct-state-writes, no-console */\n${write}\nconsole.log(1);`)).toEqual([
      {
        ruleId: "machines/require-disable-reason",
        line: 1,
        message: expect.stringContaining("Say why this turns off machines/no-direct-state-writes:"),
      },
    ]);
  });

  test("a bare disable turns the machines rules off too, so it needs a reason as well", () => {
    const blanket =
      "A bare eslint-disable turns off the machines rules too. Name the rules it's for, and say why: `-- <reason>`.";
    expect(lint(`// eslint-disable-next-line\n${write}`)).toEqual([
      { ruleId: "machines/require-disable-reason", line: 1, message: blanket },
    ]);
    expect(lint(`${write} // eslint-disable-line`)).toEqual([
      { ruleId: "machines/require-disable-reason", line: 1, message: blanket },
    ]);
    expect(lint(`/* eslint-disable */\n${write}`)).toEqual([
      { ruleId: "machines/require-disable-reason", line: 1, message: blanket },
    ]);
    expect(lint(`/* eslint-disable -- generated */\n${write}`)).toEqual([]);
  });

  test("a disable that names only other rules is left alone", () => {
    expect(lint(`// eslint-disable-next-line no-console\nconsole.log(1);`)).toEqual([]);
  });
});
