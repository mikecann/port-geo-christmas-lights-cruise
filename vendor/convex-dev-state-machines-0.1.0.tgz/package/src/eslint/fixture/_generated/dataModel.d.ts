// The fixture's data model, as convex codegen writes one for an app: what
// the rules read, with types, to find the tables that hold a machine.
import type { GenericId } from "convex/values";

type ProjectState = { kind: "noApp" } | { kind: "ready"; current: GenericId<"versions"> };
type VersionState = { kind: "building"; model: string } | { kind: "ready"; model: string; builtAt: number };

export type DataModel = {
  accounts: { document: { _id: GenericId<"accounts">; _creationTime: number; name: string; credits: number } };
  projects: { document: { _id: GenericId<"projects">; _creationTime: number; accountId: GenericId<"accounts">; name: string; state: ProjectState } };
  versions: {
    document: {
      _id: GenericId<"versions">;
      _creationTime: number;
      projectId: GenericId<"projects">;
      state: VersionState;
      stateTimers: { event: string; dueAt: number; job: GenericId<"_scheduled_functions"> }[];
    };
  };
  // A plain `state` that isn't a machine's: a string.
  drafts: { document: { _id: GenericId<"drafts">; _creationTime: number; state: string } };
};
