// RuleTester's typed cases are linted as this file (testing.js), each with its own code.
