import { v } from "convex/values";

// A state union in another module, for the type-aware cases: only its type
// tells a schema file that imports it that it's a state union.
export const orderState = v.union(
  v.object({ kind: v.literal("open") }),
  v.object({ kind: v.literal("shipped"), trackingCode: v.string() }),
);
