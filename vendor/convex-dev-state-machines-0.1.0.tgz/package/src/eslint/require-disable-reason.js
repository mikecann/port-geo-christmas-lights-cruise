// The machines rules have an escape hatch, an eslint-disable comment, but it
// has to say why: `// eslint-disable-next-line machines/<rule> -- <reason>`.
// A bare `eslint-disable` with no rule names turns these rules off too, so
// it needs a reason as well. Comments that name only other rules are left
// alone.

export default {
  meta: {
    type: "problem",
    docs: { description: "An eslint-disable that covers a machines rule must say why, after `--`." },
    schema: [],
    messages: {
      named:
        "Say why this turns off {{rules}}: `-- <reason>` at the end of the comment. If there's no good reason, fix the code instead.",
      blanket:
        "A bare eslint-disable turns off the machines rules too. Name the rules it's for, and say why: `-- <reason>`.",
    },
  },

  create(context) {
    const prefixes = ["machines/", `${context.id.split("/")[0]}/`];
    return {
      Program() {
        for (const directive of context.sourceCode.getDisableDirectives().directives) {
          if (directive.type === "enable" || directive.justification.trim()) continue;
          const rules = directive.value
            .split(",")
            .map((rule) => rule.trim())
            .filter(Boolean);
          const ours = rules.filter((rule) => prefixes.some((prefix) => rule.startsWith(prefix)));
          if (rules.length && !ours.length) continue;
          const { start, end } = directive.node.loc;
          // A bare `eslint-disable` or `eslint-disable-line` would also
          // silence this report if it sat on the comment, so it sits one
          // column before the directive starts.
          const column = directive.type === "disable-line" ? -1 : start.column - 1;
          context.report({
            loc: rules.length ? directive.node.loc : { start: { line: start.line, column }, end },
            messageId: rules.length ? "named" : "blanket",
            data: { rules: ours.join(", ") },
          });
        }
      },
    };
  },
};
