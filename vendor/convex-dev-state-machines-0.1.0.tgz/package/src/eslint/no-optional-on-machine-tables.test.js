import rule from "./no-optional-on-machine-tables.js";
import { syntaxTester, typed, typedTester } from "./testing.js";

// The mistakes an agent makes in the schema when a state needs more data:
// an optional or nullable field next to the machine's union, instead of a
// field in that state's member. Without types, `state: versionState` is a
// machine's state by its name; with them, by the union's type.

// convex/schema.ts as it is.
const schema = `import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { projectState, versionState } from "./states";

export default defineSchema({
  accounts: defineTable({
    name: v.string(),
    credits: v.number(),
  }),
  projects: defineTable({
    accountId: v.id("accounts"),
    name: v.string(),
    nextNumber: v.number(),
    state: projectState,
  })
    .index("by_account", ["accountId"])
    .index("by_state", ["state.kind"]),
  versions: defineTable({
    projectId: v.id("projects"),
    number: v.number(),
    purpose: v.union(v.literal("create"), v.literal("edit")),
    request: v.string(),
    cost: v.number(),
    state: versionState,
  })
    .index("by_project", ["projectId", "number"])
    .index("by_state", ["state.kind"]),
});`;

// The versions table with one more field.
const versionsWith = (field) => `defineSchema({
  versions: defineTable({
    projectId: v.id("projects"),
    cost: v.number(),
    ${field}
    state: versionState,
  }).index("by_state", ["state.kind"]),
});`;

const optional = (path, how = "optional") => ({
  messageId: "optional",
  data: {
    path,
    how,
    owner: "a machine's state (versions.state)",
    union: "versionState",
  },
});

syntaxTester.run("no-optional-on-machine-tables", rule, {
  valid: [
    schema,
    // Common fields every state needs are required.
    versionsWith(`thumbnailUrl: v.string(),`),
    // Optional fields on a table no machine holds are the app's business.
    `defineSchema({ accounts: defineTable({ name: v.string(), avatarUrl: v.optional(v.string()) }) });`,
    // State-specific data goes in that state's member, optional or not.
    `const versionState = v.union(
      v.object({ kind: v.literal("building"), model: v.string() }),
      v.object({ kind: v.literal("failed"), model: v.string(), error: v.string(), hint: v.optional(v.string()) }),
    );
    defineSchema({ versions: defineTable({ projectId: v.id("projects"), state: versionState }) });`,
    // A row that is the union, with its shared fields required, and
    // optional data in one state's member.
    `const ticket = v.union(
      v.object({ kind: v.literal("open"), title: v.string(), rev: v.number(), openedBy: v.string(), assignee: v.optional(v.string()) }),
      v.object({ kind: v.literal("closed"), title: v.string(), rev: v.number(), resolution: v.string() }),
    );
    defineSchema({ tickets: defineTable(ticket).index("by_kind", ["kind"]) });`,
    // Required in one state and optional in another is a real per-state
    // shape: an open ticket always has an assignee, a closed one may not.
    `const ticket = v.union(
      v.object({ kind: v.literal("open"), title: v.string(), rev: v.number(), assignee: v.string() }),
      v.object({ kind: v.literal("closed"), title: v.string(), rev: v.number(), assignee: v.optional(v.string()) }),
    );
    defineSchema({ tickets: defineTable(ticket) });`,
    // Data several states share, repeated through a spread (in states.ts
    // the three ends that refund each have `refunded`).
    `const ended = { refunded: v.number() };
    const versionState = v.union(
      v.object({ kind: v.literal("building"), model: v.string() }),
      v.object({ kind: v.literal("failed"), model: v.string(), error: v.string(), ...ended }),
      v.object({ kind: v.literal("cancelled"), ...ended }),
    );`,
    // Known misses: shapes that aren't optional but can still carry one
    // state's data on every row (a "" sentinel, an empty array). Only review
    // catches those.
    versionsWith(`errorMessage: v.string(),`),
    versionsWith(`errors: v.array(v.string()),`),
    // Items and members with every field required.
    versionsWith(`steps: v.array(v.object({ name: v.string(), at: v.number() })),`),
    versionsWith(`source: v.union(v.object({ upload: v.id("_storage") }), v.object({ url: v.string() })),`),
    // A record or v.any() on a table no machine holds is the app's business.
    `defineSchema({ accounts: defineTable({ name: v.string(), settings: v.record(v.string(), v.boolean()), raw: v.any() }) });`,
    // Two machines on one row (the lamps fixture).
    `defineSchema({ lamps: defineTable({ name: v.string(), powerState, colorState }) });`,
    // A union of objects without a kind literal isn't a state union.
    `defineSchema({ events: defineTable({ body: v.union(v.object({ text: v.string() }), v.object({ image: v.id("_storage") })), note: v.optional(v.string()) }) });`,
    // A field named `state` that the file shows isn't a union is the app's.
    `defineSchema({ drafts: defineTable({ state: v.string(), publishedAt: v.optional(v.number()) }) });`,
  ],
  invalid: [
    // The agent's first instinct: a failed build's message, on every version.
    { code: versionsWith(`errorMessage: v.optional(v.string()),`), errors: [optional("versions.errorMessage")] },
    // Nullable, three ways.
    {
      code: versionsWith(`finishedAt: v.union(v.number(), v.null()),`),
      errors: [optional("versions.finishedAt", "nullable")],
    },
    {
      code: versionsWith(`previewUrl: v.nullable(v.string()),`),
      errors: [optional("versions.previewUrl", "nullable")],
    },
    {
      code: versionsWith(`previewUrl: nullable(v.string()),`),
      errors: [optional("versions.previewUrl", "nullable")],
    },
    // The method form, and a helper const.
    { code: versionsWith(`retries: v.number().optional(),`), errors: [optional("versions.retries")] },
    {
      code: `const maybeError = v.optional(v.string());\n${versionsWith(`lastError: maybeError,`)}`,
      errors: [optional("versions.lastError")],
    },
    // Hidden in a shared field set, spread in.
    {
      code: `const audit = { updatedAt: v.number(), failedAt: v.optional(v.number()) };\n${versionsWith(`...audit,`)}`,
      errors: [optional("versions.failedAt")],
    },
    // Nested in a plain object.
    {
      code: versionsWith(`meta: v.object({ startedAt: v.number(), failedAt: v.optional(v.number()) }),`),
      errors: [optional("versions.meta.failedAt")],
    },
    // However deep: an array's items, a union's members.
    {
      code: versionsWith(`steps: v.array(v.object({ name: v.string(), failedAt: v.optional(v.number()) })),`),
      errors: [optional("versions.steps[].failedAt")],
    },
    {
      code: versionsWith(`source: v.union(v.object({ upload: v.id("_storage") }), v.object({ url: v.string(), note: v.optional(v.string()) })),`),
      errors: [optional("versions.source.note")],
    },
    // A shape that holds anything, on a machine's table.
    {
      code: versionsWith(`extra: v.any(),`),
      errors: [{ messageId: "loose", data: { path: "versions.extra", how: "v.any()", owner: "a machine's state (versions.state)", union: "versionState" } }],
    },
    {
      code: versionsWith(`flags: v.record(v.string(), v.boolean()),`),
      errors: [{ messageId: "loose", data: { path: "versions.flags", how: "a v.record", owner: "a machine's state (versions.state)", union: "versionState" } }],
    },
    {
      code: versionsWith(`meta: v.object({ history: v.array(v.any()) }),`),
      errors: [{ messageId: "loose", data: { path: "versions.meta.history[]", how: "v.any()", owner: "a machine's state (versions.state)", union: "versionState" } }],
    },
    // The full message, on the project's table.
    {
      code: `defineSchema({ projects: defineTable({ name: v.string(), state: projectState, currentVersion: v.optional(v.id("versions")) }) });`,
      errors: [
        {
          message:
            "projects.currentVersion is optional, on a table that holds a machine's state (projects.state). If one state has it, put it in that state's member of projectState; if several do, repeat it in each of their members with a shared spread; if every state does, make it a required field here. If it changes every few seconds (a driver's live location), give it a table of its own, keyed by this row's ID: here or in a state, every change rewrites the row the machine and its readers read. Only if it's app data that's optional in every state, keep it and say why: `// eslint-disable-next-line machines/no-optional-on-machine-tables -- <reason>`.",
        },
      ],
    },
    // Making the state itself optional.
    {
      code: `import { projectState } from "./states";
        defineSchema({ projects: defineTable({ name: v.string(), state: v.optional(projectState) }) });`,
      errors: [
        {
          message:
            "projects.state holds a machine's state, so it must be required: every row is in exactly one state. For 'not started yet', add a state to projectState in ./states instead.",
        },
      ],
    },
    // The scenario that found it: a live position next to a delivery's state.
    {
      code: `defineSchema({
        deliveries: defineTable({
          order: v.string(),
          state: v.union(v.object({ kind: v.literal("waiting") }), v.object({ kind: v.literal("onTheRoad"), driver: v.string() })),
          location: v.optional(v.object({ lat: v.number(), lng: v.number(), at: v.number() })),
        }),
      });`,
      errors: [{ messageId: "optional", data: { path: "deliveries.location", how: "optional", owner: "a machine's state (deliveries.state)", union: "deliveries.state" } }],
    },
    // A union a helper builds, or one imported from another file: without
    // types, the field's name says it's a machine's state.
    {
      code: `defineSchema({ orders: defineTable({ state: states(["open", "shipped"]), trackingCode: v.optional(v.string()) }) });`,
      errors: [{ messageId: "optional", data: { path: "orders.trackingCode", how: "optional", owner: "a machine's state (orders.state)", union: "orders.state" } }],
    },
    {
      code: `import { orderState } from "./orderStates";
        defineSchema({ orders: defineTable({ customer: v.string(), state: orderState, trackingCode: v.optional(v.string()) }) });`,
      errors: [{ messageId: "optional", data: { path: "orders.trackingCode", how: "optional", owner: "a machine's state (orders.state)", union: "orderState in ./orderStates" } }],
    },
    // A new table with its union written inline: the union's shape says it holds states.
    {
      code: `defineSchema({
        orders: defineTable({
          customer: v.string(),
          state: v.union(
            v.object({ kind: v.literal("open") }),
            v.object({ kind: v.literal("shipped"), trackingCode: v.string() }),
          ),
          trackingCode: v.optional(v.string()),
        }),
      });`,
      errors: [
        {
          messageId: "optional",
          data: { path: "orders.trackingCode", how: "optional", owner: "a machine's state (orders.state)", union: "orders.state" },
        },
      ],
    },
    // A row that is the union, with an optional field in every state.
    {
      code: `const ticket = v.union(
        v.object({ kind: v.literal("open"), title: v.string(), rev: v.number(), openedBy: v.string(), assignee: v.optional(v.string()) }),
        v.object({ kind: v.literal("closed"), title: v.string(), rev: v.number(), resolution: v.string(), assignee: v.optional(v.string()) }),
      );
      defineSchema({ tickets: defineTable(ticket) });`,
      errors: [
        {
          line: 2,
          message:
            "assignee is optional in every member of ticket, so it isn't any state's data. If every state has it, make it required; if only some do, keep it in just those states' members, with a shared spread. Only if it's app data that's optional in every state, keep it and say why: `// eslint-disable-next-line machines/no-optional-on-machine-tables -- <reason>`.",
        },
      ],
    },
    // The agent's second instinct, after the first is refused: the same
    // field moved inside the union, optional in every member (states.ts).
    {
      code: `export const versionState = v.union(
        v.object({ kind: v.literal("building"), model: v.string(), errorMessage: v.optional(v.string()) }),
        v.object({ kind: v.literal("ready"), model: v.string(), builtAt: v.number(), errorMessage: v.optional(v.string()) }),
        v.object({ kind: v.literal("failed"), model: v.string(), error: v.string(), errorMessage: v.optional(v.string()) }),
      );`,
      errors: [{ messageId: "optionalEverywhere", line: 2, data: { field: "errorMessage", how: "optional", union: "versionState" } }],
    },
    // ... or through a spread every member shares, or nullable in each.
    {
      code: `const loose = { note: v.optional(v.string()) };
        const projectState = v.union(
          v.object({ kind: v.literal("noApp"), ...loose }),
          v.object({ kind: v.literal("ready"), current: v.id("versions"), ...loose }),
        );`,
      errors: [{ messageId: "optionalEverywhere", line: 3, data: { field: "note", how: "optional", union: "projectState" } }],
    },
    {
      code: `defineSchema({
        orders: defineTable({
          state: v.union(
            v.object({ kind: v.literal("open"), shippedAt: v.union(v.number(), v.null()) }),
            v.object({ kind: v.literal("shipped"), shippedAt: v.nullable(v.number()) }),
          ),
        }),
      });`,
      errors: [{ messageId: "optionalEverywhere", data: { field: "shippedAt", how: "nullable", union: "orders.state" } }],
    },
  ],
});

// With types: a union imported from another module is a state union by its type.
const prelude = `import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { orderState } from "./states";`;

typedTester.run("no-optional-on-machine-tables, with types", rule, {
  valid: typed(prelude, [`defineSchema({ orders: defineTable({ customer: v.string(), state: orderState }) });`]),
  invalid: typed(prelude, [
    {
      code: `defineSchema({ orders: defineTable({ customer: v.string(), state: orderState, trackingCode: v.optional(v.string()) }) });`,
      errors: [
        {
          messageId: "optional",
          data: { path: "orders.trackingCode", how: "optional", owner: "a machine's state (orders.state)", union: "orderState in ./states" },
        },
      ],
    },
    // An array of objects imported from elsewhere: its items' type says one field is optional.
    {
      code: `import type { VArray, VObject, VString, VFloat64 } from "convex/values";
        declare const steps: VArray<{ name: string; at?: number }[], VObject<{ name: string; at?: number }, { name: VString<string, "required">; at: VFloat64<number | undefined, "optional"> }>>;
        defineSchema({ orders: defineTable({ state: orderState, steps }) });`,
      errors: [{ messageId: "optional", data: { path: "orders.steps[].at", how: "optional", owner: "a machine's state (orders.state)", union: "orderState in ./states" } }],
    },
    // A helper that returns an optional validator: only its type says so.
    {
      code: `const maybe = <T extends ReturnType<typeof v.string>>(x: T) => v.optional(x);
        function looseString() { return maybe(v.string()); }
        defineSchema({ orders: defineTable({ state: orderState, note: looseString() }) });`,
      errors: [{ messageId: "optional" }],
    },
  ]),
});
