import { initOf, keyName, memberName, staticString, textOf, unwrap, variableOf } from "./utils.js";

// Two ways round the internal brand that only deliberate code takes. The
// types and the runtime can't refuse them, as Convex lets any server
// function call an internal one, so this rule does:
//
// - The catalog's delivery: `machines.deliver`, `internal.machines.deliver`,
//   or "machines:deliver". Called directly, it forges a link's event, `from`
//   and all, or fires a timer before its time. Only convex/machines.ts
//   registers it.
// - `_handler`: Convex keeps a registered function's whole handler there,
//   builder and all, and calling it runs the builder on whatever ctx it's
//   given, the internal brand included. Only tests reach for it.
//
// Each check can be turned off where it's needed: `{ deliver: false }` for
// convex/machines.ts, and the rule off for tests.

// `machines`, imported as another name, a const that holds it, or `internal.machines`.
function isCatalog(node, context, depth = 0) {
  node = unwrap(node);
  if (node?.type === "MemberExpression") return memberName(node, context) === "machines";
  if (node?.type !== "Identifier" || depth > 5) return false;
  if (node.name === "machines") return true;
  const def = variableOf(context, node)?.defs[0];
  if (def?.type === "ImportBinding") return def.node.imported?.name === "machines";
  const init = initOf(context, node);
  return init ? isCatalog(init, context, depth + 1) : false;
}

export default {
  meta: {
    type: "problem",
    docs: { description: "No direct call to the machines' delivery outside convex/machines.ts, and no `_handler` outside tests." },
    schema: [{ type: "object", properties: { deliver: { type: "boolean" }, handler: { type: "boolean" } }, additionalProperties: false }],
    messages: {
      deliver:
        "`{{text}}` is the machines' delivery. Called directly, it forges a link's event, sender and all, or fires a timer before its time. Send the machine an event with its send(), from the app's builders: only convex/machines.ts registers the delivery.",
      handler:
        "`_handler` runs a registered function's builder on whatever ctx it's given, the internal brand included. Call an internal function with ctx.runMutation or the scheduler, or build this one with the app's internalMutation: only tests reach for `_handler`.",
    },
  },

  create(context) {
    const { deliver = true, handler = true } = context.options[0] ?? {};
    const report = (node, messageId, text) => context.report({ node, messageId, data: { text } });
    return {
      MemberExpression(node) {
        const name = memberName(node, context);
        if (deliver && name === "deliver" && isCatalog(node.object, context)) report(node, "deliver", textOf(context, node));
        if (handler && name === "_handler") report(node.property, "handler");
      },
      // `const { deliver } = machines`, and `const { _handler } = fn`.
      VariableDeclarator(node) {
        if (node.id.type !== "ObjectPattern" || !node.init) return;
        for (const property of node.id.properties) {
          const key = property.type === "Property" ? keyName(property, context) : null;
          if (deliver && key === "deliver" && isCatalog(node.init, context)) report(property, "deliver", `{ deliver } = ${textOf(context, node.init)}`);
          if (handler && key === "_handler") report(property, "handler");
        }
      },
      // `makeFunctionReference("machines:deliver")`.
      CallExpression(node) {
        const callee = unwrap(node.callee);
        if (deliver && callee.type === "Identifier" && callee.name === "makeFunctionReference" && staticString(node.arguments[0], context) === "machines:deliver")
          report(node, "deliver", textOf(context, node));
      },
    };
  },
};
