import rule from "./no-brand-bypass.js";
import { syntaxTester } from "./testing.js";

// The two deliberate ways round the internal brand: a public mutation
// running the delivery itself, to
// forge a link's event or fire a timer early, and a registered function's
// `_handler`, which hands out the brand. convex/machines.ts registers the
// delivery (`{ deliver: false }`), and the tests are where `_handler` goes.

const forged = `{ machine: "project", id: projectId, event: "BUILD_SUCCEEDED", link: { machine: "version", id: versionId, depth: 0, budget: 100 } }`;

syntaxTester.run("no-brand-bypass", rule, {
  valid: [
    // Events go through the machine, from the app's builders.
    `await project.send(ctx, projectId, { type: "BUILD" });`,
    `await ctx.runMutation(internal.projects.report, { versionId, event, reportId });`,
    // The catalog's other parts.
    `export const { mutation, internalMutation } = machines;`,
    `await ctx.scheduler.runAfter(0, internal.machines.failedTimers, {});`,
    `const rows = await machines.failedTimers(ctx, {});`,
    // Something else's deliver, and a handler that isn't Convex's.
    `await runtime.deliver(ctx, args);`,
    `const { deliver } = options;`,
    `export const send = mutation({ args, handler: async (ctx) => null });`,
    `const ref = makeFunctionReference("projects:report");`,
    // convex/machines.ts registers the delivery.
    { code: `export const deliver = machines.internalMutation({ args: deliveryArgs, handler: machines.deliver });`, options: [{ deliver: false }] },
    { code: `defineMachines(schema, [project, version], { mutation, internalMutation, deliver: internal.machines.deliver });`, options: [{ deliver: false }] },
    // A test's way to the brand.
    { code: `const branded = await fn._handler(ctx, {});`, options: [{ handler: false }] },
  ],
  invalid: [
    // A forged link's event, and a timer fired early.
    { code: `await ctx.runMutation(internal.machines.deliver, ${forged});`, errors: [{ messageId: "deliver", data: { text: "internal.machines.deliver" } }] },
    {
      code: `await ctx.runMutation(internal.machines.deliver, { machine: "version", id: versionId, event: "TIMED_OUT", dueAt: timer.dueAt });`,
      errors: [{ messageId: "deliver" }],
    },
    // However it's spelled.
    { code: `await machines.deliver(ctx, ${forged});`, errors: [{ messageId: "deliver", data: { text: "machines.deliver" } }] },
    { code: `await ctx.runMutation(internal.machines["deliver"], args);`, errors: [{ messageId: "deliver" }] },
    { code: `const { deliver } = machines;`, errors: [{ messageId: "deliver", data: { text: "{ deliver } = machines" } }] },
    { code: `const { deliver } = internal.machines;`, errors: [{ messageId: "deliver" }] },
    { code: `import { machines as catalog } from "./machines";\nawait catalog.deliver(ctx, args);`, errors: [{ messageId: "deliver" }] },
    { code: `const catalog = machines;\nawait catalog.deliver(ctx, args);`, errors: [{ messageId: "deliver" }] },
    { code: `const ref = makeFunctionReference("machines:deliver");`, errors: [{ messageId: "deliver" }] },
    { code: "const ref = makeFunctionReference<\"mutation\">(`machines:deliver`);", errors: [{ messageId: "deliver" }] },
    // `_handler`, however it's reached.
    { code: `const branded = await internalMutation({ args: {}, handler: async (ctx) => ctx })._handler(ctx, {});`, errors: [{ messageId: "handler" }] },
    { code: `await fn["_handler"](ctx, {});`, errors: [{ messageId: "handler" }] },
    { code: `const { _handler } = fn;`, errors: [{ messageId: "handler" }] },
    // convex/machines.ts may register the delivery, but not reach for `_handler`.
    { code: `await fn._handler(ctx, {});`, options: [{ deliver: false }], errors: [{ messageId: "handler" }] },
    // And a test may reach for `_handler`, but not run the delivery outside the catalog.
    { code: `await machines.deliver(ctx, args);`, options: [{ handler: false }], errors: [{ messageId: "deliver" }] },
  ],
});
