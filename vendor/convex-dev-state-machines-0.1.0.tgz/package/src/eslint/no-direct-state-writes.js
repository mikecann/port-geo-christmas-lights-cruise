import {
  bindingOf,
  isLoose,
  isOwnedName,
  isTimersName,
  keyName,
  literalsAt,
  looksLikeDb,
  memberName,
  staticString,
  stateFieldsOf,
  tablesOfId,
  textOf,
  typeHas,
  typesOf,
  unwrap,
  variableOf,
} from "./utils.js";

// Only a machine changes its state, and its rows go through it. A db write
// that sets a machine's state field is refused, and so is an insert, replace
// or delete on a machine's table (each skips the machine: its start, its
// timers, its links), and any write to the library's own tables. Machine
// modules aren't exempt: an effect returns the next state and the library
// writes it, and the runtime guard refuses an effect's own write.
//
// Which tables hold a machine: with type information (convex/ is linted
// with it), the app's DataModel says, by the union's shape. Without it, a
// field named `state` or `<name>State` is taken to be one.
//
// What it follows: `ctx.db` and `db` however they're named, destructured or
// aliased (`const write = ctx.db.patch`), casts, computed keys with a const
// name, spreads, `Object.assign` and update objects filled in later, as far
// as the file shows them. With types it also reads an ID's table
// (`patch(projectId, ...)`) and the fields of anything spread or passed in.
// A write it can't read, it reports rather than passes: spread arguments,
// and with types, a value whose type allows any field on a machine's table.
// What it can't see: a key only known at runtime, a helper that wraps the
// db, and writes from another function. The runtime guard has those.

const WRITES = new Set(["insert", "patch", "replace", "delete"]);

const isObjectAssign = (node) =>
  node?.type === "CallExpression" &&
  node.callee.type === "MemberExpression" &&
  node.callee.object.type === "Identifier" &&
  node.callee.object.name === "Object" &&
  !node.callee.computed &&
  node.callee.property.name === "assign";

export default {
  meta: {
    type: "problem",
    docs: { description: "Only a machine writes its state and timers, and its rows go through it: no db writes to a machine's state, timers or row." },
    schema: [],
    messages: {
      patch:
        "This patch {{verb}} `{{key}}`{{via}}, which belongs to a machine on {{table}}. Only its machine changes it: send it an event, `<machine>.send(ctx, id, event)`. If no event does what you need, add a transition to the machine.",
      insert:
        "{{table}} rows hold a machine's state ({{owned}}), so they're born by an event: `<machine>.create(ctx, fields, event)` runs its start transition and arms its timers. Don't insert them directly.",
      replace:
        "A replace on {{table}} rewrites a machine's state ({{owned}}). Patch the app's own fields instead, and change the state by sending the machine an event.",
      delete:
        "{{table}} rows hold a machine's state ({{owned}}), and deleting one skips the machine: a pending timer, a refund or a link never happens. Send it to a final state (a deletion is a transition, like a project's DELETE), or from internal code `<machine>.purge(ctx, id)`, which cancels its timers and records it.",
      unknownTable:
        "This {{method}} {{verb}} `{{key}}`{{via}}, which by its name is a machine's state. If that's so, send the machine an event instead. If it isn't, name the table, `{{named}}`, so this rule can tell.",
      unresolved:
        "This {{method}} {{why}}, so this rule can't tell whether it writes a machine's state. Write the call out, `ctx.db.{{method}}(\"<table>\", id, value)`, with a value whose fields are in view or typed.",
    },
  },

  create(context) {
    const types = typesOf(context);
    // Each table's state fields, from the app's types; null without them.
    const owned = stateFieldsOf(types, context.filename);

    // `ctx.db`, `db`, `const db = ctx.db`, `const { db } = ctx`, `({ db }) =>`,
    // and anything typed as a db writer.
    function isDb(node, depth = 0) {
      node = unwrap(node);
      if (!node || depth > 5) return false;
      if (node.type === "MemberExpression" && memberName(node, context) === "db") return true;
      if (node.type === "Identifier") {
        if (node.name === "db" || node.name.endsWith("Db")) return true;
        const binding = bindingOf(variableOf(context, node));
        if (binding?.path.at(-1) === "db") return true;
        if (binding && !binding.path.length && binding.init && isDb(binding.init, depth + 1)) return true;
      }
      return looksLikeDb(types, node);
    }

    // The write method a call makes: `ctx.db.patch(...)`, `ctx.db["patch"](...)`,
    // or `patch(...)` after `const { patch } = ctx.db`, `const patch =
    // ctx.db.patch` or `ctx.db.patch.bind(ctx.db)`.
    function writeMethod(call) {
      const callee = unwrap(call.callee);
      if (callee.type === "MemberExpression") return methodOf(callee);
      if (callee.type !== "Identifier") return null;
      const binding = bindingOf(variableOf(context, callee));
      if (binding && !binding.path.length && !binding.reassigned) {
        let init = unwrap(binding.init);
        if (init?.type === "CallExpression" && init.callee.type === "MemberExpression" && memberName(init.callee, context) === "bind")
          init = unwrap(init.callee.object);
        return init?.type === "MemberExpression" ? methodOf(init) : null;
      }
      const name = binding?.path.at(-1);
      if (!WRITES.has(name)) return null;
      if (binding.path.length >= 2) return binding.path.at(-2) === "db" ? name : null;
      return binding.init && isDb(binding.init) ? name : null;
    }

    function methodOf(member) {
      const name = memberName(member, context);
      return WRITES.has(name) && isDb(member.object) ? name : null;
    }

    // The keys a written value has, from among `keys`: written out, spread
    // in from an object in the file, assigned later (`update.stage = ...`),
    // or (with types) in the type of whatever is spread or passed. Each is
    // reported where the call shows it: the property, the spread, or the
    // value passed.
    // `keys` null: the table's fields aren't known, so any key named like a state field.
    function keysIn(value, keys) {
      const found = new Map();
      const add = (key, node, verb, via) => {
        if ((keys ? keys.has(key) : isOwnedName(key)) && !found.has(key)) found.set(key, { key, node, verb, via });
      };
      collect(value, { at: value, via: "", keys, add, depth: 0 });
      if (types)
        for (const key of typedKeys(value, keys))
          if (!found.has(key) && typeHas(types, value, key)) add(key, value, "can write", " (its type has it)");
      return [...found.values()];
    }
    // The keys to look for in a value's type: the known ones, or its state-named properties.
    const typedKeys = (node, keys) =>
      keys ?? (types ? types.checker.getApparentType(types.typeAt(unwrap(node))).getProperties().map((p) => p.name).filter(isOwnedName) : []);

    function collect(node, { at, via, keys, add, depth }) {
      node = unwrap(node);
      if (!node || depth > 5) return;
      const deeper = { at, via, keys, add, depth: depth + 1 };
      if (node.type === "ObjectExpression") {
        for (const property of node.properties) {
          const here = depth ? at : property;
          if (property.type === "Property") {
            const name = keyName(property, context);
            if (name !== null) add(name, here, "writes", via);
            else if (types) for (const key of literalsAt(types, property.key) ?? []) add(key, here, "writes", via);
            continue;
          }
          const through = depth ? via : ` through \`${textOf(context, property)}\``;
          collect(property.argument, { ...deeper, at: here, via: through });
          if (types)
            for (const key of typedKeys(property.argument, keys))
              if (typeHas(types, unwrap(property.argument), key)) add(key, here, "can write", `${through} (its type has it)`);
        }
        return;
      }
      if (node.type === "ConditionalExpression") {
        collect(node.consequent, deeper);
        collect(node.alternate, deeper);
        return;
      }
      if (node.type === "LogicalExpression") {
        collect(node.left, deeper);
        collect(node.right, deeper);
        return;
      }
      if (isObjectAssign(node)) {
        for (const source of node.arguments) collect(source, deeper);
        return;
      }
      if (node.type !== "Identifier") return;
      const variable = variableOf(context, node);
      const binding = bindingOf(variable);
      const named = depth ? via : ` through \`${node.name}\``;
      if (binding?.init && !binding.path.length) collect(binding.init, { ...deeper, via: named });
      // `const update = {}; update.stage = next;`, or `Object.assign(update, { stage })`.
      for (const reference of variable?.references ?? []) {
        const parent = reference.identifier.parent;
        if (
          parent.type === "MemberExpression" &&
          parent.object === reference.identifier &&
          parent.parent.type === "AssignmentExpression" &&
          parent.parent.left === parent
        ) {
          const name = memberName(parent, context);
          if (name) add(name, at, "writes", named);
        }
        if (isObjectAssign(parent) && parent.arguments[0] === reference.identifier)
          for (const source of parent.arguments.slice(1)) collect(source, { ...deeper, via: named });
      }
    }

    return {
      CallExpression(call) {
        const method = writeMethod(call);
        if (!method) return;
        const args = call.arguments;
        const report = (messageId, data, node = call) => context.report({ node, messageId, data });
        if (args.some((arg) => arg.type === "SpreadElement")) return report("unresolved", { method, why: "passes its arguments with a spread" });
        // insert(table, value), patch/replace(table, id, value), delete(table, id),
        // or the older patch/replace(id, value) and delete(id).
        const named = method === "insert" || args.length >= (method === "delete" ? 2 : 3);
        const value = method === "insert" ? args[1] : method === "delete" ? null : named ? args[2] : args[1];
        const tables = named
          ? staticString(args[0], context) !== null
            ? [staticString(args[0], context)]
            : literalsAt(types, args[0])
          : tablesOfId(types, args[0]);

        // With types, the data model says which tables hold a machine. Without
        // them, a key named like a state field is taken to be one.
        const fields = tables && owned ? tables.flatMap((table) => owned.get(table) ?? []) : null;
        if (fields && !fields.length) return;
        const table = tables?.[0];
        const written = value ? keysIn(value, fields ? new Set(fields) : null) : [];
        if (method !== "patch") {
          // The message names the state fields; their timers go with them.
          const named = (fields ?? written.map((item) => item.key)).filter((key) => !isTimersName(key) || !(fields ?? []).includes(key.slice(0, -"Timers".length)));
          if (fields || written.length) report(method, { table: table ?? "this table", owned: named.join(", ") });
          return;
        }
        for (const { key, node, verb, via } of written)
          if (table) report("patch", { verb, via, key, table }, node);
          else report("unknownTable", { method, verb, via, key, named: 'ctx.db.patch("<table>", id, value)' }, node);
        // A machine's table, and a value whose type allows any field: it could hold the state.
        if (fields && !written.length && value && isLoose(types, unwrap(value))) report("unresolved", { method, why: `writes a value whose type allows any field, on ${table}` });
      },
    };
  },
};
