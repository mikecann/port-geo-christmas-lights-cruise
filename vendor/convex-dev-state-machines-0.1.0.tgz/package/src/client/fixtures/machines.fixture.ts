import { internalMutationGeneric, makeFunctionReference, mutationGeneric, type FunctionReference } from "convex/server";
import { v, type GenericId, type ObjectType } from "convex/values";
import { componentsGeneric } from "convex/server";
import type { ComponentApi } from "../../component/_generated/component.js";
import { defineMachine, defineMachines, deliveryArgs } from "../machine.js";
import schema from "./schema.fixture.js";

// The app's components, as an app's generated api would have them.
const components = componentsGeneric() as unknown as { stateMachines: ComponentApi };

// Machines on the fixture tables, for the library's tests. Two dots in the
// name, so none of this deploys.

// Two independent machines on one row, born by the same event.
export const power = defineMachine(
  schema,
  {
    name: "power",
    table: "lamps",
    field: "powerState",
    callers: { anyone: "Anyone can." },
    events: { anyone: { INSTALL: {}, TURN_ON: {}, TURN_OFF: {} } },
    states: {
      start: { on: { INSTALL: { to: "off" } } },
      // Two links to the row's other machine. Each finds its rows on the row as it is by then, so SHINE sees what WARM did.
      off: {
        on: {
          TURN_ON: {
            to: "on",
            effect: "switchOn",
            sends: [
              { machine: "color", event: "WARM", onRefused: "ignore" },
              { machine: "color", event: "SHINE", onRefused: "ignore" },
            ],
          },
        },
      },
      on: { on: { TURN_OFF: { to: "off" } } },
    },
  },
  {
    callers: { anyone: () => true },
    effects: { switchOn: async () => ({ kind: "on", since: Date.now() }) },
    links: {
      "color.WARM": ({ id, row }) => (row.colorState.kind === "white" ? id : []),
      "color.SHINE": ({ id, row }) => (row.colorState.kind === "warm" ? id : []),
    },
  },
);
export const color = defineMachine(
  schema,
  {
    name: "color",
    table: "lamps",
    field: "colorState",
    callers: { anyone: "Anyone can." },
    events: { anyone: { INSTALL: {}, PAINT: { hue: v.number() }, RESET: {} }, power: { WARM: {}, SHINE: {} } },
    states: {
      start: { on: { INSTALL: { to: "white" } } },
      white: { on: { PAINT: { to: "colored", effect: "paint" }, WARM: { to: "warm" } } },
      warm: { on: { SHINE: { to: "colored", effect: "shine" }, RESET: { to: "white" } } },
      colored: { on: { PAINT: { effect: "paint" }, RESET: { to: "white" } } },
    },
  },
  {
    callers: { anyone: () => true },
    effects: { paint: async (_ctx, { event }) => ({ kind: "colored", hue: event.hue }), shine: async () => ({ kind: "colored", hue: 40 }) },
  },
);

export const HEARTBEAT_MS = 10_000;
export const MAX_RUN_MS = 60_000;

// One transition shared by two states, as a plain constant spread into each.
// `as const` keeps its literal types; the diagram draws it from each state.
const cancellable = { CANCEL: { to: "failed", effect: "cancel" } } as const;

export const job = defineMachine(
  schema,
  {
    name: "job",
    table: "jobs",
    callers: { owner: "Only the job's owner can do that." },
    events: {
      owner: { SUBMIT: { retryAt: v.optional(v.number()) }, CANCEL: {} },
      // The worker's reports, from an internal mutation.
      server: { START: {}, HEARTBEAT: { note: v.string() }, FINISH: {} },
    },
    guards: { later: "It has no retry time.", retriesLeft: "It has had 3 attempts." },
    states: {
      // Born waiting, if it has a retry time, or else queued: a guarded start.
      start: { on: { SUBMIT: [{ to: "waiting", guard: "later", effect: "wait" }, { to: "queued" }] } },
      queued: { on: { START: { to: "running", effect: "start" }, ...cancellable } },
      running: {
        // Due at the time in the data, which a heartbeat moves; and a fixed one.
        timers: { STALLED: { at: "deadline" }, TOO_LONG: { after: MAX_RUN_MS } },
        on: {
          HEARTBEAT: { effect: "beat" },
          FINISH: { to: "done", effect: "finish" },
          // A timer that chooses, like any event.
          STALLED: [
            { to: "waiting", guard: "retriesLeft", effect: "backOff" },
            { to: "failed", effect: "giveUp" },
          ],
          TOO_LONG: { to: "failed", effect: "giveUp" },
        },
      },
      waiting: { timers: { RETRY: { at: "retryAt" } }, on: { RETRY: { to: "running", effect: "start" }, ...cancellable } },
      done: {},
      failed: {},
    },
  },
  {
    callers: { owner: async (ctx, { row }) => (await ctx.auth.getUserIdentity())?.subject === row.owner },
    guards: {
      later: (_ctx, { event }) => event.retryAt !== undefined,
      retriesLeft: (_ctx, { state }) => state.attempt < 3,
    },
    effects: {
      wait: async (_ctx, { event }) => ({ kind: "waiting", attempt: 0, retryAt: event.retryAt ?? Date.now() }),
      start: async (_ctx, { state }) => ({
        kind: "running",
        attempt: (state.kind === "waiting" ? state.attempt : 0) + 1,
        deadline: Date.now() + HEARTBEAT_MS,
        note: "",
      }),
      beat: async (_ctx, { state, event }) => ({ ...state, deadline: Date.now() + HEARTBEAT_MS, note: event.note }),
      finish: async (_ctx, { state }) => ({ kind: "done", attempt: state.attempt }),
      // 4, 16 seconds: the due time is the state's own data.
      backOff: async (_ctx, { state }) => ({ kind: "waiting", attempt: state.attempt, retryAt: Date.now() + 1_000 * 4 ** state.attempt }),
      giveUp: async (_ctx, { state, event }) => ({ kind: "failed", attempt: state.attempt, reason: event.type }),
      // From queued or waiting: the fragment's two states.
      cancel: async (_ctx, { state }) => ({ kind: "failed", attempt: state.kind === "waiting" ? state.attempt : 0, reason: "cancelled" }),
    },
  },
);

export const TICK_MS = 1_000;

// A timer whose step stays put is periodic: TICK is armed again from now
// each time. Its guard refuses once it's ticked enough, and the timer is
// spent. No history, so only the refusal is recorded.
export const poll = defineMachine(
  schema,
  {
    name: "poll",
    table: "polls",
    history: false,
    callers: { anyone: "Anyone can." },
    events: { anyone: { WATCH: { stopAt: v.number() }, STOP: {} } },
    guards: { more: "It has ticked enough." },
    states: {
      start: { on: { WATCH: { to: "watching", effect: "watch" } } },
      watching: { timers: { TICK: { after: TICK_MS } }, on: { TICK: { guard: "more", effect: "tick" }, STOP: { to: "stopped" } } },
      stopped: {},
    },
  },
  {
    callers: { anyone: () => true },
    guards: { more: (_ctx, { state }) => state.ticks < state.stopAt },
    effects: {
      watch: async (_ctx, { event }) => ({ kind: "watching", ticks: 0, stopAt: event.stopAt }),
      tick: async (_ctx, { state }) => ({ ...state, ticks: state.ticks + 1 }),
    },
  },
);

export const room = defineMachine(
  schema,
  {
    name: "room",
    table: "rooms",
    callers: { anyone: "Anyone can." },
    events: { anyone: { OPEN: { inside: v.number() }, CLOSE: {} }, guest: { GUEST_LEFT: {} } },
    states: {
      start: { on: { OPEN: { to: "open", effect: "open" } } },
      open: {
        on: {
          // Every guest, found by a query. The ones that left refuse, and the room closes anyway.
          CLOSE: { to: "closed", effect: "close", sends: [{ machine: "guest", event: "ROOM_CLOSED", onRefused: "ignore" }] },
          GUEST_LEFT: { effect: "countOut" },
        },
      },
      closed: {},
    },
  },
  {
    callers: { anyone: () => true },
    effects: {
      open: async (_ctx, { event }) => ({ kind: "open", inside: event.inside }),
      close: async () => ({ kind: "closed", closedAt: Date.now() }),
      // `from` is the guest that sent it.
      countOut: async (_ctx, { state, from }) => ({ ...state, inside: state.inside - 1, lastLeft: from.id }),
    },
    links: {
      "guest.ROOM_CLOSED": async ({ db, id }) => (await db.query("guests").withIndex("by_room", (q) => q.eq("roomId", id)).take(200)).map((item) => item._id),
    },
  },
);

export const guest = defineMachine(
  schema,
  {
    name: "guest",
    table: "guests",
    callers: { anyone: "Anyone can." },
    events: { anyone: { ARRIVE: {}, LEAVE: {} }, room: { ROOM_CLOSED: {} } },
    states: {
      start: { on: { ARRIVE: { to: "inside" } } },
      inside: {
        on: {
          // A closed room refuses the news, and the guest leaves anyway.
          LEAVE: { to: "left", effect: "leave", sends: [{ machine: "room", event: "GUEST_LEFT", onRefused: "ignore" }] },
          ROOM_CLOSED: { to: "sentHome" },
        },
      },
      left: {},
      sentHome: {},
    },
  },
  {
    callers: { anyone: () => true },
    effects: { leave: async () => ({ kind: "left", leftAt: Date.now() }) },
    links: { "room.GUEST_LEFT": ({ row }) => row.roomId },
  },
);

// KICK sends HIT to itself, and each HIT sends another until it's counted to
// stopAt: a cycle that ends, or (stopAt past the depth limit) one that
// doesn't. KICK_ALL tells every ping at once: a fan-out. Its links roll
// back, so they run inline, in one transaction. NUDGE and TAP are the same
// cycle with `ignore`, each hop in its own sub-transaction, a level deeper
// in Convex's nesting, and the last TAP stops it.
export const ping = defineMachine(
  schema,
  {
    name: "ping",
    table: "pings",
    callers: { anyone: "Anyone can." },
    events: { anyone: { CREATE: { stopAt: v.number() }, KICK: {}, KICK_ALL: {}, NUDGE: {} }, ping: { HIT: {}, TAP: {} } },
    guards: { more: "It has counted enough." },
    states: {
      start: { on: { CREATE: { to: "counting", effect: "begin" } } },
      counting: {
        on: {
          KICK: { sends: [{ machine: "ping", event: "HIT", onRefused: "rollback" }] },
          KICK_ALL: { sends: [{ machine: "ping", event: "HIT", onRefused: "rollback" }] },
          HIT: [{ guard: "more", effect: "count", sends: [{ machine: "ping", event: "HIT", onRefused: "rollback" }] }, { effect: "count" }],
          NUDGE: { sends: [{ machine: "ping", event: "TAP", onRefused: "ignore" }] },
          TAP: [{ guard: "more", effect: "count", sends: [{ machine: "ping", event: "TAP", onRefused: "ignore" }] }, { to: "stopped", effect: "stop" }],
        },
      },
      stopped: {},
    },
  },
  {
    callers: { anyone: () => true },
    guards: { more: (_ctx, { state }) => state.hits + 1 < state.stopAt },
    effects: {
      begin: async (_ctx, { event }) => ({ kind: "counting", hits: 0, stopAt: event.stopAt }),
      count: async (_ctx, { state }) => ({ ...state, hits: state.hits + 1 }),
      stop: async (_ctx, { state }) => ({ kind: "stopped", hits: state.hits + 1 }),
    },
    links: {
      "ping.HIT": async ({ db, id, event }) => (event.type === "KICK_ALL" ? (await db.query("pings").take(500)).map((item) => item._id) : id),
      "ping.TAP": ({ id }) => id,
    },
  },
);

export const KIT_MS = 60_000;

// BUILD's effect creates `count` parts, one at a time. With `retry`, it
// first makes a flaky part, whose start writes a charge and throws, and
// catches that: the mutation fails anyway. Left open, a kit
// makes one part when its timer fires, and an empty kit's part refuses. A
// tester's FILL, by an ignore link, makes the parts `probe.fill` lists,
// catching the ones it marks, and then tells its parts MADE again by a
// rollback link, which a made part refuses.
export const kit = defineMachine(
  schema,
  {
    name: "kit",
    table: "kits",
    callers: { anyone: "Anyone can." },
    events: { anyone: { OPEN: {}, BUILD: { count: v.number(), retry: v.boolean() } }, tester: { FILL: {} } },
    states: {
      start: { on: { OPEN: { to: "open" } } },
      open: {
        timers: { LAPSED: { after: KIT_MS } },
        on: {
          BUILD: { to: "built", effect: "build", creates: { machine: "part", event: "MADE" } },
          LAPSED: { to: "built", effect: "buildOne", creates: { machine: "part", event: "MADE" } },
          FILL: { to: "built", effect: "fill", creates: { machine: "part", event: "MADE" }, sends: [{ machine: "part", event: "MADE", onRefused: "rollback" }] },
        },
      },
      built: {},
    },
  },
  {
    callers: { anyone: () => true },
    effects: {
      build: async (_ctx, { id, event, create }) => {
        if (event.retry) await create(part, { kitId: id, flaky: true }, { type: "MADE" }).catch(() => null);
        for (let made = 0; made < event.count; made++) await create(part, { kitId: id, flaky: false }, { type: "MADE" });
        return { kind: "built", parts: event.count };
      },
      buildOne: async (_ctx, { id, create }) => {
        await create(part, { kitId: id, flaky: false }, { type: "MADE" });
        return { kind: "built", parts: 1 };
      },
      fill: async (ctx, { id, create }) => {
        const empty = (await ctx.db.query("kits").collect()).find((row) => row.name === "empty")?._id;
        for (const { kitId, flaky, caught } of probe.fill({ own: id, empty })) {
          const made = create(part, { kitId, flaky }, { type: "MADE" });
          await (caught ? made.catch(() => null) : made);
        }
        return { kind: "built", parts: 1 };
      },
    },
    links: { "part.MADE": async ({ db, id }) => (await db.query("parts").collect()).filter((row) => row.kitId === id).map((row) => row._id) },
  },
);
export const part = defineMachine(
  schema,
  {
    name: "part",
    table: "parts",
    events: { kit: { MADE: {} } },
    guards: { inStock: "The kit is empty." },
    states: { start: { on: { MADE: { to: "made", guard: "inStock", effect: "charge" } } }, made: {} },
  },
  {
    guards: { inStock: async (ctx, { row }) => (await ctx.db.get("kits", row.kitId))?.name !== "empty" },
    effects: {
      // Writes a charge, then a flaky part's card is declined.
      charge: async (ctx, { row }) => {
        await ctx.db.insert("ledger", { note: "charged for a part" });
        if (row.flaky) throw new Error("The card was declined.");
        return { kind: "made" };
      },
    },
  },
);

// A machine whose code a test supplies: its effects, guard and link call
// these, which a test replaces with vi.spyOn. Left alone, POKE and DUE
// count by 1, ECHO by 10, and ECHO tells no one.
type Idle = { kind: "idle"; n: number; dueAt: number; data: ArrayBuffer };
export const probe = {
  poke: async (_ctx: unknown, args: { id: string; state: Idle }): Promise<unknown> => ({ ...args.state, n: args.state.n + 1 }),
  echo: async (_ctx: unknown, args: { id: string; state: Idle }): Promise<unknown> => ({ ...args.state, n: args.state.n + 10 }),
  ok: async (_ctx: unknown, _args: unknown): Promise<boolean> => true,
  targets: (_args: { id: string }): unknown => [],
  // A kit's FILL: the parts it makes, in order, and which it catches. A part of the empty kit's is refused, and a flaky
  // one writes and throws. Left alone, the empty kit's (caught), then its own.
  fill: ({ own, empty }: { own: GenericId<"kits">; empty?: GenericId<"kits"> }): { kitId: GenericId<"kits">; flaky: boolean; caught: boolean }[] => [
    ...(empty ? [{ kitId: empty, flaky: false, caught: true }] : []),
    { kitId: own, flaky: false, caught: false },
  ],
};
export const tester = defineMachine(
  schema,
  {
    name: "tester",
    table: "testers",
    callers: { anyone: "Anyone can." },
    events: { anyone: { MAKE: { dueAt: v.number() }, POKE: {}, PING: {}, PUSH: {}, STOCK: {}, STOP: {} }, tester: { ECHO: {} } },
    guards: { ok: "The test's guard said no." },
    states: {
      start: { on: { MAKE: { to: "idle", effect: "make" } } },
      idle: {
        timers: { DUE: { at: "dueAt" } },
        on: {
          POKE: { guard: "ok", effect: "poke" },
          // One link, both ways: PING's receiver steps in its own sub-transaction, PUSH's inline. ECHO passes it on inline.
          PING: { effect: "poke", sends: [{ machine: "tester", event: "ECHO", onRefused: "ignore" }] },
          PUSH: { effect: "poke", sends: [{ machine: "tester", event: "ECHO", onRefused: "rollback" }] },
          ECHO: { effect: "echo", sends: [{ machine: "tester", event: "ECHO", onRefused: "rollback" }] },
          // Fills the open kits, then echoes: an ignore receiver's caught, refused birth, and the links after it.
          STOCK: { effect: "poke", sends: [{ machine: "kit", event: "FILL", onRefused: "ignore" }, { machine: "tester", event: "ECHO", onRefused: "ignore" }] },
          DUE: { guard: "ok", effect: "poke" },
          STOP: { to: "done", effect: "stop" },
        },
      },
      done: {},
    },
  },
  {
    callers: { anyone: () => true },
    guards: { ok: (ctx, args) => probe.ok(ctx, args) },
    effects: {
      make: async (_ctx, { event }) => ({ kind: "idle", n: 0, dueAt: event.dueAt, data: new ArrayBuffer(1) }),
      poke: async (ctx, args) => (await probe.poke(ctx, args)) as never,
      echo: async (ctx, args) => (await probe.echo(ctx, args)) as never,
      stop: async (_ctx, { state }) => ({ kind: "done", n: state.n }),
    },
    links: {
      "tester.ECHO": (args) => probe.targets(args) as never,
      "kit.FILL": async ({ db }) => (await db.query("kits").collect()).filter((row) => row.name !== "empty" && row.state.kind === "open").map((row) => row._id),
    },
  },
);

// The fixtures' catalog, and its builders, as an app's are made.
type DeliveryRef = FunctionReference<"mutation", "internal", ObjectType<typeof deliveryArgs>>;
export const machines = defineMachines(schema, [power, color, job, poll, room, guest, ping, kit, part, tester], {
  mutation: mutationGeneric,
  internalMutation: internalMutationGeneric,
  deliver: makeFunctionReference("fixtures/machines.fixture:deliver") as unknown as DeliveryRef,
  component: components.stateMachines,
});
export const deliver = machines.internalMutation({ args: deliveryArgs, handler: machines.deliver });

// A kit's BUILD through the app's builder, which fails the mutation when a create failed, caught or not.
export const buildKit = machines.mutation({
  args: { kitId: v.id("kits"), count: v.number(), retry: v.boolean() },
  handler: async (ctx, { kitId, count, retry }) => await kit.send(ctx, kitId, { type: "BUILD", count, retry }),
});

// Internal code that calls the delivery itself and catches its error: the
// timer's deletion is the step's first write, so the builder fails the
// mutation anyway, and the timer stays.
export const catchesDelivery = machines.internalMutation({
  args: deliveryArgs,
  handler: async (ctx, args) => await machines.deliver(ctx, args).catch(() => null),
});
