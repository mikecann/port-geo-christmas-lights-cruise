import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { machineTimers } from "../machine.js";

// Test-only tables for the library's own tests (machine.test.ts). Two dots
// in the name, so none of this deploys.

// Two machines on one row: one `<name>State` field each. Power tells color
// twice in one step, so the second link sees what the first did.
export const powerState = v.union(v.object({ kind: v.literal("off") }), v.object({ kind: v.literal("on"), since: v.number() }));
export const colorState = v.union(
  v.object({ kind: v.literal("white") }),
  v.object({ kind: v.literal("warm") }),
  v.object({ kind: v.literal("colored"), hue: v.number() }),
);

// A job: a guarded start, due times in the data, two timers in one state,
// and a timer that chooses through guards.
export const jobState = v.union(
  v.object({ kind: v.literal("queued") }),
  v.object({ kind: v.literal("running"), attempt: v.number(), deadline: v.number(), note: v.string() }),
  v.object({ kind: v.literal("waiting"), attempt: v.number(), retryAt: v.number() }),
  v.object({ kind: v.literal("done"), attempt: v.number() }),
  v.object({ kind: v.literal("failed"), attempt: v.number(), reason: v.string() }),
);

// A room and its guests: a fan-out, `from`, and refusals that are ignored.
export const roomState = v.union(
  v.object({ kind: v.literal("open"), inside: v.number(), lastLeft: v.optional(v.string()) }),
  v.object({ kind: v.literal("closed"), closedAt: v.number() }),
);
export const guestState = v.union(
  v.object({ kind: v.literal("inside") }),
  v.object({ kind: v.literal("left"), leftAt: v.number() }),
  v.object({ kind: v.literal("sentHome") }),
);

// A ping that tells itself again: rollback and ignore cycles, depth and the budget.
export const pingState = v.union(v.object({ kind: v.literal("counting"), hits: v.number(), stopAt: v.number() }), v.object({ kind: v.literal("stopped"), hits: v.number() }));

// A poll that ticks while it's watching: a periodic timer, and a timer its guard refuses.
export const pollState = v.union(v.object({ kind: v.literal("watching"), ticks: v.number(), stopAt: v.number() }), v.object({ kind: v.literal("stopped") }));

// A kit and its parts: an effect that creates as many rows as it likes.
export const kitState = v.union(v.object({ kind: v.literal("open") }), v.object({ kind: v.literal("built"), parts: v.number() }));
export const partState = v.union(v.object({ kind: v.literal("made") }));

// A machine whose code each test supplies (machines.fixture.ts's `probe`), with some bytes.
export const testerState = v.union(
  v.object({ kind: v.literal("idle"), n: v.number(), dueAt: v.number(), data: v.bytes() }),
  v.object({ kind: v.literal("done"), n: v.number() }),
);

export default defineSchema({
  lamps: defineTable({ name: v.string(), powerState, colorState }),
  jobs: defineTable({ owner: v.string(), state: jobState, stateTimers: machineTimers }),
  rooms: defineTable({ name: v.string(), state: roomState }),
  guests: defineTable({ roomId: v.id("rooms"), name: v.string(), state: guestState }).index("by_room", ["roomId"]),
  pings: defineTable({ state: pingState }),
  polls: defineTable({ state: pollState, stateTimers: machineTimers }),
  kits: defineTable({ name: v.string(), state: kitState, stateTimers: machineTimers }),
  parts: defineTable({ kitId: v.id("kits"), flaky: v.boolean(), state: partState }),
  // What effects write besides a state: a part's charge, a tester's note.
  ledger: defineTable({ note: v.string() }),
  testers: defineTable({ name: v.string(), state: testerState, stateTimers: machineTimers }),
});
