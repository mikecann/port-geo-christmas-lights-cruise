// State machines for Convex.
//
// A machine's states are a union in the app's schema, tagged with `kind`, on
// a field named `state` (or `<name>State` when a row holds several). Its
// pending timers sit beside it on the row (`stateTimers`, or
// `<name>StateTimers`), and its history is kept by this package's
// component. The rules are data: who sends each event, what each state does
// with it, its timers, the links it sends. The code behind them is the second
// argument. The runtime runs the manifest the diagrams are drawn from, in the
// caller's own transaction:
//
//   create(ctx, fields, event)   a row is born by an event: a start transition picks its first state
//   send(ctx, id, event)         an event, after its role's check. `server` events need the internal ctx
//   inspect(ctx, id)             what this caller may do now, and why not, without writing
//   purge(ctx, id)               internal code: delete a row in a final state, and its timers
//   armTimers(ctx, id)           internal code: arm a row's timers for its state, as a migration needs
//
// `decide` is the one code path send and inspect share, so inspect predicts
// the role check and the transition send would take (LBI #635). It can't
// foresee an effect, a create or a rollback link failing.
import type { Auth, DataModelFromSchemaDefinition, DocumentByName, FunctionReference, PaginationOptions, PaginationResult } from "convex/server";
import type { GenericDataModel, GenericDatabaseReader, GenericDatabaseWriter, MutationBuilder, QueryBuilder } from "convex/server";
import type { GenericMutationCtx, GenericQueryCtx, SchemaDefinition, TableNamesInDataModel, WithoutSystemFields } from "convex/server";
import { getFunctionName } from "convex/server";
import { compareValues, ConvexError, convexToJson, jsonToConvex, v, type GenericId, type Infer, type ObjectType } from "convex/values";
import type { PropertyValidators, Validator, Value } from "convex/values";
import { customMutation, customQuery } from "convex-helpers/server/customFunctions";
import { validate, ValidationError } from "convex-helpers/validators";
import type { ComponentApi } from "../component/_generated/component.js";
import { entry } from "../component/schema.js";

// ------------------------------------------------------------- The timers

/**
 * A machine's pending timers, on its row beside its state: `stateTimers:
 * machineTimers` (or `<name>StateTimers` for `<name>State`). Only the library
 * writes it. A machine with no timers needs none. `job` is the scheduled
 * delivery: if it threw, Convex marks it failed, and the timer stays until
 * rearmed.
 */
export const machineTimers = v.array(v.object({ event: v.string(), dueAt: v.number(), job: v.id("_scheduled_functions") }));
type Timer = Infer<typeof machineTimers>[number];
/** One fact from a row's history, as `history()` returns it. */
export const historyEntry = entry;
export type HistoryEntry = Infer<typeof entry>;

// No role, machine, state, event or timer may be one of these, and each is a
// plain identifier, so it reads the same in history, errors and diagrams.
const RESERVED = ["start", "server", "timer"];
const NAME = /^[A-Za-z_][A-Za-z0-9_]*$/;

// ------------------------------------------------------------------ Rules

type Transition = {
  to?: string; // the state it goes to. Leave it out to stay put
  guard?: string | readonly string[]; // named guards, checked in order: all must pass
  effect?: string; // does the step's work, and returns the whole next state
  sends?: readonly LinkRule[]; // links the library sends once the step is saved (`links` finds their rows)
  creates?: CreateRule | readonly CreateRule[]; // rows its effect creates, one or more of each, with the `create` it's given
};
/**
 * A link, and what its receiver refusing it does. "rollback": the receiver
 * steps inline, and its refusal throws LINK_REFUSED, so both steps happen or
 * neither does. "ignore": a refusal over there doesn't undo this step. The
 * receiver steps in its own sub-transaction, and if it refuses, or a
 * rollback link below it is refused, its writes are undone, this step
 * stands, and history records why. Anything else it throws (a bug, its own
 * link limits, Convex's) fails this step, as it would inline.
 */
type LinkRule = { machine: string; event: string; onRefused: "rollback" | "ignore" };
/** A row of `machine` that the effect creates, born by its start event `event`. */
type CreateRule = { machine: string; event: string };
type OnRules = Record<string, Transition | readonly Transition[]>;
/** Sends the state its event `after` ms in it (and again after each firing while it stays), or `at` a time in its data. */
type TimerRule = { after: number } | { at: string };
type Rules = {
  name: string;
  table: string;
  field?: string; // `state` (the default), or `<name>State` when a row holds several machines
  history?: boolean; // false: nothing is recorded, and it never calls the history component. Refusals and ignored links are logged instead
  callers?: Record<string, string>; // the roles callers send events as, each with the sentence a refused caller gets
  events: Record<string, Record<string, PropertyValidators>>; // by who sends them: a role, `server`, or another machine (no payload)
  guards?: Record<string, string>; // each guard's "why not"
  states: Record<string, { timers?: Record<string, TimerRule>; on?: OnRules }>; // `start`, and every state. `{}` is final
};

// ------------------------------------------------- The internal ctx's brand

// Only the internalMutation builder that defineMachines returns puts it on a
// ctx, and nothing outside this module can add it. Clients can't call
// internal functions, so `server` events, purge and the operator's functions
// can't be reached from one through the library.
const INTERNAL: unique symbol = Symbol("convex-machines.internal");
/** The ctx of the app's internalMutation or internalQuery (the catalog's builders): it may send `server` events, purge, and read what's for operators. */
export type InternalCtx = { readonly [INTERNAL]: true };
const isInternal = (ctx: object) => (ctx as Record<symbol, unknown>)[INTERNAL] === true;
function internalOnly(ctx: object, what: string) {
  if (!isInternal(ctx)) fail("INTERNAL_ONLY", `${what} runs from internal code: a function built with the app's internalMutation (convex/functions.ts).`);
}

// ----------------------------------------------- Types read off the schema

type DM0 = GenericDataModel;
/** No keys: the type-level `{}`. */
type Empty = Record<never, never>;
type Expand<T> = T extends infer O ? { [K in keyof O]: O[K] } : never;
type Item<T> = T extends readonly (infer U)[] ? U : T;
type NameOf<C> = C extends { name: infer N extends string } ? N : string;
type TableOf<C> = C extends { table: infer T extends string } ? T : never;
type FieldOf<C> = C extends { field: infer F extends string } ? F : "state";
type DocOf<DM extends DM0, C> = TableOf<C> extends TableNamesInDataModel<DM> ? DocumentByName<DM, TableOf<C>> : never;
/** The machine's union: the value of its state field. */
type StateOf<DM extends DM0, C> = DocOf<DM, C>[FieldOf<C> & keyof DocOf<DM, C>];
type KindOf<DM extends DM0, C> = StateOf<DM, C> extends infer U ? (U extends { kind: infer K extends string } ? K : never) : never;
type Member<DM extends DM0, C, K> = Extract<StateOf<DM, C>, { kind: K }>;
type HasData<DM extends DM0, C, K> = [Exclude<keyof Member<DM, C, K>, "kind">] extends [never] ? false : true;
/** A table's state fields: `state` or `<name>State`, holding a union tagged with `kind`. */
type StateFieldsOf<DM extends DM0, T> = T extends TableNamesInDataModel<DM>
  ? { [F in keyof DocumentByName<DM, T>]: F extends "state" | `${string}State` ? (DocumentByName<DM, T>[F] extends { kind: string } ? F : never) : never }[keyof DocumentByName<DM, T>] & string
  : never;
/** A table's timer fields: `stateTimers` or `<name>StateTimers`, beside a state field. */
type TimerFieldsOf<DM extends DM0, T> = T extends TableNamesInDataModel<DM> ? keyof DocumentByName<DM, T> & `${StateFieldsOf<DM, T>}Timers` : never;
/** What only the library writes on a machine's row: its states and their timers. */
type OwnedFieldsOf<DM extends DM0, T> = StateFieldsOf<DM, T> | TimerFieldsOf<DM, T>;
/** The rows a step created, by table: `{ versions: [id] }`. Only machines' tables have rows a step creates. */
type Created<DM extends DM0> = { [T in TableNamesInDataModel<DM> as [StateFieldsOf<DM, T>] extends [never] ? never : T]?: GenericId<T>[] };
/** A new row's own fields, what `create` takes: its machines pick their states. */
type FieldsOf<DM extends DM0, C> = Expand<Omit<WithoutSystemFields<DocOf<DM, C>>, OwnedFieldsOf<DM, TableOf<C>>>>;

type EventsOf<C> = C extends { events: infer E } ? E : Empty;
type StatesOf<C> = C extends { states: infer S } ? S : Empty;
type OnOf<R> = R extends { on: infer O } ? O : Empty;
type TimersOf<R> = R extends { timers: infer T } ? T : Empty;
type RoleNames<C> = keyof (C extends { callers: infer R } ? R : Empty) & string;
type GuardNames<C> = keyof (C extends { guards: infer G } ? G : Empty) & string;
type EventUnion<P> = {
  [K in keyof P & string]: Expand<{ type: K } & (P[K] extends PropertyValidators ? ObjectType<P[K]> : Empty)>;
}[keyof P & string];
/** The events a group sends: a role, "server", or a machine's name. */
type EventFrom<C, G> = G extends keyof EventsOf<C> ? EventUnion<EventsOf<C>[G]> : never;
/** Its roles' events: what any ctx may send, after the role's check. */
type RoleEvent<C> = EventFrom<C, RoleNames<C>>;
// A `server` event from a ctx without the brand: the property it lacks says why.
type NeedsInternal<C> = EventFrom<C, "server"> extends { type: infer T } ? { type: T; "server events are sent from the app's internalMutation": never } : never;
/** What `send` and `create` take from a ctx: its roles' events, and with the internal ctx, its `server` events too. */
type CallerEvent<C, X> = RoleEvent<C> | (X extends InternalCtx ? EventFrom<C, "server"> : NeedsInternal<C>);
type EventNames<C> = { [K in keyof EventsOf<C>]: keyof EventsOf<C>[K] & string }[keyof EventsOf<C>];
type TimerNames<C> = { [S in keyof StatesOf<C>]: keyof TimersOf<StatesOf<C>[S]> & string }[keyof StatesOf<C>];
type AnyEvent<C> =
  | { [K in keyof EventsOf<C>]: EventUnion<EventsOf<C>[K]> }[keyof EventsOf<C>]
  | (TimerNames<C> extends infer N ? (N extends string ? { type: N } : never) : never);
type StartOf<C> = StatesOf<C> extends { start: infer S } ? S : Empty;
type StartEvents<C> = keyof OnOf<StartOf<C>> & string;
// The events some state takes: what a row is sent. A start-only one (CREATE) is for create.
type RowEvents<C> = { [S in Exclude<keyof StatesOf<C>, "start">]: keyof OnOf<StatesOf<C>[S]> & string }[Exclude<keyof StatesOf<C>, "start">];
type ForRow<E, C> = Extract<E, { type: RowEvents<C> }>;
type ForStart<E, C> = Extract<E, { type: StartEvents<C> }>;
type Groups<C> = RoleNames<C> | ("server" extends keyof EventsOf<C> ? "server" : never);
type GroupOf<C, E> = { [G in keyof EventsOf<C>]: E extends keyof EventsOf<C>[G] ? G : never }[keyof EventsOf<C>];
/** Who sent a link's event: `{ machine, id }`. Callers', the server's and timers' events have none. */
type LinkFrom<C, E> = E extends unknown ? ([GroupOf<C, E>] extends [RoleNames<C> | "server"] ? undefined : { machine: GroupOf<C, E>; id: string }) : never;

// Where a guard, an effect or a link is named, so its code gets the state
// narrowed to the states it runs in, the event to the events it runs on, and
// (for an effect) the state it enters as its return type.
type Stay = "(stays)";
type LinkName<L> = L extends { machine: infer M extends string; event: infer E extends string } ? `${M}.${E}` : never;
type NameIn<Key extends string, V> = Key extends "sends" ? LinkName<Item<V>> : Item<V>;
type UsesIn<O, From, Key extends string, N> = {
  [E in keyof O]: Item<O[E]> extends infer T
    ? T extends Record<Key, infer V>
      ? N extends NameIn<Key, V>
        ? { from: From; event: E; to: T extends { to: infer To } ? To : Stay; creates: T extends { creates: infer Cr } ? Item<Cr> : never }
        : never
      : never
    : never;
}[keyof O];
type Uses<C, Key extends string, N> = { [S in keyof StatesOf<C>]: UsesIn<OnOf<StatesOf<C>[S]>, S, Key, N> }[keyof StatesOf<C>];
type NamesOf<C, Key extends string> = { [S in keyof StatesOf<C>]: { [E in keyof OnOf<StatesOf<C>[S]>]: Item<OnOf<StatesOf<C>[S]>[E]> extends infer T ? (T extends Record<Key, infer V> ? NameIn<Key, V> : never) : never }[keyof OnOf<StatesOf<C>[S]>] }[keyof StatesOf<C>] & string;

type FromOf<U> = U extends { from: infer F } ? F : never;
type EventOf<U> = U extends { event: infer E } ? E : never;
type ToOf<U> = U extends { from: infer F; to: infer T } ? (T extends Stay ? F : T) : never;
type IdArg<C, F> = F extends "start" ? undefined : GenericId<TableOf<C>>;
type RowArg<DM extends DM0, C, F> = F extends "start" ? FieldsOf<DM, C> : DocOf<DM, C>;
type StateArg<DM extends DM0, C, F> = F extends "start" ? undefined : Member<DM, C, F>;
// Frozen at runtime, and read-only here: `state.n++` would hide the change from the step.
type StepArgs<DM extends DM0, C, U> = {
  /** A start transition runs before its row exists, so it has no ID. */
  id: IdArg<C, FromOf<U>>;
  /** The row, or for a start transition the fields it's created with. */
  row: Readonly<RowArg<DM, C, FromOf<U>>>;
  /** Narrowed to the states this runs in: `state.building` while building. */
  state: Readonly<StateArg<DM, C, FromOf<U>>>;
  /** Narrowed to the events this runs on. */
  event: Readonly<Extract<AnyEvent<C>, { type: EventOf<U> }>>;
  /** The machine and row that sent it, for a link's event. */
  from: LinkFrom<C, EventOf<U>>;
};

type AnyMachine = { readonly name: string; readonly "~types": { rules: unknown; table: string; fields: unknown } };
type RulesOf<M> = M extends { "~types": { rules: infer R } } ? R : never;
type Declared<U> = U extends { creates: infer Cr } ? Cr : never;
type MachineOf<R> = R extends { machine: infer N } ? N : never;
type EventIn<R> = R extends { event: infer E } ? E : never;
/** An effect's `create`: a row of a machine its transition `creates`, born by the start event it declares. */
type CreateFn<C, U> = <M extends AnyMachine & { name: MachineOf<Declared<U>> }>(
  machine: M,
  fields: M["~types"]["fields"],
  event: Extract<EventFrom<RulesOf<M>, NameOf<C>>, { type: EventIn<Extract<Declared<U>, { machine: M["name"] }>> & StartEvents<RulesOf<M>> }>,
) => Promise<GenericId<M["~types"]["table"]>>;

/** What guards and callers get: reads, and who's asking. */
type GuardCtx<DM extends DM0> = { db: GenericDatabaseReader<DM>; auth: Auth };
/** A role's check. `id` is undefined on create, where `row` is the fields the row would have. */
type CallerFn<DM extends DM0, C> = (ctx: GuardCtx<DM>, args: { id: GenericId<TableOf<C>> | undefined; row: Readonly<FieldsOf<DM, C>> }) => boolean | Promise<boolean>;
type GuardFn<DM extends DM0, C, N> = (ctx: GuardCtx<DM>, args: StepArgs<DM, C, Uses<C, "guard", N>>) => boolean | Promise<boolean>;
type KeysOf<U> = U extends unknown ? keyof U : never;
/** A state as an effect returns it. Another state's fields are refused, from a spread too: `{ ...state, kind: "queued" }`. */
type Exact<DM extends DM0, C, K> = K extends unknown
  ? Member<DM, C, K> & { [F in Exclude<KeysOf<StateOf<DM, C>>, keyof Member<DM, C, K>> & string]?: `${F} is another state's data, not ${K & string}'s` }
  : never;
type EffectFn<DM extends DM0, C, N> = (
  ctx: AppCtx<DM>,
  args: StepArgs<DM, C, Uses<C, "effect", N>> & { to: ToOf<Uses<C, "effect", N>>; create: CreateFn<C, Uses<C, "effect", N>> },
) => Promise<Exact<DM, C, ToOf<Uses<C, "effect", N>>>>;
/** Run once the step is saved, for each link: `row` is the row now, `state` the state it left and `next` the one it entered. */
type LinkArgs<DM extends DM0, C, U> = {
  db: GenericDatabaseReader<DM>;
  id: GenericId<TableOf<C>>;
  row: Readonly<DocOf<DM, C>>;
  state: Readonly<StateArg<DM, C, FromOf<U>>>;
  next: Readonly<Member<DM, C, ToOf<U>>>;
  event: Readonly<Extract<AnyEvent<C>, { type: EventOf<U> }>>;
};
/** The rows to tell: an ID of the receiver's table, or a list of them (`[]` for none). Anything else is LINK_TARGET. */
type Targets<DM extends DM0> = GenericId<TableNamesInDataModel<DM>> | readonly GenericId<TableNamesInDataModel<DM>>[];
type LinkFn<DM extends DM0, C, N> = (args: LinkArgs<DM, C, Uses<C, "sends", N>>) => Targets<DM> | Promise<Targets<DM>>;
type Needs<Names, T> = [Names] extends [never] ? { [K in keyof T]?: Empty } : T;
type Implementation<DM extends DM0, C> = Needs<RoleNames<C>, { callers: { [R in RoleNames<C>]: CallerFn<DM, C> } }> &
  Needs<GuardNames<C>, { guards: { [N in GuardNames<C>]: GuardFn<DM, C, N> } }> &
  Needs<NamesOf<C, "effect">, { effects: { [N in NamesOf<C, "effect">]: EffectFn<DM, C, N> } }> &
  Needs<NamesOf<C, "sends">, { links: { [N in NamesOf<C, "sends">]: LinkFn<DM, C, N> } }>;

// --------------------------------------------- Checking the rules' types

// `defineMachine` infers the rules as one literal type, C, then checks C
// against this mirror of itself. Where something's wrong the mirror holds a
// sentence, so the error lands on that property and reads as a reason.
type Fine<Problem> = [Problem] extends [never] ? unknown : Problem;
type First<Ps extends unknown[]> = Ps extends [infer H, ...infer R] ? ([H] extends [never] ? First<R> : H) : never;
type Each<X, Message extends string> = X extends string ? `${X}${Message}` : never;
// A string option's reason is an object: two string literals intersect to never.
type Is<X, Allowed, Problem extends string> = [X] extends [Allowed] ? unknown : { problem: Problem };
type RollsBack<S> = [Extract<Item<S>, { onRefused: "rollback" }>] extends [never] ? false : true;
// `Self` is the state the transition is in, or "start".
type TransitionCheck<DM extends DM0, C, T, Self, Timer> = Fine<
  First<
    [
      Each<Exclude<keyof T, keyof Transition>, " isn't a transition option">,
      T extends { to: Self } ? "leave `to` out to stay put. To restart a deadline, use an `at` timer and move its field" : never,
      T extends { to: infer To }
        ? To extends KindOf<DM, C>
          ? T extends { effect: string } ? never : HasData<DM, C, To> extends true ? `${To} has data, so entering it needs an effect that returns it` : never
          : `${To & string} isn't a state in the schema's union`
        : Self extends "start" ? "a start transition needs `to`: the state the row starts in" : never,
      T extends { guard: infer G } ? Each<Exclude<Item<G>, GuardNames<C>>, " isn't declared in guards"> : never,
      [Self, T] extends ["start", { creates: unknown } | { sends: unknown }] ? "a start can't send or create: its row may be born inside its creator's step" : never,
      [Timer, T] extends [true, { sends: infer S }] ? (RollsBack<S> extends true ? 'a timer\'s links send with onRefused: "ignore"' : never) : never,
    ]
  >
>;
// A list maps through a type parameter, so a tuple stays a tuple.
type ListCheck<DM extends DM0, C, L extends readonly unknown[], Self, Timer> = { [I in keyof L]: TransitionCheck<DM, C, L[I], Self, Timer> };
type OnCheck<DM extends DM0, C, O, Timers extends string, Self> = {
  [E in keyof O]: E extends EventNames<C> | Timers
    ? O[E] extends infer L extends readonly unknown[]
      ? L extends readonly [] ? "an empty list takes the event and does nothing: give it a transition, or leave the event out" : ListCheck<DM, C, L, Self, E extends Timers ? true : false>
      : TransitionCheck<DM, C, O[E], Self, E extends Timers ? true : false>
    : `${E & string} isn't one of this machine's events, or a timer of this state`;
};
// `{} extends Pick<M, F>` holds for an optional field, so an `at` can't name one.
type RequiredNumbers<M> = { [F in keyof M]-?: Empty extends Pick<M, F> ? never : M[F] extends number ? F : never }[keyof M];
type StateCheck<DM extends DM0, C, K, R> = {
  timers?: { [T in keyof TimersOf<R>]: TimersOf<R>[T] extends { at: infer F } ? { at: Is<F, RequiredNumbers<Member<DM, C, K>>, "not a required number field of this state's data"> } : { after: number } };
  on?: OnCheck<DM, C, OnOf<R>, keyof TimersOf<R> & string, K>;
};
type Validate<DM extends DM0, C> = {
  table: Is<TableOf<C>, TableNamesInDataModel<DM>, "not a table in the schema">;
  field?: Is<FieldOf<C>, StateFieldsOf<DM, TableOf<C>>, "not `state` or `<name>State` holding a union tagged with `kind`">;
  // `start`, every state in the union, and nothing else.
  states: { start: { on: OnCheck<DM, C, OnOf<StartOf<C>>, never, "start"> } } & {
    [K in KindOf<DM, C>]: StateCheck<DM, C, K, K extends keyof StatesOf<C> ? StatesOf<C>[K] : Empty>;
  } & { [K in Exclude<keyof StatesOf<C>, KindOf<DM, C> | "start">]: "not a state in the schema's union" };
};

// ------------------------------------------------------ The write guard

type Refused<DM extends DM0, T, Advice extends string> = [StateFieldsOf<DM, T>] extends [never] ? T : `${T & string} rows hold a machine's state: ${Advice}`;
/** `ctx.db` for app mutations and effects: writing a machine's state, or deleting its row, is a compile error and a runtime one. */
type GuardedDb<DM extends DM0> = Omit<GenericDatabaseWriter<DM>, "insert" | "patch" | "replace" | "delete"> & {
  insert<T extends TableNamesInDataModel<DM>>(
    table: Refused<DM, T, "create them with the machine's create()">,
    value: WithoutSystemFields<DocumentByName<DM, T>>,
  ): Promise<GenericId<T>>;
  patch<T extends TableNamesInDataModel<DM>>(
    table: T,
    id: GenericId<T>,
    value: Partial<Omit<DocumentByName<DM, T>, "_id" | "_creationTime" | OwnedFieldsOf<DM, T>>> & {
      [K in OwnedFieldsOf<DM, T>]?: `${K} belongs to a machine: send it an event`;
    },
  ): Promise<void>;
  replace<T extends TableNamesInDataModel<DM>>(
    table: Refused<DM, T, "patch the app's fields instead">,
    id: GenericId<T>,
    value: WithoutSystemFields<DocumentByName<DM, T>>,
  ): Promise<void>;
  delete<T extends TableNamesInDataModel<DM>>(
    table: Refused<DM, T, "send them to a final state (a deletion is a transition), or purge() them from internal code">,
    id: GenericId<T>,
  ): Promise<void>;
};
/**
 * The ctx effects get, and a type for helpers that handlers and effects both
 * call: the guarded db, and no runMutation or runQuery, whose nested function
 * would run outside the step and could step its row under it.
 */
export type AppCtx<DM extends DM0> = Omit<GenericMutationCtx<DM>, "db" | "runMutation" | "runQuery"> & { db: GuardedDb<DM> };

// ---------------------------------------------------------- The machine

type StepCtx<DM extends DM0> = Omit<AppCtx<DM>, "db"> & { db: object };
type ReadCtx<DM extends DM0> = Omit<GenericQueryCtx<DM>, "db"> & { db: object };
/** A ctx that reads: the app's mutation ctx or a query's. */
type ReaderCtx<DM extends DM0> = Omit<ReadCtx<DM>, "runQuery">;
/** A query's or mutation's ctx: reading history calls the component. */
type HistoryCtx = { runQuery: GenericQueryCtx<DM0>["runQuery"] };
type TypeOf<E> = E extends { type: infer T extends string } ? T : never;
type Rejected = { status: "rejected"; code: "NOT_ALLOWED" | "NOT_ACCEPTED" | "GUARD_BLOCKED"; reasons: string[] };
/** `created`: the rows the step's effect created, by table. A refusal is a result too. */
export type SendResult<K extends string = string, Made = Record<string, string[]>> = { status: "done"; from: K; to: K; created: Made } | Rejected;
export type CreateResult<K extends string = string, Id = string> = { status: "done"; id: Id; from: "start"; to: K } | Rejected;
/** `to`: where it goes if allowed (null: stays put). "needs_input": its payload has required fields, and none was given to try. */
type NextStep<E extends string = string, K extends string = string> = { event: E; to: K | null; allowed: boolean | "needs_input"; code?: Rejected["code"]; reasons: string[] };
/** The events this caller's roles may send, and the pending timers. */
export type Inspection<E extends string = string, K extends string = string> = { kind: K; events: NextStep<E, K>[]; timers: { event: string; dueAt: number }[] };

export type Machine<DM extends DM0, C> = {
  readonly name: NameOf<C>;
  readonly table: TableOf<C>;
  readonly field: FieldOf<C>;
  /** The rules as data, frozen: what the diagrams draw, and what the runtime runs. */
  readonly manifest: Manifest;
  /** Validators for an endpoint's args: each role's events, and the server's, that a row takes. Start-only ones aren't here. */
  readonly events: { [G in Groups<C> as [ForRow<EventFrom<C, G>, C>] extends [never] ? never : G]: Validator<ForRow<EventFrom<C, G>, C>, "required", string> };
  /** The same for the events a row is born by: each group's start events. */
  readonly startEvents: { [G in Groups<C> as [ForStart<EventFrom<C, G>, C>] extends [never] ? never : G]: Validator<ForStart<EventFrom<C, G>, C>, "required", string> };
  /** Validators for an endpoint's `returns`: what create, send and inspect return. */
  readonly results: {
    create: Validator<CreateResult<KindOf<DM, C>, GenericId<TableOf<C>>>, "required", string>;
    send: Validator<SendResult<KindOf<DM, C>, Created<DM>>, "required", string>;
    inspect: Validator<Inspection<TypeOf<ForRow<RoleEvent<C>, C>>, KindOf<DM, C>> | null, "required", string>;
  };
  /** A row born by a start event: a role's, after its check, or with the internal ctx a `server` one. Errors as `send`'s. */
  create<X extends StepCtx<DM>>(ctx: X, fields: FieldsOf<DM, C>, event: ForStart<CallerEvent<C, X>, C>): Promise<CreateResult<KindOf<DM, C>, GenericId<TableOf<C>>>>;
  /**
   * A role's event, after the role's check, or with the internal ctx a
   * `server` event. A refusal is a result. An error thrown once the step has
   * begun writing (its effect ran) fails the whole mutation in the app's
   * builders, even if the handler catches it, so a half-done step never
   * commits. One thrown before anything was written (NOT_FOUND,
   * INVALID_EVENT, INTERNAL_ONLY, UNKNOWN_STATE, CONCURRENT_SEND) is an
   * ordinary error, safe to catch.
   */
  send<X extends StepCtx<DM>>(ctx: X, id: GenericId<TableOf<C>>, event: ForRow<CallerEvent<C, X>, C>): Promise<SendResult<KindOf<DM, C>, Created<DM>>>;
  /** What this caller's events would do now, and why not. Null if the row is gone, or none of the caller's roles pass. Pass events to try ones with a payload. */
  inspect(ctx: ReadCtx<DM>, id: GenericId<TableOf<C>>, events?: ForRow<RoleEvent<C>, C>[]): Promise<Inspection<TypeOf<ForRow<RoleEvent<C>, C>>, KindOf<DM, C>> | null>;
  /** Internal code only: deletes a row whose machines are all in final states (or any, with `force`), cancels its timers, and records it. */
  purge(ctx: StepCtx<DM> & InternalCtx, id: GenericId<TableOf<C>>, options?: { force?: boolean }): Promise<void>;
  /**
   * Internal code only: arms the timers the row's state has, as if it had
   * just entered it, and cancels any it had. For a row a migration moved into
   * a state, which has none yet. Returns what it armed.
   */
  armTimers(ctx: StepCtx<DM> & InternalCtx, id: GenericId<TableOf<C>>): Promise<{ event: string; dueAt: number }[]>;
  /** The row's history, oldest first unless `order` is "desc". Empty for a machine with `history: false`. */
  history(ctx: HistoryCtx, id: GenericId<TableOf<C>>, options: { paginationOpts: PaginationOptions; order?: "asc" | "desc" }): Promise<PaginationResult<HistoryEntry>>;
  readonly "~types": { rules: C; table: TableOf<C>; fields: FieldsOf<DM, C>; state: StateOf<DM, C>; kind: KindOf<DM, C> };
};

/** Read straight off the rules and the schema's validator, then frozen: the diagrams draw it, and the runtime runs it. */
export type Manifest = {
  name: string;
  table: string;
  field: string;
  history: boolean;
  states: { kind: string; data: string[]; final: boolean; timers: { event: string; after?: number; at?: string }[] }[];
  events: { type: string; from: string; fields: string[] }[]; // `from`: a role, "server", or a machine. `fields`: its payload's, "name?" if optional
  callers: Record<string, string>;
  guards: Record<string, string>;
  transitions: {
    from: string; // a state, or "start"
    event: string;
    to: string | null; // null: stays put
    guards: string[];
    effect?: string;
    sends: { machine: string; event: string; onRefused: "rollback" | "ignore" }[];
    creates: CreateRule[];
    order?: { index: number; of: number }; // its place in a list, which is tried in order (from 1)
  }[];
};

// What a client may see: a code, and a sentence with no state's data and no other row's ID.
type ErrorCode = "NOT_FOUND" | "INVALID_EVENT" | "INTERNAL_ONLY" | "UNKNOWN_STATE" | "WRONG_STATE" | "NOT_FINAL" | "CONCURRENT_SEND"
  | "UNDECLARED_CREATE" | "LINK_REFUSED" | "LINK_TARGET" | "LINK_DEPTH" | "LINK_BUDGET" | "STATE_WRITE_OUTSIDE_MACHINE"; // prettier-ignore
function fail(code: ErrorCode, message: string): never {
  throw new ConvexError({ code, message });
}

// ----------------------------------------------------------------- Runtime

type Loose = Record<string, unknown>;
type State = Loose & { kind: string };
type Event = Loose & { type: string };
type AnyCtx = GenericMutationCtx<DM0>;
type Db = GenericDatabaseWriter<DM0>;
type AnyValidator = Validator<unknown, "required" | "optional", string> & { fields?: Record<string, AnyValidator>; members?: AnyValidator[]; value?: unknown };
// eslint-disable-next-line @typescript-eslint/no-explicit-any -- any schema, as convex/server types it
type AnySchema = SchemaDefinition<any, boolean>;
type Item0 = Manifest["transitions"][number];
// Below Convex's cap of 8 nested calls, even for a step entered through runMutation.
const MAX_LINK_DEPTH = 4;
const LINK_BUDGET = 100;

const list = <T>(value: T | readonly T[] | undefined): T[] => (value === undefined ? [] : Array.isArray(value) ? [...value] : [value as T]);
const same = (a: unknown, b: unknown) => compareValues(a as Value, b as Value) === 0;
const tablesOf = (schema: AnySchema) => schema.tables as Record<string, { validator: AnyValidator }>;
// The code a ConvexError carries, across a sub-transaction too. LINK_REFUSED is a refusal from below, which `ignore` isolates.
const codeOf = (error: unknown) => (error instanceof ConvexError ? (error.data as Loose)?.code : undefined);
const refused = (error: unknown) => codeOf(error) === "LINK_REFUSED";

// The library writes through the raw db. A guarded db maps to its raw one
// here, where nothing outside this module can reach it.
const rawOf = new WeakMap<object, Db>();
const raw = (ctx: { db: unknown }): Db => rawOf.get(ctx.db as object) ?? (ctx.db as Db);
const reader = (db: Db) =>
  ({ get: db.get.bind(db), query: db.query.bind(db), normalizeId: db.normalizeId.bind(db), system: db.system }) as unknown as GenericDatabaseReader<DM0>;
const guardCtx = (ctx: { db: unknown; auth: unknown }) => ({ db: reader(raw(ctx)), auth: ctx.auth });

// Callers, guards, effects and links get frozen copies of the row, the state
// and the event, so `state.n++` throws instead of changing the snapshot the
// step compares its result with.
function frozen<T>(value: T): T {
  if (value && typeof value === "object" && !(value instanceof ArrayBuffer) && !Object.isFrozen(value)) for (const item of Object.values(Object.freeze(value))) frozen(item);
  return value;
}
const snapshot = <T>(value: T): T => frozen(jsonToConvex(convexToJson(value as Value)) as T);

// One step at a time per transaction: two sends at once would both read the
// row before either wrote it. Taken before the first await, released when
// the step and its links are done. And a step that throws once it has begun
// writing is remembered, so the app's builders fail the mutation even if the
// handler caught the error: its half-done writes never commit. The first
// failure is kept, unless it was a refusal and a bug came after it: a
// refusal can't hide a bug.
const busy = new WeakSet<object>();
const failures = new WeakMap<object, unknown>();
const remember = (db: object, error: unknown) => {
  if (!failures.has(db) || (refused(failures.get(db)) && !refused(error))) failures.set(db, error);
};
// What a call shares with the links and creates it runs: the link budget left, and whether it has begun writing.
type Run = { budget: number; wrote: boolean };
async function exclusive<T>(ctx: { db: unknown }, go: (run: Run) => Promise<T>, budget = LINK_BUDGET): Promise<T> {
  const db = raw(ctx);
  if (busy.has(db)) fail("CONCURRENT_SEND", "A machine step is already running on this ctx. Await each send in turn, and tell other machines from a transition's `sends`.");
  busy.add(db);
  const run = { budget, wrote: false };
  try {
    return await go(run);
  } catch (error) {
    if (run.wrote) remember(db, error);
    throw error;
  } finally {
    busy.delete(db);
  }
}

/** A union of objects each tagged `kind: v.literal(...)`, as kind -> member. */
function stateUnion(validator: AnyValidator | undefined): Map<string, AnyValidator> | null {
  if (validator?.kind !== "union" || validator.isOptional === "optional" || !validator.members?.length) return null;
  const members = new Map<string, AnyValidator>();
  for (const member of validator.members) {
    const kind = member.fields?.kind;
    if (member.kind !== "object" || kind?.kind !== "literal" || typeof kind.value !== "string") return null;
    members.set(kind.value, member);
  }
  return members;
}

/** Each table's fields that only the library writes: its state fields, and their timer fields. */
function ownedFields(schema: AnySchema): Map<string, string[]> {
  const fields = tablesOf(schema);
  return new Map([...stateFields(schema)].map(([table, states]) => [table, states.flatMap((state) => [state, ...(fields[table].validator.fields?.[`${state}Timers`] ? [`${state}Timers`] : [])])]));
}

/** Each table's state fields: `state` or `<name>State`, holding a union tagged with `kind`. */
function stateFields(schema: AnySchema): Map<string, string[]> {
  const found = new Map<string, string[]>();
  for (const [table, { validator }] of Object.entries(tablesOf(schema))) {
    const fields = Object.entries(validator.fields ?? {})
      .filter(([name, field]) => (name === "state" || name.endsWith("State")) && stateUnion(field))
      .map(([name]) => name);
    if (fields.length) found.set(table, fields);
  }
  return found;
}

function guardDb(db: Db, owned: Map<string, string[]>): Db {
  const refuse = (what: string, advice: string): never => fail("STATE_WRITE_OUTSIDE_MACHINE", `${what}. ${advice}`);
  // The table a write names, or for the older form, `patch(id, value)`, the one its ID is of.
  const tableOf = (args: unknown[], withValue: boolean) =>
    args.length >= (withValue ? 3 : 2) ? (args[0] as string) : [...owned.keys()].find((table) => db.normalizeId(table as never, args[0] as string) !== null);
  // A whole-row write to a machine's table.
  const check = (table: string | undefined, advice: string) => {
    if (table && owned.has(table)) refuse(`${owned.get(table)!.map((field) => `${table}.${field}`).join(", ")} belongs to a machine`, advice);
  };
  const write = (method: "patch" | "replace" | "delete", args: unknown[]) => (db[method] as (...rest: unknown[]) => Promise<void>)(...args);
  const guarded = {
    ...reader(db),
    insert: async (table: string, value: Loose) => (check(table, "Create the row with its machine's create()."), await db.insert(table as never, value as never)),
    async patch(...args: unknown[]) {
      const table = tableOf(args, true);
      const written = table ? (owned.get(table) ?? []).filter((field) => field in ((args.length >= 3 ? args[2] : args[1]) as Loose)) : [];
      if (written.length) refuse(`${written.map((field) => `${table}.${field}`).join(", ")} belongs to a machine`, "Send the machine an event instead.");
      return await write("patch", args);
    },
    replace: async (...args: unknown[]) => (check(tableOf(args, true), "Patch the app's own fields instead."), await write("replace", args)),
    delete: async (...args: unknown[]) => (check(tableOf(args, false), "Send it to a final state (a deletion is a transition), or purge() it from internal code."), await write("delete", args)),
  } as unknown as Db;
  rawOf.set(guarded, db);
  return guarded;
}

// Cancelling a job that's running would cancel what it schedules, so only pending ones.
// A function's name as Convex records it on a scheduled job ("machines.js:deliver"), and as a
// reference gives it ("machines:deliver"), brought to one form so the two can be compared.
const functionKey = (name: string) => name.replace(/\.js:/, ":");

async function cancelIfPending(ctx: AnyCtx, job: GenericId<"_scheduled_functions">) {
  if ((await raw(ctx).system.get("_scheduled_functions", job))?.state.kind === "pending") await ctx.scheduler.cancel(job);
}
/** A machine's timers on a row: none if it keeps no timer field. */
const timersOf = (run: { timers?: string }, row: Loose | null | undefined) => ((run.timers && row?.[run.timers]) || []) as readonly Timer[];

/** The args of the app's one delivery mutation: a timer's event at its due time, or an `ignore` link's in a sub-transaction. */
export const deliveryArgs = {
  ...{ machine: v.string(), id: v.string(), event: v.string() },
  dueAt: v.optional(v.number()), // a timer's
  link: v.optional(v.object({ machine: v.string(), id: v.string(), depth: v.number(), budget: v.number() })), // a link's sender, and its step's limits
};
type DeliveryArgs = ObjectType<typeof deliveryArgs>;
type Delivered = { status: "done" | "rejected" | "skipped"; reasons: string[]; budget: number };
type DeliveryRef = FunctionReference<"mutation", "internal", DeliveryArgs, Delivered>;

// Who sent an event: for the role check, history and `from`.
type By = { kind: "role"; role: string } | { kind: "server" } | { kind: "timer" } | { kind: "link"; machine: string; id: string };
const byText = (by: By) => (by.kind === "role" ? by.role : by.kind === "link" ? `${by.machine}:${by.id}` : by.kind);
type Fact = { subject: string; kind: HistoryEntry["kind"]; event: string; from: string; to: string; by: By; reasons: string[] };
type Fn<R> = (...args: never[]) => R;
type LooseCode = {
  callers?: Record<string, Fn<boolean | Promise<boolean>>>;
  guards?: Record<string, Fn<boolean | Promise<boolean>>>;
  effects?: Record<string, Fn<Promise<State>>>;
  links?: Record<string, Fn<unknown>>;
};
// A step's links share its run's limits: at most MAX_LINK_DEPTH deep, and LINK_BUDGET in all.
type Step = { id: string; depth: number; run: Run };
// A delivered link's depth or budget, held to the limit: below 0, or NaN, is 0, so no caller can lift the limits.
const within = (value: number, limit: number) => (value >= 0 ? Math.min(value, limit) : 0);
function hop(step: Step, from: string, to: string, toId: string): [By, Step] {
  if (step.depth + 1 > MAX_LINK_DEPTH) fail("LINK_DEPTH", `Links went ${MAX_LINK_DEPTH} deep at ${to}: are two machines telling each other forever?`);
  if (--step.run.budget < 0) fail("LINK_BUDGET", `One step sent more than ${LINK_BUDGET} links. Fan out to fewer rows, or schedule the rest.`);
  return [{ kind: "link", machine: from, id: step.id }, { id: toId, depth: step.depth + 1, run: step.run }];
}

// A machine's runtime, kept here rather than on the machine, so only the library reaches its code.
type Runtime = {
  name: string; table: string; field: string; timers?: string; rules: Rules; manifest: Manifest; catalog?: Catalog; // prettier-ignore
  apply(ctx: AnyCtx, id: string, event: Event, by: By, step: Step): Promise<SendResult>;
  admit(ctx: AnyCtx, fields: Loose, event: Event, by: By): Promise<Item0 | Rejected>;
  begin(ctx: AnyCtx, fields: Loose, event: Event, by: By, transition: Item0): Promise<State>;
  born(ctx: AnyCtx, id: string, state: State, event: Event, by: By): Promise<void>;
  record(ctx: AnyCtx, fact: Fact): Promise<void>;
};
const runtimes = new WeakMap<object, Runtime>();
function runtimeOf(machine: unknown): Runtime {
  const run = runtimes.get(machine as object);
  if (!run) throw new Error("That isn't a machine: pass what defineMachine returned.");
  return run;
}
type Catalog = { machines: Map<string, Runtime>; owned: Map<string, string[]>; deliver?: DeliveryRef; component?: ComponentApi };
function catalogOf(run: Runtime): Catalog {
  if (!run.catalog)
    throw new Error(`${run.name} isn't in a catalog: add it to defineMachines, or import convex/machines (or convex/functions) in this file so the catalog loads.`);
  return run.catalog;
}
const machinesOn = (run: Runtime) => [...catalogOf(run).machines.values()].filter((other) => other.table === run.table);

// A row is born by one event, which every machine on its table takes from
// the same sender, each picking its own start state. In phases: every start
// is decided, then every effect runs, then the row is inserted and every
// machine's timers and history begin. A start sends nothing, so no step runs
// on a half-born row.
async function birth(ctx: AnyCtx, run: Runtime, fields: Loose, event: Event, by: By, shared: Run): Promise<CreateResult> {
  const starts = [];
  for (const machine of machinesOn(run)) {
    const transition = await machine.admit(ctx, fields, event, by);
    if ("status" in transition) return transition;
    starts.push({ machine, transition });
  }
  shared.wrote = true;
  const states: State[] = [];
  for (const { machine, transition } of starts) states.push(await machine.begin(ctx, fields, event, by, transition));
  // Each machine's state, and its timers (none yet: born() arms them once the row has an ID).
  const owned = starts.flatMap(({ machine }, index) => [[machine.field, states[index]], ...(machine.timers ? [[machine.timers, []]] : [])]);
  const row = { ...fields, ...Object.fromEntries(owned) };
  const id = (await raw(ctx).insert(run.table as never, row as never)) as string;
  for (const [index, { machine }] of starts.entries()) await machine.born(ctx, id, states[index], event, by);
  return { status: "done", id, from: "start", to: states[starts.findIndex(({ machine }) => machine === run)].kind };
}

// A fixed sentence when it fails: the validator's own message quotes the value, which may be a stored one.
function checked(validator: AnyValidator, value: unknown, db: Db, code: ErrorCode, message: string) {
  try {
    validate(validator, value, { db: reader(db), throw: true });
  } catch (error) {
    if (error instanceof ValidationError) fail(code, message);
    throw error;
  }
}

/**
 * A machine on a table of `schema`. `rules` are data, which the diagrams and
 * checks read. The second argument is the code behind each name in them:
 * `callers`, `guards`, `effects`, and `links` (each link's rows).
 */
export function defineMachine<Schema extends AnySchema, const C extends Rules>(
  schema: Schema,
  rules: C & NoInfer<Validate<DataModelFromSchemaDefinition<Schema>, C>>,
  implementation: NoInfer<Implementation<DataModelFromSchemaDefinition<Schema>, C>>,
): Machine<DataModelFromSchemaDefinition<Schema>, C> {
  const { name, table } = rules as Rules;
  const field = rules.field ?? "state";
  const union = tablesOf(schema)[table]?.validator.fields?.[field];
  const members = stateUnion(union);
  if (!members) throw new Error(`defineMachine("${name}"): ${table}.${field} must be a required v.union of v.objects tagged with \`kind: v.literal(...)\`.`);
  const code = implementation as LooseCode;
  const manifest = frozen(buildManifest(rules, field, members));
  check(rules, union!, members, manifest, code);
  // Its timers sit on the row beside its state. A machine with none needs no field.
  const timersField = `${field}Timers`;
  const timers = tablesOf(schema)[table]?.validator.fields?.[timersField] ? timersField : undefined;
  if (!timers && manifest.states.some((state) => state.timers.length))
    throw new Error(`defineMachine("${name}"): it has timers, so ${table} needs \`${timersField}: machineTimers\` beside ${field}.`);

  const roles = Object.keys(rules.callers ?? {});
  const groupOf = new Map(manifest.events.map((event) => [event.type, event.from]));
  const on = new Map<string, Item0[]>();
  for (const item of manifest.transitions) on.set(`${item.from} ${item.event}`, [...(on.get(`${item.from} ${item.event}`) ?? []), item]);
  const candidates = (kind: string, type: string) => on.get(`${kind} ${type}`) ?? [];
  const startOnly = new Set(manifest.events.map(({ type }) => type).filter((type) => manifest.transitions.every((item) => item.event !== type || item.from === "start")));
  const validators = new Map(manifest.events.map(({ type, from }) => [type, v.object({ type: v.literal(type), ...rules.events[from][type] }) as AnyValidator]));
  const fromOf = (by: By) => (by.kind === "link" ? { machine: by.machine, id: by.id } : undefined);
  const rejected = (code: Rejected["code"], reasons: string[]): Rejected => ({ status: "rejected", code, reasons });

  // Who may send this event: a role (after its check), or the internal ctx for a `server` event.
  function sender(event: Event, ctx: object): By {
    const group = groupOf.get(event.type);
    if (group === undefined || (group !== "server" && !roles.includes(group))) fail("INVALID_EVENT", `${name} has no event ${event.type} that a caller can send.`);
    if (group !== "server") return { kind: "role", role: group };
    if (!isInternal(ctx)) fail("INTERNAL_ONLY", `${event.type} is a server event: send it from a function built with the app's internalMutation.`);
    return { kind: "server" };
  }
  // "EDIT isn't possible while building. It's possible from ready."
  function notAccepted(kind: string, type: string) {
    if (manifest.states.find((state) => state.kind === kind)?.final) return `${kind} is final. Nothing more can happen.`;
    const from = manifest.states.filter((state) => candidates(state.kind, type).length).map((state) => state.kind);
    return from.length ? `${type} isn't possible while ${kind}. It's possible from ${from.join(", ")}.` : `${type} isn't possible in ${name}.`;
  }
  // The row, with its state checked against its member of the union (a
  // migration, an import or a deploy with schema validation off can't hand a
  // guard half a state), as a frozen copy.
  async function loadRow(db: Db, id: string): Promise<Loose | null> {
    const normal = db.normalizeId(table as never, id);
    const row = normal && ((await db.get(normal)) as Loose | null);
    if (!row) return null;
    const state = row[field] as State | undefined;
    const member = members!.get(state?.kind as string);
    if (!member) fail("UNKNOWN_STATE", `A ${table} row's ${field} isn't one of ${name}'s states.`);
    checked(member, state, db, "UNKNOWN_STATE", `A ${table} row's ${field} isn't a valid ${state!.kind}.`);
    return snapshot(row);
  }
  function validEvent(event: Event, by: By, db: Db) {
    if (by.kind === "link" && groupOf.get(event.type) !== by.machine) fail("INVALID_EVENT", `${name} doesn't take ${event.type} from ${by.machine}.`);
    if (by.kind !== "timer") checked(validators.get(event.type)!, event, db, "INVALID_EVENT", `${event.type}'s payload isn't what ${name} declares for it.`);
  }
  // The role check: `send` and `create` run it before any guard, and `inspect` to pick the events it lists.
  async function allowed(ctx: AnyCtx, by: By, id: string | undefined, row: Loose) {
    if (by.kind !== "role" || (await code.callers![by.role](...([guardCtx(ctx), { id, row }] as never[])))) return null;
    return rejected("NOT_ALLOWED", [rules.callers![by.role]]);
  }
  /** No writes. Guards run in order and stop at the first that fails, so the reads are only what the path needed. */
  async function decide(ctx: AnyCtx, kind: string, args: Loose & { event: Event }): Promise<Item0 | Rejected> {
    const options = candidates(kind, args.event.type);
    if (!options.length) return rejected("NOT_ACCEPTED", [notAccepted(kind, args.event.type)]);
    const reasons = new Set<string>();
    for (const transition of options) {
      let blocked: string | undefined;
      for (const guard of transition.guards)
        if (!(await code.guards![guard](...([guardCtx(ctx), args] as never[])))) {
          blocked = guard;
          break;
        }
      if (blocked === undefined) return transition;
      reasons.add(rules.guards![blocked]);
    }
    return rejected("GUARD_BLOCKED", [...reasons]);
  }

  // Runs the transition's effect, with a `create` for the rows it declares,
  // and checks it returned the whole state it goes to.
  async function effect(ctx: AnyCtx, transition: Item0, args: Loose & { state?: State; event: Event }, step: Step | null) {
    const to = transition.to ?? args.state!.kind;
    const created: Record<string, string[]> = {};
    const done = new Set<CreateRule>();
    let [creating, failed] = [false, false];
    const create = async (machine: unknown, fields: Loose, event: Event) => {
      const target = runtimeOf(machine);
      const rule = transition.creates.find((item) => item.machine === target.name && item.event === event.type);
      const first = !creating;
      creating = true;
      try {
        if (!rule || !step)
          fail("UNDECLARED_CREATE", `${name}'s ${args.event.type} step created a ${target.name} by ${event.type}, which its \`creates\` doesn't declare.`);
        if (!first) fail("CONCURRENT_SEND", `${name}'s effect created two rows at once. Await each create in turn.`);
        const result = await birth(ctx, target, fields, event, { kind: "link", machine: name, id: step.id }, step.run);
        if (result.status !== "done") fail("LINK_REFUSED", `${name} created a ${target.name}, and its start refused ${event.type}: ${result.reasons.join(" ")}`);
        done.add(rule);
        (created[target.table] ??= []).push(result.id);
        return result.id;
      } catch (error) {
        // The child may have written before it threw: the step fails, even if the effect catches this.
        remember(raw(ctx), error);
        failed = true;
        throw error;
      } finally {
        if (first) creating = false;
      }
    };
    const run = transition.effect ? code.effects![transition.effect] : undefined;
    // The guarded db, and no runMutation or runQuery: a nested function would run outside this step.
    const own = { ...ctx, db: guardDb(raw(ctx), catalogOf(runtime).owned), runMutation: undefined, runQuery: undefined };
    // A create that failed fails the step as its effect ends, caught or not, before anything is saved or sent,
    // with the worst failure remembered: a bug, not a refusal after or before it.
    let next: State;
    try {
      next = run ? await run(...([own, { ...args, to, create }] as never[])) : transition.to ? { kind: to } : args.state!;
    } catch (error) {
      throw failed ? failures.get(raw(ctx)) : error;
    }
    if (failed) throw failures.get(raw(ctx));
    for (const rule of transition.creates)
      if (!done.has(rule)) fail("UNDECLARED_CREATE", `${name}'s ${args.event.type} step declares it creates a ${rule.machine}, and its effect didn't.`);
    if (next?.kind !== to) fail("WRONG_STATE", `${name}'s ${transition.effect} effect returned ${String(next?.kind)}, not the whole ${to} state.`);
    checked(members!.get(to)!, next, raw(ctx), "WRONG_STATE", `${name}'s ${transition.effect} effect returned a ${to} the schema refuses.`);
    // Frozen once: what's saved, compared, given to links and returned.
    return { next: frozen(next), created };
  }

  // The row's timers once a step has run. Leaving a state cancels them, and
  // entering one arms its own. Staying keeps them, but an `at` timer moves
  // when its field does, and a fired `after` timer is armed again from now:
  // so a timer whose step stays put is periodic. A fired `at` timer whose
  // field didn't move is spent: its time has passed. A timer no state has any
  // more (the rules changed) is cancelled. No timers before or after: no work.
  async function nextTimers(ctx: AnyCtx, id: string, current: readonly Timer[], before: State | null, after: State, fired?: string) {
    const moved = before?.kind !== after.kind;
    const wanted = manifest.states.find((state) => state.kind === after.kind)!.timers;
    const kept: Timer[] = [];
    for (const timer of current)
      if (moved || !wanted.some((want) => want.event === timer.event) || kept.some((other) => other.event === timer.event)) await cancelIfPending(ctx, timer.job);
      else kept.push(timer);
    for (const { event, after: ms, at } of wanted) {
      const dueAt = at !== undefined ? (moved || before![at] !== after[at] ? (after[at] as number) : undefined) : moved || event === fired ? Date.now() + ms! : undefined;
      if (dueAt === undefined) continue;
      if (!Number.isFinite(dueAt)) fail("WRONG_STATE", `${name}'s ${after.kind} is due to send ${event} at ${at}, which isn't a finite time.`);
      const old = kept.findIndex((timer) => timer.event === event);
      if (old >= 0) await cancelIfPending(ctx, kept.splice(old, 1)[0].job);
      kept.push({ event, dueAt, job: await ctx.scheduler.runAt(dueAt, catalogOf(runtime).deliver!, { machine: name, id, event, dueAt }) });
    }
    return kept;
  }

  // After a step is saved: its links, so each receiver sees this row's new
  // state. The step's own resolver, LINK_TARGET and its link limits fail it
  // whatever the policy. "rollback" steps the receiver inline, and its
  // refusal throws. "ignore" steps it in a sub-transaction (the catalog's
  // delivery mutation, by ctx.runMutation): if it refuses, or a rollback link
  // below it is refused, its writes are undone, this step stands, and the
  // reason is recorded here. Anything else it throws fails this step.
  async function deliver(ctx: AnyCtx, id: string, before: State, next: State, transition: Item0, event: Event, by: By, step: Step) {
    const db = raw(ctx);
    const ignored: string[] = [];
    for (const send of transition.sends) {
      const target = catalogOf(runtime).machines.get(send.machine)!;
      // Read for each link, so it sees what an earlier one did to this row.
      const row = snapshot(await db.get(id as GenericId<string>));
      const found = await code.links![`${send.machine}.${send.event}`](...([{ db: reader(db), id, row, state: before, next, event }] as never[]));
      for (const targetId of Array.isArray(found) ? found : [found]) {
        if (typeof targetId !== "string" || !db.normalizeId(target.table as never, targetId))
          fail("LINK_TARGET", `${name}'s link ${send.machine}.${send.event} gave a row that isn't in ${target.table}: return its IDs ([] for none).`);
        const [linkBy, link] = hop(step, name, target.name, targetId);
        if (send.onRefused === "rollback") {
          const result = await target.apply(ctx, targetId, { type: send.event }, linkBy, link);
          if (result.status !== "done") fail("LINK_REFUSED", `${name}'s ${event.type} step sent ${send.event}, and the ${send.machine} refused it: ${result.reasons.join(" ")}`);
          continue;
        }
        const args = { machine: send.machine, id: targetId, event: send.event, link: { machine: name, id, depth: link.depth, budget: step.run.budget } };
        // A refusal below it comes back as LINK_REFUSED, with the budget its branch left.
        const result = await ctx.runMutation(catalogOf(runtime).deliver!, args).catch((error: unknown) => {
          if (!refused(error)) throw error;
          const { message, budget } = (error as ConvexError<{ message: string; budget: number }>).data;
          return { status: "rejected" as const, reasons: [message], budget };
        });
        step.run.budget = result.budget;
        if (result.status === "rejected") ignored.push(`${send.machine} ${targetId} refused ${send.event}: ${result.reasons.join(" ")}`);
      }
    }
    if (ignored.length) await record(ctx, { subject: id, kind: "ignored", event: event.type, from: before.kind, to: next.kind, by, reasons: ignored });
  }
  // One fact, through the history component. With history off, nothing is
  // recorded, and a refusal nobody else would see goes to the logs.
  async function record(ctx: AnyCtx, { by, ...fact }: Fact) {
    if (!manifest.history) {
      if (fact.kind === "refused" || fact.kind === "ignored") console.log(`${name} ${fact.subject}: ${fact.kind} ${fact.event}. ${fact.reasons.join(" ")}`);
      return;
    }
    await ctx.runMutation(catalogOf(runtime).component!.lib.record, { facts: [{ machine: name, ...fact, by: byText(by) }] });
  }

  async function inspect(ctx: AnyCtx, id: string, given: Event[] = []): Promise<Inspection | null> {
    catalogOf(runtime);
    const db = raw(ctx);
    // What `send` would refuse, inspect refuses the same way.
    for (const event of given) validEvent(event, sender(event, {}), db);
    const row = await loadRow(db, id);
    if (!row) return null;
    const state = row[field] as State;
    const events: NextStep[] = [];
    let caller = false;
    for (const role of roles) {
      if (await allowed(ctx, { kind: "role", role }, id, row)) continue;
      caller = true;
      for (const [type, payload] of Object.entries(rules.events[role] ?? {})) {
        if (startOnly.has(type)) continue;
        const tried = given.find((item) => item.type === type);
        // A payload with required fields can't be guessed: the page supplies the event to try.
        const needsInput = !tried && candidates(state.kind, type).length && Object.values(payload).some((item) => item.isOptional === "required");
        const decision = needsInput ? null : await decide(ctx, state.kind, { id, row, state, event: snapshot(tried ?? { type }), from: undefined });
        if (!decision) events.push({ event: type, to: null, allowed: "needs_input", reasons: [] });
        else if ("status" in decision) events.push({ event: type, to: null, allowed: false, code: decision.code, reasons: decision.reasons });
        else events.push({ event: type, to: decision.to, allowed: true, reasons: [] });
      }
    }
    return caller ? { kind: state.kind, events, timers: timersOf(runtime, row).map(({ event, dueAt }) => ({ event, dueAt })) } : null;
  }

  // Each group's validator for the events a row takes, or for its start events. A group with none has no key.
  const groups = [...roles, ...(rules.events.server ? ["server"] : [])];
  const startEvents = new Set(manifest.transitions.filter((item) => item.from === "start").map((item) => item.event));
  const validatorsOf = (keep: (type: string) => boolean) =>
    Object.fromEntries(
      groups.flatMap((group) => {
        const events = manifest.events.filter((event) => event.from === group && keep(event.type)).map((event) => validators.get(event.type)!);
        return events.length ? [[group, events.length === 1 ? events[0] : v.union(...(events as never[]))]] : [];
      }),
    );
  // And for an endpoint's `returns`, built once the catalog says which tables this machine's creates are on.
  const kinds = v.union(...[...members.keys()].map((kind) => v.literal(kind)));
  const codes = v.union(v.literal("NOT_ALLOWED"), v.literal("NOT_ACCEPTED"), v.literal("GUARD_BLOCKED"));
  const refusal = v.object({ status: v.literal("rejected"), code: codes, reasons: v.array(v.string()) });
  const asked = roles.flatMap((role) => Object.keys(rules.events[role] ?? {})).filter((type) => !startOnly.has(type));
  let results: Loose | undefined;
  const resultsOf = () => {
    const made = new Set(manifest.transitions.flatMap((item) => item.creates.map((rule) => catalogOf(runtime).machines.get(rule.machine)!.table)));
    const created = v.object(Object.fromEntries([...made].map((other) => [other, v.optional(v.array(v.id(other)))])));
    const answer = v.object({
      ...{ event: v.union(...asked.map((type) => v.literal(type))), to: v.union(kinds, v.null()) },
      ...{ allowed: v.union(v.boolean(), v.literal("needs_input")), code: v.optional(codes), reasons: v.array(v.string()) },
    });
    const inspection = v.object({ kind: kinds, events: v.array(answer), timers: v.array(v.object({ event: v.string(), dueAt: v.number() })) });
    return {
      create: v.union(v.object({ status: v.literal("done"), id: v.id(table), from: v.literal("start"), to: kinds }), refusal),
      send: v.union(v.object({ status: v.literal("done"), from: kinds, to: kinds, created }), refusal),
      // Without a role, inspect is always null. With one, an object, its events empty if they're all start events.
      inspect: roles.length ? v.union(v.null(), inspection) : v.null(),
    };
  };

  const runtime: Runtime = {
    ...{ name, table, field, timers, rules, manifest, record },

    async apply(ctx: AnyCtx, id: string, event: Event, by: By, step: Step): Promise<SendResult> {
      const db = raw(ctx);
      validEvent(event, by, db);
      const row = await loadRow(db, id);
      if (!row && by.kind === "link") return rejected("NOT_ACCEPTED", [`No ${table} row with that ID.`]);
      if (!row) fail("NOT_FOUND", `No ${table} row with that ID.`);
      const state = row[field] as State;
      // What the step compares its result with: a copy no callback gets, as freezing can't stop one writing into an ArrayBuffer.
      const stored = snapshot(state);
      const refused = await allowed(ctx, by, id, row);
      if (refused) return refused;
      const args = { id, row, state, event: snapshot(event), from: fromOf(by) };
      const transition = await decide(ctx, state.kind, args);
      if ("status" in transition) {
        // A timer's event its state refused: the timer is spent, and nobody else would see why.
        if (by.kind === "timer") await record(ctx, { subject: id, kind: "refused", event: event.type, from: state.kind, to: state.kind, by, reasons: transition.reasons });
        return transition;
      }
      step.run.wrote = true;
      const { next, created } = await effect(ctx, transition, args, step);
      const current = timersOf(runtime, row);
      const armed = timers && (await nextTimers(ctx, id, current, state, next, by.kind === "timer" ? event.type : undefined));
      // Staying put with nothing changed doesn't write the row, so nothing reading it re-runs.
      const changed = { ...(same(next, stored) ? {} : { [field]: next }), ...(timers && !same(armed, current) ? { [timers]: armed } : {}) };
      if (Object.keys(changed).length) await db.patch(id as GenericId<string>, changed as never);
      await record(ctx, { subject: id, kind: "step", event: event.type, from: state.kind, to: next.kind, by, reasons: [] });
      await deliver(ctx, id, state, next, transition, args.event, by, step);
      // Where the row is now: a link back to it may have moved it on.
      const now = transition.sends.length ? (((await db.get(id as GenericId<string>)) as Loose)[field] as State) : next;
      return { status: "done", from: state.kind, to: now.kind, created };
    },

    async admit(ctx: AnyCtx, fields: Loose, event: Event, by: By) {
      validEvent(event, by, raw(ctx));
      const row = snapshot(fields);
      return (await allowed(ctx, by, undefined, row)) ?? (await decide(ctx, "start", { id: undefined, row, state: undefined, event: snapshot(event), from: fromOf(by) }));
    },
    begin: async (ctx: AnyCtx, fields: Loose, event: Event, by: By, transition: Item0) =>
      (await effect(ctx, transition, { id: undefined, row: snapshot(fields), state: undefined, event: snapshot(event), from: fromOf(by) }, null)).next,
    async born(ctx: AnyCtx, id: string, state: State, event: Event, by: By) {
      const armed = timers ? await nextTimers(ctx, id, [], null, state) : [];
      if (armed.length) await raw(ctx).patch(id as GenericId<string>, { [timers!]: armed } as never);
      await record(ctx, { subject: id, kind: "step", event: event.type, from: "start", to: state.kind, by, reasons: [] });
    },
  };

  // The public machine: what an app calls. Every method needs the machine to be in a catalog.
  const machine = {
    ...{ name, table, field, manifest },
    events: validatorsOf((type) => !startOnly.has(type)),
    startEvents: validatorsOf((type) => startEvents.has(type)),
    get results() {
      return (results ??= resultsOf());
    },
    async create(ctx: AnyCtx, fields: Loose, event: Event) {
      catalogOf(runtime);
      return await exclusive(ctx, (shared) => birth(ctx, runtime, fields, event, sender(event, ctx), shared));
    },
    async send(ctx: AnyCtx, id: string, event: Event) {
      catalogOf(runtime);
      return await exclusive(ctx, (shared) => runtime.apply(ctx, id, event, sender(event, ctx), { id, depth: 0, run: shared }));
    },
    inspect,
    async purge(ctx: AnyCtx, id: string, options: { force?: boolean } = {}) {
      catalogOf(runtime);
      internalOnly(ctx, `${name}.purge`);
      await exclusive(ctx, async (shared) => {
        const db = raw(ctx);
        const normal = db.normalizeId(table as never, id);
        const row = (normal && ((await db.get(normal)) as Loose | null)) || fail("NOT_FOUND", `No ${table} row with that ID.`);
        const machines = machinesOn(runtime);
        // A state the rules don't know (renamed by a refactor) isn't refused.
        const busy = machines.filter((machine) => machine.manifest.states.some((state) => state.kind === (row[machine.field] as State)?.kind && !state.final));
        const states = busy.map((machine) => `${machine.name} ${(row[machine.field] as State).kind}`).join(" and ");
        if (busy.length && !options.force) fail("NOT_FINAL", `The ${table} row is ${states}, not final: send it to a final state first, or force it.`);
        shared.wrote = true;
        for (const machine of machines) for (const timer of timersOf(machine, row)) await cancelIfPending(ctx, timer.job);
        for (const machine of machines) {
          const [from, reasons] = [String((row[machine.field] as State)?.kind), busy.includes(machine) ? ["forced"] : []];
          await machine.record(ctx, { subject: id, kind: "purged", event: "", from, to: "", by: { kind: "server" }, reasons });
        }
        await db.delete(normal as GenericId<string>);
      });
    },
    async armTimers(ctx: AnyCtx, id: string) {
      catalogOf(runtime);
      internalOnly(ctx, `${name}.armTimers`);
      return await exclusive(ctx, async (shared) => {
        const db = raw(ctx);
        const row = (await loadRow(db, id)) ?? fail("NOT_FOUND", `No ${table} row with that ID.`);
        if (!timers) return [];
        shared.wrote = true;
        const armed = await nextTimers(ctx, id, timersOf(runtime, row), null, row[field] as State);
        await db.patch(id as GenericId<string>, { [timers]: armed } as never);
        return armed.map(({ event, dueAt }) => ({ event, dueAt }));
      });
    },
    async history(ctx: HistoryCtx, id: string, { paginationOpts, order }: { paginationOpts: PaginationOptions; order?: "asc" | "desc" }) {
      const { component } = catalogOf(runtime);
      if (!manifest.history || !component) return { page: [], isDone: true, continueCursor: "" };
      return await ctx.runQuery(component.lib.list, { machine: name, subject: id, order, paginationOpts });
    },
  };
  runtimes.set(machine, runtime);
  return machine as unknown as Machine<DataModelFromSchemaDefinition<Schema>, C>;
}

// -------------------------------------------------------------- The catalog

/**
 * Every machine, in one list, and the app's builders, made from Convex's
 * raw `mutation`, `internalMutation` and `internalQuery`. The delivery
 * mutation, the diagrams and the checks take them from here too. Throws,
 * with every problem at once, if a state field in the schema has no machine
 * or two, or if a link or a create doesn't line up. `deliver` is the app's delivery
 * mutation, which timers and `ignore` links need: `internal.machines.deliver`.
 * `component` is this package's component, installed in convex.config.ts,
 * which every machine that keeps history needs: `components.stateMachines`.
 */
export function defineMachines<Schema extends AnySchema>(
  schema: Schema,
  machines: readonly AnyMachine[],
  options: {
    mutation: MutationBuilder<DataModelFromSchemaDefinition<Schema>, "public">;
    internalMutation: MutationBuilder<DataModelFromSchemaDefinition<Schema>, "internal">;
    internalQuery: QueryBuilder<DataModelFromSchemaDefinition<Schema>, "internal">;
    deliver?: DeliveryRef;
    component?: ComponentApi;
  },
) {
  type DM = DataModelFromSchemaDefinition<Schema>;
  const runs = machines.map(runtimeOf);
  const byName = new Map(runs.map((run) => [run.name, run]));
  const owned = ownedFields(schema);
  const problems = linkProblems(runs.map((run) => run.manifest));
  for (const [table, fields] of stateFields(schema))
    for (const field of fields) {
      const holders = runs.filter((run) => run.table === table && run.field === field).map((run) => run.name);
      if (!holders.length) problems.push(`${table}.${field} holds a state union, but no machine in the catalog is on it.`);
      if (holders.length > 1) problems.push(`${table}.${field} belongs to ${holders.join(" and ")}: a state field has one machine.`);
    }
  // Machines on one row are born together: by the same events, from the same senders.
  const starts = ({ manifest }: Runtime) =>
    [...new Set(manifest.transitions.filter((item) => item.from === "start").map((item) => `${item.event} from ${manifest.events.find((e) => e.type === item.event)?.from}`))]
      .sort()
      .join(", ");
  for (const run of runs) {
    if (runs.filter((other) => other.name === run.name).length > 1) problems.push(`Two machines are named "${run.name}".`);
    if (run.catalog) problems.push(`${run.name} is already in a catalog: an app has one, in convex/machines.ts.`);
    const sibling = runs.find((other) => other !== run && other.table === run.table && starts(other) !== starts(run));
    if (sibling)
      problems.push(`${[run.name, sibling.name].sort().join(" and ")} share ${run.table}, so their starts take the same events, from the same senders.`);
    if (!stateFields(schema).get(run.table)?.includes(run.field)) problems.push(`${run.name}'s ${run.table}.${run.field} isn't a state union in this schema.`);
    for (const role of Object.keys(run.rules.callers ?? {})) if (byName.has(role)) problems.push(`${run.name}'s role "${role}" is also a machine's name.`);
    const delivers = run.manifest.states.some((state) => state.timers.length) || run.manifest.transitions.some((item) => item.sends.some((send) => send.onRefused === "ignore"));
    if (!options.deliver && delivers) problems.push(`${run.name} has timers or ignore links, so pass \`deliver\`: internal.machines.deliver.`);
    if (!options.component && run.manifest.history)
      problems.push(`${run.name} keeps history, so install the stateMachines component and pass \`component\`: components.stateMachines. Or set \`history: false\` on it.`);
  }
  if (problems.length) throw new Error(`defineMachines:\n- ${[...new Set(problems)].join("\n- ")}`);
  const catalog: Catalog = { machines: byName, owned, deliver: options.deliver, component: options.component };
  for (const run of runs) run.catalog = catalog;
  const machineOf = (name: string) => {
    const run = byName.get(name);
    if (!run) throw new Error(`No machine "${name}" in the catalog.`);
    return run;
  };
  // A machine's pending timer on a row, by its event (and its due time, for a delivery), with the row's list it's in.
  async function pendingTimer(db: Db, run: Runtime, { id, event, dueAt }: { id: string; event: string; dueAt?: number }) {
    const normal = run.timers ? db.normalizeId(run.table as never, id) : null;
    const list = timersOf(run, normal && ((await db.get(normal)) as Loose | null));
    const timer = list.find((item) => item.event === event && (dueAt === undefined || item.dueAt === dueAt));
    return timer && { id: normal!, list, timer };
  }

  // The app's mutation builders (convex-helpers' customMutation): a guarded
  // db, and after the handler returns, a machine step that threw once it had
  // begun writing fails the mutation, even if the handler caught it. Only
  // the internal ones add the brand, and nothing else here exposes it.
  const builder = <Extra extends object>(extra: Extra) => ({
    args: {},
    input: (ctx: GenericMutationCtx<DM>) => ({
      ctx: { db: guardDb(raw(ctx), owned) as unknown as GuardedDb<DM>, ...extra },
      args: {},
      onSuccess: () => {
        if (failures.has(raw(ctx))) throw failures.get(raw(ctx));
      },
    }),
  });

  return {
    /** Every machine's manifest, for the diagrams. */
    manifests: runs.map((run) => run.manifest),
    /** The app's `mutation`: its db can't write a machine's state or delete its rows. */
    mutation: customMutation(options.mutation, builder({})),
    /** The app's `internalMutation`: the same, and the internal brand, which `server` events, purge and the functions below need. */
    internalMutation: customMutation(options.internalMutation, builder({ [INTERNAL]: true } as InternalCtx)),
    /** The app's `internalQuery`: the internal brand on a query's ctx, so a page can watch `failedTimers` live. A query can't write, so its db isn't guarded. */
    internalQuery: customQuery(options.internalQuery, { args: {}, input: () => ({ ctx: { [INTERNAL]: true } as InternalCtx, args: {} }) }),
    /**
     * The delivery mutation's handler: `machines.internalMutation({ args: deliveryArgs, handler: machines.deliver })`.
     * A timer's event at its due time: one delivery, so if its step throws,
     * it all rolls back and the timer stays pending, its job failed, until
     * rearmTimer. Or an `ignore` link's event, which its sender runs by
     * ctx.runMutation: a sub-transaction, whose refusal comes back as
     * LINK_REFUSED with the budget it left.
     */
    async deliver(ctx: StepCtx<DM> & InternalCtx, args: DeliveryArgs): Promise<Delivered> {
      internalOnly(ctx, "machines.deliver");
      const [run, c, link] = [machineOf(args.machine), ctx as unknown as AnyCtx, args.link];
      const db = raw(c);
      return await exclusive(
        c,
        async (shared) => {
          try {
            // A timer that was superseded (its state was left, or its `at` field moved it), or whose row is gone, does nothing.
            const pending = link || args.dueAt === undefined ? undefined : await pendingTimer(db, run, { ...args, dueAt: args.dueAt });
            // Taking it off the row is the step's first write, so a guard that throws can't commit it alone.
            if (pending) {
              shared.wrote = true;
              await db.patch(pending.id, { [run.timers!]: pending.list.filter((item) => item !== pending.timer) } as never);
            }
            const live = link || pending;
            const by: By = link ? { kind: "link", machine: link.machine, id: link.id } : { kind: "timer" };
            const depth = link ? within(link.depth, MAX_LINK_DEPTH) : 0;
            const result = live ? await run.apply(c, args.id, { type: args.event }, by, { id: args.id, depth, run: shared }) : undefined;
            return { status: result?.status ?? "skipped", reasons: result?.status === "rejected" ? result.reasons : [], budget: shared.budget };
          } catch (error) {
            // A refusal goes back with the budget its branch left. A bug the step remembered can't pass for one.
            const failure = failures.has(db) && !refused(failures.get(db)) ? failures.get(db) : error;
            throw link && refused(failure) ? new ConvexError({ ...(failure as ConvexError<{ code: string; message: string }>).data, budget: shared.budget }) : failure;
          }
        },
        link && within(link.budget, LINK_BUDGET),
      );
    },
    /** For an operator: schedules a pending timer's delivery again, at its due time (now, if that's past). */
    async rearmTimer(ctx: StepCtx<DM> & InternalCtx, args: { machine: string; id: string; event: string }) {
      internalOnly(ctx, "machines.rearmTimer");
      const db = raw(ctx);
      const pending = (await pendingTimer(db, machineOf(args.machine), args)) ?? fail("NOT_FOUND", `${args.machine} has no pending ${args.event} timer on that row.`);
      await cancelIfPending(ctx as unknown as AnyCtx, pending.timer.job);
      const job = await ctx.scheduler.runAt(pending.timer.dueAt, catalog.deliver!, { ...args, dueAt: pending.timer.dueAt });
      await db.patch(pending.id, { [machineOf(args.machine).timers!]: pending.list.map((item) => (item === pending.timer ? { ...item, job } : item)) } as never);
    },
    /**
     * For an operator, a cron or a page: timers whose delivery threw, newest
     * first. Each stays pending on its row until rearmTimer delivers it. It
     * only reads, so it runs from the app's internalQuery too, where a page
     * watches it live. Read from Convex's own record of scheduled functions,
     * which it keeps for 7 days: `limit` is how many failed deliveries to
     * look through. Other functions' failures (crons, actions) aren't
     * counted, so a burst of them can't hide an older stuck timer.
     */
    async failedTimers(ctx: ReaderCtx<DM> & InternalCtx, { limit = 100 }: { limit?: number } = {}) {
      internalOnly(ctx, "machines.failedTimers");
      const db = raw(ctx);
      const failed: { machine: string; id: string; event: string; dueAt: number }[] = [];
      if (!catalog.deliver) return failed;
      const delivery = functionKey(getFunctionName(catalog.deliver));
      // There's no index on a job's state or name, so this reads newest first until it has seen `limit` failed deliveries.
      let seen = 0;
      for await (const job of db.system.query("_scheduled_functions").order("desc")) {
        if (job.state.kind !== "failed" || functionKey(job.name) !== delivery) continue;
        if (seen++ >= limit) break;
        const args = job.args[0] as Partial<DeliveryArgs> | undefined;
        const run = typeof args?.machine === "string" ? byName.get(args.machine) : undefined;
        if (!run || typeof args?.id !== "string" || typeof args.event !== "string" || typeof args.dueAt !== "number") continue;
        const pending = await pendingTimer(db, run, { id: args.id, event: args.event, dueAt: args.dueAt });
        if (pending?.timer.job === job._id) failed.push({ machine: run.name, id: args.id, event: args.event, dueAt: args.dueAt });
      }
      return failed;
    },
    /** For an operator or a cron: deletes up to 500 history rows written before `before` (ms), oldest first. Run it until `more` is false. */
    async pruneHistory(ctx: StepCtx<DM> & InternalCtx, { before }: { before: number }) {
      internalOnly(ctx, "machines.pruneHistory");
      if (!catalog.component) return { deleted: 0, more: false };
      return await (ctx as unknown as AnyCtx).runMutation(catalog.component.lib.prune, { before });
    },
  };
}
/** The catalog's type, to write on `machines`: its delivery reference is typed by the module that exports it. */
export type Machines<Schema extends AnySchema> = ReturnType<typeof defineMachines<Schema>>;

// --------------------------------------------------- Checks and manifest

function buildManifest(rules: Rules, field: string, members: Map<string, AnyValidator>): Manifest {
  return {
    name: rules.name,
    table: rules.table,
    field,
    history: rules.history !== false,
    states: [...members].map(([kind, member]) => {
      const timers = Object.entries(rules.states[kind]?.timers ?? {}).map(([event, timer]) => ({ event, ...timer }));
      const data = Object.entries(member.fields!).flatMap(([key, value]) => (key === "kind" ? [] : [value.isOptional === "optional" ? `${key}?` : key]));
      return { kind, data, final: !rules.states[kind]?.on && !timers.length, timers };
    }),
    events: Object.entries(rules.events).flatMap(([from, events]) =>
      Object.entries(events).map(([type, payload]) => ({ type, from, fields: Object.entries(payload).map(([key, value]) => (value.isOptional === "optional" ? `${key}?` : key)) })),
    ),
    callers: { ...rules.callers },
    guards: { ...rules.guards },
    transitions: ["start", ...members.keys()].flatMap((from) =>
      Object.entries(rules.states[from]?.on ?? {}).flatMap(([event, entry]) =>
        list<Transition>(entry).map((item, index, items) => ({
          ...{ from, event, to: item.to ?? null, guards: list(item.guard) },
          ...(item.effect ? { effect: item.effect } : {}),
          sends: list(item.sends).map((send) => ({ machine: send.machine, event: send.event, onRefused: send.onRefused })),
          creates: list(item.creates).map((rule) => ({ machine: rule?.machine, event: rule?.event })),
          ...(Array.isArray(entry) && items.length > 1 ? { order: { index: index + 1, of: items.length } } : {}),
        })),
      ),
    ),
  };
}

/** Throws on the mistakes the types can't see, or that plain JS makes. */
function check(rules: Rules, union: AnyValidator, members: Map<string, AnyValidator>, manifest: Manifest, code: LooseCode) {
  const problems: string[] = [];
  const kinds = new Set(members.keys());
  const events = new Map(manifest.events.map((event) => [event.type, event.from]));
  const roles = Object.keys(rules.callers ?? {});
  const timers = Object.values(rules.states).flatMap((state) => Object.keys(state.timers ?? {}));
  const all = union.members!.map((member) => member.fields!.kind.value as string);
  for (const kind of new Set(all.filter((kind, index) => all.indexOf(kind) !== index)))
    problems.push(`Two members of ${rules.table}.${manifest.field}'s union have kind "${kind}": each state has one.`);
  if (manifest.field !== "state" && !manifest.field.endsWith("State")) problems.push(`The field "${manifest.field}" should be \`state\`, or \`<name>State\`.`);
  for (const word of new Set([rules.name, ...roles, ...kinds, ...events.keys(), ...timers]))
    if (RESERVED.includes(word)) problems.push(`"${word}" is reserved, so it can't be a name.`);
    else if (!NAME.test(word)) problems.push(`"${word}" isn't a plain name: use letters, digits and _, like "timedOut".`);
  if (manifest.events.length !== events.size) problems.push(`An event is declared under two senders: each event has one.`);
  for (const [group, declared] of Object.entries(rules.events))
    for (const [type, payload] of Object.entries(declared)) {
      if ("type" in payload) problems.push(`${type}'s payload has a field named "type", which is the event's own: rename it.`);
      if (group !== "server" && !roles.includes(group) && Object.keys(payload).length) problems.push(`${type} comes from the ${group} machine: no payload, read its row by \`from.id\`.`);
    }
  for (const role of roles) {
    if (!rules.events[role]) problems.push(`Role "${role}" sends no events.`);
    if (!code.callers?.[role]) problems.push(`Role "${role}" has no code in \`callers\`.`);
  }
  if (!rules.states.start?.on) problems.push(`It needs \`states.start\`: the events a row is born by.`);
  for (const kind of kinds) if (!rules.states[kind]) problems.push(`State "${kind}" (from the schema) has no rules.`);
  for (const [kind, rule] of Object.entries(rules.states)) {
    if (kind !== "start" && !kinds.has(kind)) problems.push(`"${kind}" isn't a state in the schema's union.`);
    if (rule.on && !Object.keys(rule.on).length) problems.push(`"${kind}" has \`on: {}\`: a final state, which takes no events, is written \`{}\`.`);
    for (const [event, entry] of Object.entries(rule.on ?? {}))
      if (Array.isArray(entry) && !entry.length) problems.push(`"${kind}" on ${event} is an empty list, which takes the event and does nothing: give it a transition, or leave it out.`);
    for (const [timer, spec] of Object.entries(rule.timers ?? {})) {
      if (events.has(timer)) problems.push(`"${kind}"'s timer ${timer} has the name of an event.`);
      const at = "at" in spec ? members.get(kind)?.fields?.[spec.at] : undefined;
      if ("at" in spec && (at?.kind !== "float64" || at.isOptional !== "required")) problems.push(`"${kind}"'s timer ${timer} is at "${spec.at}", not a required number in its data.`);
      if ("after" in spec && !(Number.isFinite(spec.after) && spec.after > 0)) problems.push(`"${kind}"'s timer ${timer} is after ${spec.after} ms: it must be finite and above 0.`);
      if (!manifest.transitions.some((item) => item.event === timer && item.from === kind)) problems.push(`"${kind}"'s timer ${timer} has no transition.`);
    }
  }
  for (const item of manifest.transitions) {
    const where = `"${item.from}" on ${item.event}`;
    const timer = Object.keys(rules.states[item.from]?.timers ?? {}).includes(item.event);
    if (!events.has(item.event) && !timer) problems.push(`${where}: no such event, or timer of this state.`);
    if (item.to !== null && !kinds.has(item.to)) problems.push(`${where} goes to unknown state "${item.to}".`);
    if (item.to === item.from) problems.push(`${where} goes to its own state: leave \`to\` out to stay. For a new deadline, move an \`at\` timer's field.`);
    if (item.from === "start" && item.to === null) problems.push(`${where} needs \`to\`: the state the row starts in.`);
    if (item.from === "start" && item.creates.length) problems.push(`${where} can't create: its row doesn't exist yet.`);
    if (item.from === "start" && item.sends.length) problems.push(`${where} can't send: its row may be born inside its creator's step.`);
    if (item.to !== null && !item.effect && Object.keys(members.get(item.to)?.fields ?? {}).length > 1) problems.push(`${where} enters "${item.to}", whose data needs an effect.`);
    if (item.creates.length && !item.effect) problems.push(`${where} creates, but only an effect can: it has none.`);
    for (const rule of item.creates) if (typeof rule.machine !== "string" || typeof rule.event !== "string") problems.push(`${where}: \`creates\` is { machine, event }.`);
    for (const send of item.sends) {
      if (send.onRefused !== "rollback" && send.onRefused !== "ignore") problems.push(`${where} sends ${send.event} to ${send.machine}: say \`onRefused: "rollback"\` or \`"ignore"\`.`);
      if (timer && send.onRefused === "rollback") problems.push(`${where} is a timer's: its link sends with \`onRefused: "ignore"\`, or a refusal would fail the timer's step every time it's rearmed.`);
      if (!code.links?.[`${send.machine}.${send.event}`]) problems.push(`Link "${send.machine}.${send.event}" has no code in \`links\`.`);
    }
    if (item.order && !item.guards.length && item.order.index < item.order.of) problems.push(`${where}: item ${item.order.index} has no guard, so the rest never run.`);
    for (const guard of item.guards) if (!rules.guards?.[guard]) problems.push(`${where} uses undeclared guard "${guard}".`);
    if (item.effect && !code.effects?.[item.effect]) problems.push(`Effect "${item.effect}" has no code.`);
  }
  for (const guard of Object.keys(rules.guards ?? {})) if (!code.guards?.[guard]) problems.push(`Guard "${guard}" has no code.`);
  for (const type of events.keys()) if (!manifest.transitions.some((item) => item.event === type)) problems.push(`Event ${type} isn't handled by any state.`);
  if (problems.length) throw new Error(`defineMachine("${rules.name}"):\n- ${[...new Set(problems)].join("\n- ")}`);
}

/**
 * The links across machines: each `sends` names a machine that takes that
 * event from the sender, each `creates` a machine whose start takes its
 * event from the creator, and each event a machine takes from another is sent.
 */
function linkProblems(machines: Manifest[]): string[] {
  const problems: string[] = [];
  const byName = new Map(machines.map((machine) => [machine.name, machine]));
  const takes = (target: Manifest, from: string, event: string) => target.events.some((item) => item.type === event && item.from === from);
  const starts = (target: Manifest, event: string) => target.transitions.some((item) => item.from === "start" && item.event === event);
  for (const machine of machines) {
    for (const item of machine.transitions) {
      const where = `${machine.name} ${item.from} on ${item.event}`;
      for (const { machine: name, event } of item.creates)
        if (!byName.has(name)) problems.push(`${where} creates "${name}", which isn't defined.`);
        else if (!takes(byName.get(name)!, machine.name, event) || !starts(byName.get(name)!, event))
          problems.push(`${where} creates a ${name} by ${event}, but its start doesn't take ${event} from ${machine.name}.`);
      for (const { machine: target, event } of item.sends)
        if (!byName.has(target)) problems.push(`${where} sends to "${target}", which isn't defined.`);
        else if (!takes(byName.get(target)!, machine.name, event)) problems.push(`${where} sends ${event} to ${target}, which doesn't take it from ${machine.name}.`);
    }
    for (const { type, from } of machine.events) {
      if (from === "server" || from in machine.callers) continue;
      const sender = byName.get(from);
      const sent = sender?.transitions.some((item) => [...item.sends, ...item.creates].some((link) => link.machine === machine.name && link.event === type));
      if (!sender) problems.push(`${machine.name} takes ${type} from "${from}", which isn't a role or a defined machine.`);
      else if (!sent) problems.push(`${machine.name} takes ${type} from ${from}, which never sends it.`);
    }
  }
  return problems;
}
