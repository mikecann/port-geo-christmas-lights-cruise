import type { Manifest } from "./machine.js";

// Mermaid diagrams, drawn straight from manifests: the frozen rules each
// machine runs, read off its definition and its schema validator. One to one
// with the declared transitions: every arrow is a transition or a link in
// the definition, and nothing else is drawn. A self-loop always means the
// row stays in its state.
//
//   stateDiagram(manifest, all?)  one machine: how a row is born (with the row's other machines), its states and transitions
//   linkedDiagram(manifests)      an overview: every machine as a box, and the links and creates between them

type Transition = Manifest["transitions"][number];

const UNITS = [
  ["day", 86_400_000],
  ["hour", 3_600_000],
  ["minute", 60_000],
  ["second", 1_000],
] as const;
/** 1209600000 is "14 days", 20000 is "20 seconds". */
export function duration(ms: number) {
  for (const [unit, size] of UNITS) if (ms >= size && ms % size === 0) return `${ms / size} ${unit}${ms === size ? "" : "s"}`;
  return `${ms} ms`;
}
// Mermaid treats a few characters in labels as syntax.
const clean = (text: string) => text.replace(/[:;#"{}]/g, " ").replace(/\s+/g, " ").trim();

// A list is tried in order, so its items say where they are: [1. guard],
// [2. guard], and the last, unguarded one [else].
function guardText(item: Transition) {
  if (item.order && !item.guards.length) return " [else]";
  if (item.order) return ` [${item.order.index}. ${item.guards.join(", ")}]`;
  return item.guards.length ? ` [${item.guards.join(", ")}]` : "";
}

// Who sends it: a role or the server, with the payload's fields (`EDIT(prompt) (owner)`), a machine's link, or a timer.
// A birth names the row's other machines, born by the same event.
function transitionText(machine: Manifest, item: Transition, siblings: string[]) {
  const timer = machine.states.find((state) => state.kind === item.from)?.timers.find((candidate) => candidate.event === item.event);
  const event = machine.events.find((candidate) => candidate.type === item.event);
  const from = event?.from ?? "";
  let text = timer
    ? `${item.event} ${timer.at ? `at ${timer.at}` : `after ${duration(timer.after!)}`}`
    : from === "server" || from in machine.callers
      ? `${item.event}${event?.fields.length ? `(${event.fields.join(", ")})` : ""} (${from})`
      : `${item.event} from ${from}`;
  text += guardText(item);
  if (item.effect) text += ` / ${item.effect}`;
  const links = [
    ...(item.from === "start" && siblings.length ? [`born with ${siblings.join(" and ")}`] : []),
    ...item.creates.map((rule) => `creates 1+ ${rule.machine} by ${rule.event}`),
    ...item.sends.map((send) => `sends ${send.event} to ${send.machine} (${send.onRefused})`),
  ];
  return clean([text, ...links].join(", "));
}

/** One machine, as a Mermaid stateDiagram-v2. Each state is named, with its own data fields under it (`?` if optional). Pass every manifest to mark a shared row's births. */
export function stateDiagram(machine: Manifest, all: Manifest[] = []): string {
  const siblings = all.filter((other) => other.table === machine.table && other.name !== machine.name).map((other) => other.name);
  const lines = ["stateDiagram-v2", "  direction LR"];
  for (const { kind, data } of machine.states) lines.push(`  state "${kind}" as ${kind}`, ...(data.length ? [`  ${kind} : ${clean(data.join(", "))}`] : []));
  for (const item of machine.transitions) lines.push(`  ${item.from === "start" ? "[*]" : item.from} --> ${item.to ?? item.from} : ${transitionText(machine, item, siblings)}`);
  for (const state of machine.states) if (state.final) lines.push(`  ${state.kind} --> [*]`);
  return lines.join("\n");
}

/**
 * An overview: every machine as one box, and the links between them. A
 * solid arrow for each `creates`, labelled with the start event the rows are
 * born by, and a dotted one for each `sends`, with its event and what a
 * refusal does. Each machine's own diagram has its states and transitions.
 */
export function linkedDiagram(machines: Manifest[]): string {
  const lines = ["flowchart LR"];
  for (const machine of machines) lines.push(`  ${machine.name}["${machine.name}<br/>${machine.table}.${machine.field}"]`);
  const seen = new Set<string>();
  const arrow = (line: string) => {
    if (!seen.has(line)) lines.push(line);
    seen.add(line);
  };
  for (const machine of machines)
    for (const item of machine.transitions) {
      for (const rule of item.creates) arrow(`  ${machine.name} -->|"${clean(`creates 1+ by ${rule.event}`)}"| ${rule.machine}`);
      for (const send of item.sends) arrow(`  ${machine.name} -.->|"${clean(`${send.event} (${send.onRefused})`)}"| ${send.machine}`);
    }
  return lines.join("\n");
}
