import { defineSchema, defineTable, internalMutationGeneric, makeFunctionReference, mutationGeneric } from "convex/server";
import { ConvexError, v, type GenericId, type ObjectType } from "convex/values";
import { validate } from "convex-helpers/validators";
import { convexTest } from "convex-test";
import { afterEach, beforeEach, describe, expect, test, vi } from "vitest";
import { color, guest, HEARTBEAT_MS, job, kit, KIT_MS, machines, MAX_RUN_MS, part, ping, poll, power, probe, room, tester, TICK_MS } from "./fixtures/machines.fixture.js";
import schema from "./fixtures/schema.fixture.js";
import { defineMachine, defineMachines, deliveryArgs, machineTimers } from "./machine.js";
import { duration, linkedDiagram, stateDiagram } from "./mermaid.js";
import { advance, asInternal, components, historyOf, initFixtureTest, modules } from "./setup.test.js";

// The library's features, on the fixture machines (fixtures/machines.fixture.ts).

beforeEach(() => vi.useFakeTimers());
afterEach(() => {
  vi.restoreAllMocks();
  vi.useRealTimers();
});

async function codeOf(promise: Promise<unknown>) {
  try {
    await promise;
    return "ok";
  } catch (caught) {
    return caught instanceof ConvexError ? (caught.data as { code: string }).code : String(caught);
  }
}
const thrown = (run: () => unknown) => {
  try {
    run();
    return "";
  } catch (error) {
    return (error as Error).message;
  }
};

type T = ReturnType<typeof initFixtureTest>;
type Ctx = Parameters<Parameters<T["run"]>[0]>[0];
type Loosely = (...args: unknown[]) => Promise<unknown>;
const internal = (ctx: Ctx) => asInternal(machines, ctx);
const MIA = { subject: "mia" };
const jobState = (t: T, id: GenericId<"jobs">) => t.run(async (ctx) => (await ctx.db.get("jobs", id))!.state);
const history = (t: T, machine: string, subject: string) => historyOf(t, machine, subject);
// A machine's timers on a row: `<field>Timers`, beside its state. None once the row is gone.
const timers = (t: T, machine: string, subject: string) =>
  t.run(async (ctx) => {
    const { table, field } = machines.manifests.find((manifest) => manifest.name === machine)!;
    const row = (await ctx.db.get(table as never, subject as never)) as Record<string, unknown> | null;
    return (row?.[`${field}Timers`] ?? []) as { event: string; dueAt: number; job: GenericId<"_scheduled_functions"> }[];
  });
// Scheduled functions still waiting to run.
const pendingJobs = (t: T) => t.run(async (ctx) => (await ctx.db.system.query("_scheduled_functions").collect()).filter((job) => job.state.kind === "pending"));
const ledger = (t: T) => t.run(async (ctx) => (await ctx.db.query("ledger").collect()).map((row) => row.note));
async function created<R>(result: Promise<R>) {
  const done = (await result) as { status: string; id?: unknown };
  if (done.status !== "done") throw new Error(`Not created: ${JSON.stringify(done)}`);
  return done.id as R extends { id: infer Id } ? Id : never;
}
const startJob = async (t: T) => {
  const id = await created(t.withIdentity(MIA).run((ctx) => job.create(ctx, { owner: "mia" }, { type: "SUBMIT" })));
  await t.run(async (ctx) => job.send(await internal(ctx), id, { type: "START" }));
  return id;
};
// Testers, due a minute from now, whose code each test supplies through `probe`.
const makeTesters = (t: T, count: number) =>
  t.run(async (ctx) => {
    const ids = [];
    for (let index = 0; index < count; index++) ids.push(await created(tester.create(ctx, { name: `t${index}` }, { type: "MAKE", dueAt: Date.now() + 60_000 })));
    return ids;
  });
const testerState = (t: T, id: GenericId<"testers">) => t.run(async (ctx) => (await ctx.db.get("testers", id))!.state);
const poke = (t: T, id: GenericId<"testers">) => t.run((ctx) => tester.send(ctx, id, { type: "POKE" }));
// What an app passes the catalog: Convex's raw builders.
const builders = { mutation: mutationGeneric, internalMutation: internalMutationGeneric };
// A tiny schema and machine, for the definition checks.
const tiny = defineSchema({
  things: defineTable({ state: v.union(v.object({ kind: v.literal("here") }), v.object({ kind: v.literal("gone") })), stateTimers: machineTimers }),
});
const defineThing = (rules: object, code: object = { callers: { anyone: () => true } }) =>
  thrown(() =>
    defineMachine(tiny, { name: "thing", table: "things", callers: { anyone: "" }, events: { anyone: { MAKE: {} } }, ...rules } as never, code as never),
  );

describe("a row is born by an event", () => {
  test("a guarded start picks the first state and its data, and arms that state's timers", async () => {
    const t = initFixtureTest();
    const asMia = t.withIdentity(MIA);
    const retryAt = Date.now() + 5_000;
    const later = await created(asMia.run((ctx) => job.create(ctx, { owner: "mia" }, { type: "SUBMIT", retryAt })));
    const now = await created(asMia.run((ctx) => job.create(ctx, { owner: "mia" }, { type: "SUBMIT" })));
    expect(await jobState(t, later)).toEqual({ kind: "waiting", attempt: 0, retryAt });
    expect(await jobState(t, now)).toEqual({ kind: "queued" });
    await advance(t, 4_900);
    expect((await jobState(t, later)).kind).toBe("waiting");
    await advance(t, 200);
    expect(await jobState(t, later)).toMatchObject({ kind: "running", attempt: 1 });
    expect((await history(t, "job", later)).map(({ kind, event, from, to, by }) => [kind, event, from, to, by])).toEqual([
      ["step", "SUBMIT", "start", "waiting", "owner"],
      ["step", "RETRY", "waiting", "running", "timer"],
    ]);
  });

  test("the role's check runs on create, with the fields the row would have, and internal code doesn't skip it", async () => {
    const t = initFixtureTest();
    const refused = { status: "rejected", code: "NOT_ALLOWED", reasons: ["Only the job's owner can do that."] };
    expect(await t.withIdentity({ subject: "sam" }).run((ctx) => job.create(ctx, { owner: "mia" }, { type: "SUBMIT" }))).toEqual(refused);
    // Internal code has no identity, so it isn't Mia: it can't act as her.
    expect(await t.run(async (ctx) => job.create(await internal(ctx), { owner: "mia" }, { type: "SUBMIT" }))).toEqual(refused);
    expect(await t.run((ctx) => ctx.db.query("jobs").collect())).toEqual([]);
  });

  test("two machines on one row are born by one event, and each link finds its rows on the row as it is by then", async () => {
    const t = initFixtureTest();
    const lamp = await created(t.run((ctx) => power.create(ctx, { name: "Desk lamp" }, { type: "INSTALL" })));
    const row = () => t.run(async (ctx) => (await ctx.db.get("lamps", lamp))!);
    expect(await row()).toMatchObject({ powerState: { kind: "off" }, colorState: { kind: "white" } });
    // TURN_ON tells color WARM, then SHINE. SHINE's rows are found after WARM
    // stepped color, from the row as it is by then.
    await t.run((ctx) => power.send(ctx, lamp, { type: "TURN_ON" }));
    expect(await row()).toMatchObject({ powerState: { kind: "on", since: expect.any(Number) }, colorState: { kind: "colored", hue: 40 } });
    await t.run((ctx) => color.send(ctx, lamp, { type: "PAINT", hue: 30 }));
    await t.run((ctx) => color.send(ctx, lamp, { type: "RESET" }));
    expect(await row()).toMatchObject({ powerState: { kind: "on" }, colorState: { kind: "white" } });
    // Each machine's birth is in its own history, once.
    expect((await history(t, "power", lamp)).map(({ event, from, to }) => [event, from, to])).toEqual([
      ["INSTALL", "start", "off"],
      ["TURN_ON", "off", "on"],
    ]);
    expect((await history(t, "color", lamp)).map(({ event, by }) => [event, by])).toEqual([
      ["INSTALL", "anyone"],
      ["WARM", `power:${lamp}`],
      ["SHINE", `power:${lamp}`],
      ["PAINT", "anyone"],
      ["RESET", "anyone"],
    ]);
  });

  test("a start can't send or create", () => {
    const start = (transition: object) => ({ states: { start: { on: { MAKE: { to: "here", ...transition } } }, here: { on: { DROP: { to: "gone" } } }, gone: {} } });
    const events = { events: { anyone: { MAKE: {}, DROP: {} }, thing: { PING: {} } } };
    expect(defineThing({ ...start({ sends: [{ machine: "thing", event: "PING", onRefused: "ignore" }] }), ...events })).toContain(
      `"start" on MAKE can't send: its row may be born inside its creator's step.`,
    );
    expect(defineThing({ ...start({ effect: "make", creates: { machine: "thing", event: "MAKE" } }), ...events })).toContain(`"start" on MAKE can't create`);
  });
});

describe("timers", () => {
  test("a due time in the state's data: each heartbeat moves it, and it fires when they stop", async () => {
    const t = initFixtureTest();
    const id = await startJob(t);
    for (let beat = 0; beat < 3; beat++) {
      await advance(t, HEARTBEAT_MS - 2_000);
      await t.run(async (ctx) => job.send(await internal(ctx), id, { type: "HEARTBEAT", note: `beat ${beat}` }));
    }
    expect((await jobState(t, id)).kind).toBe("running");
    await advance(t, HEARTBEAT_MS + 100);
    // STALLED fired, and its guarded choice backed off: attempt 1 waits 4 seconds.
    expect(await jobState(t, id)).toMatchObject({ kind: "waiting", attempt: 1 });
  });

  test("two timers in one state: the fixed one fires even while heartbeats hold the other off", async () => {
    const t = initFixtureTest();
    const id = await startJob(t);
    for (let elapsed = 0; elapsed < MAX_RUN_MS; elapsed += 5_000) {
      await t.run(async (ctx) => job.send(await internal(ctx), id, { type: "HEARTBEAT", note: "busy" }));
      await advance(t, 5_000);
    }
    expect(await jobState(t, id)).toEqual({ kind: "failed", attempt: 1, reason: "TOO_LONG" });
    // Leaving `running` cancelled STALLED with it: nothing is pending.
    expect(await timers(t, "job", id)).toEqual([]);
  });

  test("a timer chooses through guards, and the backoff grows from the data", async () => {
    const t = initFixtureTest();
    const id = await startJob(t);
    for (let hop = 0; hop < 7 && (await jobState(t, id)).kind !== "failed"; hop++) await advance(t, 20_000);
    // Stalled, waits 4 s; runs again, stalls, waits 16 s; third stall fails: no retries left.
    expect(await jobState(t, id)).toEqual({ kind: "failed", attempt: 3, reason: "STALLED" });
  });

  test("a timer whose step stays put fires again from now; one its guard refuses is spent, and logged with history off", async () => {
    const t = initFixtureTest();
    const log = vi.spyOn(console, "log").mockImplementation(() => {});
    const id = await created(t.run((ctx) => poll.create(ctx, {}, { type: "WATCH", stopAt: 3 })));
    const state = () => t.run(async (ctx) => (await ctx.db.get("polls", id))!.state);
    await advance(t, TICK_MS * 2 + 100);
    expect(await state()).toEqual({ kind: "watching", ticks: 2, stopAt: 3 });
    expect(await timers(t, "poll", id)).toEqual([expect.objectContaining({ event: "TICK", dueAt: Date.now() - 100 + TICK_MS })]);
    await advance(t, TICK_MS * 3);
    // The third tick, then the fourth: its guard refused it, so it's spent.
    expect(await state()).toEqual({ kind: "watching", ticks: 3, stopAt: 3 });
    expect(await timers(t, "poll", id)).toEqual([]);
    // `history: false`: nothing is recorded, and the refusal goes to the logs instead.
    expect(await history(t, "poll", id)).toEqual([]);
    expect(log).toHaveBeenCalledWith(`poll ${id}: refused TICK. It has ticked enough.`);
  });

  test("`after` is a finite number above 0, and `to` its own state isn't a re-entry: both are definition errors", () => {
    const states = (here: object) => ({ events: { anyone: { MAKE: {}, AGAIN: {} } }, states: { start: { on: { MAKE: { to: "here" } } }, here, gone: {} } });
    // `after: 0` with a step that stays would fire it in a loop.
    for (const after of [0, -1, NaN, Infinity])
      expect(defineThing(states({ timers: { LATE: { after } }, on: { LATE: {}, AGAIN: { to: "gone" } } }))).toContain(
        `"here"'s timer LATE is after ${after} ms: it must be finite and above 0.`,
      );
    expect(defineThing(states({ on: { AGAIN: { to: "here" } } }))).toContain(`"here" on AGAIN goes to its own state: leave \`to\` out to stay.`);
  });

  test("a due time that isn't a finite number is WRONG_STATE, before anything is scheduled", async () => {
    const t = initFixtureTest();
    const [id] = await makeTesters(t, 1);
    for (const dueAt of [NaN, Infinity]) {
      vi.spyOn(probe, "poke").mockImplementationOnce(async (_ctx, { state }) => ({ ...state, dueAt }));
      expect(await codeOf(poke(t, id))).toBe("WRONG_STATE");
    }
    expect(await timers(t, "tester", id)).toHaveLength(1);
  });

  test("inspect shows this caller's events and the pending timers, not their jobs; a caller with no role gets null", async () => {
    const t = initFixtureTest();
    const id = await startJob(t);
    const inspection = await t.withIdentity(MIA).run((ctx) => job.inspect(ctx, id));
    // SUBMIT only starts a job, so a job that exists doesn't list it.
    expect(inspection).toEqual({
      kind: "running",
      events: [{ event: "CANCEL", to: null, allowed: false, code: "NOT_ACCEPTED", reasons: ["CANCEL isn't possible while running. It's possible from queued, waiting."] }],
      timers: expect.arrayContaining([
        { event: "STALLED", dueAt: Date.now() + HEARTBEAT_MS },
        { event: "TOO_LONG", dueAt: Date.now() + MAX_RUN_MS },
      ]),
    });
    // Someone else's job: none of its events are theirs, so it tells them nothing.
    expect(await t.withIdentity({ subject: "sam" }).run((ctx) => job.inspect(ctx, id))).toBeNull();
  });

  test("a timer whose step throws is one failed delivery: it stays, failedTimers lists it, and rearmTimer delivers it", async () => {
    const t = initFixtureTest();
    const [id] = await makeTesters(t, 1);
    const spy = vi.spyOn(probe, "poke").mockImplementationOnce(async (ctx) => {
      await (ctx as Ctx).db.insert("ledger", { note: "half done" });
      throw new Error("payments service unavailable");
    });
    await advance(t, 61_000);
    expect(spy).toHaveBeenCalledTimes(1);
    expect(await testerState(t, id)).toMatchObject({ n: 0 });
    expect(await ledger(t)).toEqual([]);
    expect(await t.run((ctx) => tester.inspect(ctx, id))).toMatchObject({ timers: [{ event: "DUE", dueAt: expect.any(Number) }] });
    // An operator finds it without knowing the row, and retries it.
    expect(await t.run(async (ctx) => machines.failedTimers(await internal(ctx), {}))).toEqual([{ machine: "tester", id, event: "DUE", dueAt: expect.any(Number) }]);
    await t.run(async (ctx) => machines.rearmTimer(await internal(ctx), { machine: "tester", id, event: "DUE" }));
    await advance(t, 100);
    expect(await testerState(t, id)).toMatchObject({ n: 1 });
    // Its due time didn't move, so it's spent, and nothing is failed any more.
    expect(await timers(t, "tester", id)).toEqual([]);
    expect(await t.run(async (ctx) => machines.failedTimers(await internal(ctx), {}))).toEqual([]);
  });

  test("a timer's deletion is its step's first write: internal code that catches its guard's error can't commit it alone", async () => {
    const t = initFixtureTest();
    const [id] = await makeTesters(t, 1);
    const [timer] = await timers(t, "tester", id);
    vi.spyOn(probe, "ok").mockRejectedValueOnce(new Error("The guard crashed."));
    const catchesDelivery = makeFunctionReference<"mutation", ObjectType<typeof deliveryArgs>>("fixtures/machines.fixture:catchesDelivery");
    // Marked as writing only at its effect, the handler's catch would commit the deletion alone, and the timer would be gone.
    expect(await codeOf(t.mutation(catchesDelivery, { machine: "tester", id, event: "DUE", dueAt: timer.dueAt }))).toContain("The guard crashed.");
    expect(await timers(t, "tester", id)).toEqual([timer]);
  });

  test("armTimers arms a migrated row's timers for its state, as if it had just entered it, from internal code only", async () => {
    const t = initFixtureTest();
    const [id] = await makeTesters(t, 1);
    const { dueAt } = (await testerState(t, id)) as { dueAt: number };
    // A row a migration moved into `idle`: the state, and no timers yet.
    await t.run((ctx) => ctx.db.patch("testers", id, { stateTimers: [] }));
    expect(await codeOf(t.run((ctx) => tester.armTimers(ctx as never, id)))).toBe("INTERNAL_ONLY");
    expect(await t.run(async (ctx) => tester.armTimers(await internal(ctx), id))).toEqual([{ event: "DUE", dueAt }]);
    // Again replaces it: still one timer.
    expect(await t.run(async (ctx) => tester.armTimers(await internal(ctx), id))).toEqual([{ event: "DUE", dueAt }]);
    expect(await timers(t, "tester", id)).toEqual([expect.objectContaining({ event: "DUE", dueAt })]);
    // It fires as any timer does, once.
    await advance(t, 61_000);
    expect(await testerState(t, id)).toMatchObject({ n: 1 });
    expect(await timers(t, "tester", id)).toEqual([]);
  });

  test("a failed timer goes with its state: the row can still move on another way", async () => {
    const t = initFixtureTest();
    const [id] = await makeTesters(t, 1);
    vi.spyOn(probe, "poke").mockRejectedValue(new Error("payments are down"));
    await advance(t, 61_000);
    expect(await timers(t, "tester", id)).toHaveLength(1);
    expect(await t.run((ctx) => tester.send(ctx, id, { type: "STOP" }))).toMatchObject({ status: "done", to: "done" });
    expect(await timers(t, "tester", id)).toEqual([]);
  });

  test("a timer's step whose create is refused is one failed delivery too, which failedTimers lists", async () => {
    const t = initFixtureTest();
    const kitId = await created(t.run((ctx) => kit.create(ctx, { name: "empty" }, { type: "OPEN" })));
    await advance(t, KIT_MS + 1_000);
    expect(await t.run(async (ctx) => (await ctx.db.get("kits", kitId))!.state)).toEqual({ kind: "open" });
    expect(await t.run(async (ctx) => machines.failedTimers(await internal(ctx), {}))).toEqual([expect.objectContaining({ machine: "kit", id: kitId, event: "LAPSED" })]);
  });
});

describe("effects return the whole next state, from inputs they can't change", () => {
  test("staying put returns the whole state; a partial, the wrong kind or an extra field is WRONG_STATE", async () => {
    const t = initFixtureTest();
    const [id] = await makeTesters(t, 1);
    expect(await poke(t, id)).toEqual({ status: "done", from: "idle", to: "idle", created: {} });
    vi.spyOn(probe, "poke").mockImplementationOnce(async () => ({ n: 5 }));
    expect(await codeOf(poke(t, id))).toBe("WRONG_STATE");
    vi.spyOn(probe, "poke").mockImplementationOnce(async (_ctx, { state }) => ({ kind: "done", n: state.n }));
    expect(await codeOf(poke(t, id))).toBe("WRONG_STATE");
    vi.spyOn(probe, "poke").mockImplementationOnce(async (_ctx, { state }) => ({ ...state, extra: true }));
    expect(await codeOf(poke(t, id))).toBe("WRONG_STATE");
    expect(await testerState(t, id)).toMatchObject({ kind: "idle", n: 1 });
  });

  test("an effect that changes its input throws, rather than lose the update", async () => {
    const t = initFixtureTest();
    const [id] = await makeTesters(t, 1);
    // Compared with the mutated input, the result would look unchanged and nothing would be written.
    vi.spyOn(probe, "poke").mockImplementationOnce(async (_ctx, { state }) => {
      (state as { n: number }).n++;
      return state;
    });
    expect(await codeOf(poke(t, id))).toMatch(/read.only/);
    vi.spyOn(probe, "poke").mockImplementationOnce(async (_ctx, args) => {
      (args as unknown as { row: { name: string } }).row.name = "renamed";
      return args.state;
    });
    expect(await codeOf(poke(t, id))).toMatch(/read.only/);
    expect(await testerState(t, id)).toMatchObject({ n: 0 });
  });

  test("an effect that writes into a buffer it was given still saves it: the step compares with a copy no callback gets", async () => {
    const t = initFixtureTest();
    const [id] = await makeTesters(t, 1);
    // Freezing can't stop a write into an ArrayBuffer, so compared with that input, the result would look unchanged and not be saved.
    vi.spyOn(probe, "poke").mockImplementationOnce(async (_ctx, { state }) => {
      new Uint8Array(state.data)[0] = 9;
      return state;
    });
    expect(await poke(t, id)).toMatchObject({ status: "done" });
    const state = await testerState(t, id);
    expect(state.kind === "idle" && [...new Uint8Array(state.data)]).toEqual([9]);
  });

  test("a link gets the state the step entered frozen: it's the one object saved, compared and returned", async () => {
    const t = initFixtureTest();
    const [a] = await makeTesters(t, 1);
    vi.spyOn(probe, "targets").mockImplementationOnce((args) => {
      (args as unknown as { next: { n: number } }).next.n = 99;
      return [];
    });
    expect(await codeOf(t.run((ctx) => tester.send(ctx, a, { type: "PING" })))).toMatch(/read.only/);
    expect(await testerState(t, a)).toMatchObject({ n: 0 });
  });

  test("an effect has no runMutation or runQuery: its nested mutation would step the row under it", async () => {
    const t = initFixtureTest();
    const [id] = await makeTesters(t, 1);
    vi.spyOn(probe, "poke").mockImplementationOnce(async (ctx, { state }) => {
      await (ctx as { runMutation: Loosely }).runMutation(makeFunctionReference("fixtures/machines.fixture:buildKit"), {});
      return state;
    });
    expect(await codeOf(poke(t, id))).toMatch(/not a function/);
    expect(await testerState(t, id)).toMatchObject({ n: 0 });
  });

  test("an effect can't write a machine's state, its own included, and a guard can't write at all", async () => {
    const t = initFixtureTest();
    const [id] = await makeTesters(t, 1);
    vi.spyOn(probe, "poke").mockImplementationOnce(async (ctx, { state }) => {
      await (ctx as Ctx).db.patch("testers", id, { state: { kind: "done", n: 99 } });
      return state;
    });
    expect(await codeOf(poke(t, id))).toBe("STATE_WRITE_OUTSIDE_MACHINE");
    vi.spyOn(probe, "ok").mockImplementationOnce(async (ctx) => {
      await (ctx as { db: { insert: Loosely } }).db.insert("ledger", { note: "sneaky" });
      return true;
    });
    expect(await codeOf(poke(t, id))).toMatch(/insert is not a function/);
    expect(await testerState(t, id)).toMatchObject({ kind: "idle", n: 0 });
  });

  test("a machine's code isn't on it, and its manifest is frozen: the diagram is what runs", () => {
    expect(Object.keys(tester)).not.toContain("implementation");
    expect(thrown(() => (tester.manifest.transitions as unknown[]).push({}))).toMatch(/not extensible/);
    expect(thrown(() => ((tester.manifest.transitions[0] as { to: string | null }).to = "done"))).toMatch(/read.only/);
  });
});

describe("creates", () => {
  test("an effect creates as many rows as it likes, outside the link budget, and the result lists them", async () => {
    const t = initFixtureTest();
    const kitId = await created(t.run((ctx) => kit.create(ctx, { name: "big" }, { type: "OPEN" })));
    // Creates aren't charged to the link budget, so this doesn't throw LINK_BUDGET.
    const result = await t.run((ctx) => kit.send(ctx, kitId, { type: "BUILD", count: 101, retry: false }));
    expect(result).toMatchObject({ status: "done", from: "open", to: "built" });
    const parts = await t.run((ctx) => ctx.db.query("parts").collect());
    expect(result.status === "done" && result.created).toEqual({ parts: parts.map((row) => row._id) });
    expect(parts).toHaveLength(101);
  });

  test("a failed create fails the mutation, even when the effect catches it, through the app's builder", async () => {
    const t = initFixtureTest();
    const kitId = await created(t.run((ctx) => kit.create(ctx, { name: "kit" }, { type: "OPEN" })));
    const buildKit = makeFunctionReference<"mutation", { kitId: GenericId<"kits">; count: number; retry: boolean }>("fixtures/machines.fixture:buildKit");
    // The flaky part writes its charge and throws; the effect catches it and makes a good one.
    expect(await codeOf(t.mutation(buildKit, { kitId, count: 1, retry: true }))).toContain("The card was declined.");
    expect(await ledger(t)).toEqual([]);
    expect(await t.run((ctx) => ctx.db.query("parts").collect())).toEqual([]);
    expect(await t.run(async (ctx) => (await ctx.db.get("kits", kitId))!.state)).toEqual({ kind: "open" });
    expect(await t.mutation(buildKit, { kitId, count: 1, retry: false })).toMatchObject({ status: "done", created: { parts: [expect.any(String)] } });
    expect(await ledger(t)).toEqual(["charged for a part"]);
  });

  test("an effect creates only what its transition declares, and creates what it declares", async () => {
    const t = initFixtureTest();
    const [id] = await makeTesters(t, 1);
    vi.spyOn(probe, "poke").mockImplementationOnce(async (_ctx, args) => {
      await ((args as unknown as { create: Loosely }).create as Loosely)(part, {}, { type: "MADE" });
      return args.state;
    });
    expect(await codeOf(poke(t, id))).toBe("UNDECLARED_CREATE");
    const kitId = await created(t.run((ctx) => kit.create(ctx, { name: "kit" }, { type: "OPEN" })));
    expect(await codeOf(t.run((ctx) => kit.send(ctx, kitId, { type: "BUILD", count: 0, retry: false })))).toBe("UNDECLARED_CREATE");
  });
});

describe("who may send what", () => {
  test("a role's events need its check, `server` events the internal ctx, and machines' and timers' events can't be sent", async () => {
    const t = initFixtureTest();
    const id = await created(t.withIdentity(MIA).run((ctx) => job.create(ctx, { owner: "mia" }, { type: "SUBMIT" })));
    expect(await codeOf(t.run((ctx) => job.send(ctx, id, { type: "START" } as never)))).toBe("INTERNAL_ONLY");
    expect(await codeOf(t.run(async (ctx) => job.send(await internal(ctx), id, { type: "STALLED" } as never)))).toBe("INVALID_EVENT");
    expect(await t.withIdentity({ subject: "sam" }).run((ctx) => job.send(ctx, id, { type: "CANCEL" }))).toMatchObject({ status: "rejected", code: "NOT_ALLOWED" });
    // Internal code runs the role's check too: it isn't Mia.
    expect(await t.run(async (ctx) => job.send(await internal(ctx), id, { type: "CANCEL" }))).toMatchObject({ status: "rejected", code: "NOT_ALLOWED" });
    expect(await t.withIdentity(MIA).run((ctx) => job.send(ctx, id, { type: "CANCEL" }))).toMatchObject({ status: "done", to: "failed" });
    expect((await history(t, "job", id)).at(-1)).toMatchObject({ event: "CANCEL", by: "owner" });
  });

  test("a wrong table's ID, a malformed payload, and a stored state the machine doesn't know are refused, without the state in the message", async () => {
    const t = initFixtureTest();
    const id = await startJob(t);
    const lamp = await created(t.run((ctx) => power.create(ctx, { name: "Lamp" }, { type: "INSTALL" })));
    expect(await codeOf(t.run(async (ctx) => job.send(await internal(ctx), lamp as never, { type: "FINISH" })))).toBe("NOT_FOUND");
    expect(await codeOf(t.run(async (ctx) => job.send(await internal(ctx), id, { type: "HEARTBEAT", note: 5 } as never)))).toBe("INVALID_EVENT");
    // A row whose state isn't one of the machine's, or is a known kind
    // without its data (schema validation off, a migration, a bad import).
    const stored = (state: object, look = false) =>
      t.run(async (ctx) => {
        const db = { ...ctx.db, normalizeId: ctx.db.normalizeId, get: async () => ({ _id: id, owner: "mia", state }) };
        try {
          if (look) await job.inspect({ ...ctx, db } as never, id);
          else await job.send(await internal({ ...ctx, db } as never), id, { type: "FINISH" });
        } catch (error) {
          return (error as ConvexError<{ code: string; message: string }>).data;
        }
      });
    expect(await stored({ kind: "lost", secret: "s3cret" })).toEqual({ code: "UNKNOWN_STATE", message: "A jobs row's state isn't one of job's states." });
    // A known kind with the wrong data is one fixed sentence: the validator's own quotes the value. Inspect checks the row before any role.
    for (const look of [false, true])
      for (const state of [{ kind: "running", attempt: 1, secret: "s3cret" }, { kind: "running", attempt: "s3cret", deadline: 1, note: "" }])
        expect(await stored(state, look)).toEqual({ code: "UNKNOWN_STATE", message: "A jobs row's state isn't a valid running." });
  });

  test("inspect checks the events it's given as send does", async () => {
    const t = initFixtureTest();
    const lamp = await created(t.run((ctx) => power.create(ctx, { name: "Lamp" }, { type: "INSTALL" })));
    expect(await codeOf(t.run((ctx) => color.inspect(ctx, lamp, [{ type: "PAINT", hue: "red" } as never])))).toBe("INVALID_EVENT");
    expect(await codeOf(t.run((ctx) => color.inspect(ctx, lamp, [{ type: "NOPE" } as never])))).toBe("INVALID_EVENT");
  });

  test("an event with required payload fields is needs_input until the page supplies one, with no guessed `to`", async () => {
    const t = initFixtureTest();
    const lamp = await created(t.run((ctx) => power.create(ctx, { name: "Lamp" }, { type: "INSTALL" })));
    const events = async (given?: { type: "PAINT"; hue: number }[]) => (await t.run((ctx) => color.inspect(ctx, lamp, given)))!.events;
    expect(await events()).toEqual([
      { event: "PAINT", to: null, allowed: "needs_input", reasons: [] },
      { event: "RESET", to: null, allowed: false, code: "NOT_ACCEPTED", reasons: ["RESET isn't possible while white. It's possible from warm, colored."] },
    ]);
    expect((await events([{ type: "PAINT", hue: 10 }]))[0]).toEqual({ event: "PAINT", to: "colored", allowed: true, reasons: [] });
  });

  test("a machine whose role sends only a start event inspects to an object, which its own validator takes", async () => {
    const things = defineSchema({ things: defineTable({ owner: v.string(), state: v.union(v.object({ kind: v.literal("open") }), v.object({ kind: v.literal("done") })) }) });
    // The owner creates it, and the server moves it on: no event of the owner's for a row that exists.
    const thing = defineMachine(
      things,
      {
        name: "thing",
        table: "things",
        history: false,
        callers: { owner: "Only its owner can do that." },
        events: { owner: { CREATE: {} }, server: { FINISH: {} } },
        states: { start: { on: { CREATE: { to: "open" } } }, open: { on: { FINISH: { to: "done" } } }, done: {} },
      },
      { callers: { owner: async (ctx, { row }) => (await ctx.auth.getUserIdentity())?.subject === row.owner } },
    );
    defineMachines(things, [thing], builders);
    const t = convexTest(things, modules).withIdentity(MIA);
    const id = await created(t.run((ctx) => thing.create(ctx, { owner: "mia" }, { type: "CREATE" })));
    const inspection = await t.run((ctx) => thing.inspect(ctx, id));
    expect(inspection).toEqual({ kind: "open", events: [], timers: [] });
    // The owner has no events for an existing row, but has a role, so inspect returns an object, not null.
    expect(validate(thing.results.inspect, inspection)).toBe(true);
    expect(validate(thing.results.inspect, null)).toBe(true);
    expect(validate(thing.results.inspect, { ...inspection, events: [{ event: "CREATE", to: null, allowed: false, reasons: [] }] })).toBe(false);
  });

  test("every method refuses until its machine is in a catalog, inspect too", async () => {
    const t = initFixtureTest();
    const [id] = await makeTesters(t, 1);
    const loner = defineMachine(
      schema,
      {
        name: "loner",
        table: "testers",
        callers: { anyone: "" },
        events: { anyone: { MAKE: { dueAt: v.number() }, STOP: {} } },
        states: { start: { on: { MAKE: { to: "idle", effect: "make" } } }, idle: { on: { STOP: { to: "done", effect: "stop" } } }, done: {} },
      },
      {
        callers: { anyone: () => true },
        effects: { make: async (_ctx, { event }) => ({ kind: "idle", n: 0, dueAt: event.dueAt, data: new ArrayBuffer(1) }), stop: async (_ctx, { state }) => ({ kind: "done", n: state.n }) },
      },
    );
    // It names both causes: a machine left out, and a file that never loads the catalog.
    const refused = "loner isn't in a catalog: add it to defineMachines, or import convex/machines (or convex/functions) in this file so the catalog loads.";
    expect(await codeOf(t.run((ctx) => loner.create(ctx, { name: "x" }, { type: "MAKE", dueAt: 1 })))).toContain(refused);
    expect(await codeOf(t.run((ctx) => loner.send(ctx, id, { type: "STOP" })))).toContain(refused);
    expect(await codeOf(t.run((ctx) => loner.inspect(ctx, id)))).toContain(refused);
    expect(await codeOf(t.run(async (ctx) => loner.purge(await internal(ctx), id)))).toContain(refused);
  });
});

describe("links", () => {
  async function setup() {
    const t = initFixtureTest();
    const roomId = await created(t.run((ctx) => room.create(ctx, { name: "Lobby" }, { type: "OPEN", inside: 3 })));
    const guests: GenericId<"guests">[] = [];
    for (const name of ["Mia", "Sam", "Ali"]) guests.push(await created(t.run((ctx) => guest.create(ctx, { roomId, name }, { type: "ARRIVE" }))));
    const roomState = () => t.run(async (ctx) => (await ctx.db.get("rooms", roomId))!.state);
    const guestKinds = () => t.run(async (ctx) => Promise.all(guests.map(async (id) => (await ctx.db.get("guests", id))!.state.kind)));
    return { t, roomId, guests, roomState, guestKinds };
  }

  test("`from` tells the receiver which row sent it, and history says so", async () => {
    const { t, roomId, guests, roomState } = await setup();
    expect(await t.run((ctx) => guest.send(ctx, guests[0], { type: "LEAVE" }))).toEqual({ status: "done", from: "inside", to: "left", created: {} });
    expect(await roomState()).toEqual({ kind: "open", inside: 2, lastLeft: guests[0] });
    expect((await history(t, "room", roomId)).at(-1)).toMatchObject({ kind: "step", event: "GUEST_LEFT", by: `guest:${guests[0]}` });
  });

  test("a fan-out to the rows a query found: the ones that refuse are ignored, and recorded in the sender's history", async () => {
    const { t, roomId, guests, roomState, guestKinds } = await setup();
    await t.run((ctx) => guest.send(ctx, guests[0], { type: "LEAVE" }));
    expect(await t.run((ctx) => room.send(ctx, roomId, { type: "CLOSE" }))).toMatchObject({ status: "done", from: "open", to: "closed" });
    expect((await roomState()).kind).toBe("closed");
    expect(await guestKinds()).toEqual(["left", "sentHome", "sentHome"]);
    // One row for the step, then one for what was ignored, in the order they happened.
    expect((await history(t, "room", roomId)).slice(-2).map(({ kind, event, reasons }) => [kind, event, reasons])).toEqual([
      ["step", "CLOSE", []],
      ["ignored", "CLOSE", [`guest ${guests[0]} refused ROOM_CLOSED: left is final. Nothing more can happen.`]],
    ]);
  });

  test("a guest can leave a closed room, and a purged one: the room refuses, and the guest leaves anyway", async () => {
    const { t, roomId, guestKinds } = await setup();
    await t.run((ctx) => room.send(ctx, roomId, { type: "CLOSE" }));
    const late = await created(t.run((ctx) => guest.create(ctx, { roomId, name: "Kim" }, { type: "ARRIVE" })));
    expect(await t.run((ctx) => guest.send(ctx, late, { type: "LEAVE" }))).toMatchObject({ status: "done", to: "left" });
    expect((await history(t, "guest", late)).at(-1)).toMatchObject({ kind: "ignored", event: "LEAVE", reasons: [expect.stringContaining("refused GUEST_LEFT")] });
    expect(await guestKinds()).toEqual(["sentHome", "sentHome", "sentHome"]);
    // A closed room is final, so it can be purged. A room that's gone refuses the same way.
    await t.run(async (ctx) => room.purge(await internal(ctx), roomId));
    const last = await created(t.run((ctx) => guest.create(ctx, { roomId, name: "Lee" }, { type: "ARRIVE" })));
    expect(await t.run((ctx) => guest.send(ctx, last, { type: "LEAVE" }))).toMatchObject({ status: "done", to: "left" });
    expect((await history(t, "guest", last)).at(-1)).toMatchObject({ kind: "ignored", reasons: [`room ${roomId} refused GUEST_LEFT: No rooms row with that ID.`] });
  });

  test("an ignore link's receiver that throws fails the sender's step, as it would inline: nothing commits, so it's retried", async () => {
    const t = initFixtureTest();
    const [a, b] = await makeTesters(t, 2);
    vi.spyOn(probe, "targets").mockImplementation(({ id }) => (id === a ? b : []));
    vi.spyOn(probe, "echo").mockImplementationOnce(async (ctx) => {
      await (ctx as Ctx).db.insert("ledger", { note: "the echo's write" });
      throw new Error("The echo broke.");
    });
    // Recorded as ignored, the sender's step would stand and nothing would retry the receiver.
    expect(await codeOf(t.run((ctx) => tester.send(ctx, a, { type: "PING" })))).toContain("The echo broke.");
    expect([(await testerState(t, a)).n, (await testerState(t, b)).n]).toEqual([0, 0]);
    expect(await ledger(t)).toEqual([]);
    // Fixed, the receiver's step commits with the sender's, from its own sub-transaction.
    expect(await t.run((ctx) => tester.send(ctx, a, { type: "PING" }))).toEqual({ status: "done", from: "idle", to: "idle", created: {} });
    expect([(await testerState(t, a)).n, (await testerState(t, b)).n]).toEqual([1, 10]);
  });

  test("a refusal below an ignore link is ignored too: the receiver's rollback link was refused, so its writes are undone and the sender's step stands", async () => {
    const t = initFixtureTest();
    const [a, b, done] = await makeTesters(t, 3);
    await t.run((ctx) => tester.send(ctx, done, { type: "STOP" }));
    vi.spyOn(probe, "targets").mockImplementation(({ id }) => (id === a ? b : id === b ? done : []));
    expect(await t.run((ctx) => tester.send(ctx, a, { type: "PING" }))).toMatchObject({ status: "done", to: "idle" });
    expect([(await testerState(t, a)).n, (await testerState(t, b)).n]).toEqual([1, 0]);
    expect((await history(t, "tester", a)).at(-1)).toMatchObject({
      kind: "ignored",
      reasons: [`tester ${b} refused ECHO: tester's ECHO step sent ECHO, and the tester refused it: done is final. Nothing more can happen.`],
    });
  });

  test("a branch an ignore link isolates spends the step's budget, refused or not: past 100 links the step fails", async () => {
    const t = initFixtureTest();
    const [a, b1, b2, done, ...leaves] = await makeTesters(t, 64);
    await t.run((ctx) => tester.send(ctx, done, { type: "STOP" }));
    // a tells b1 and b2 (ignore); each tells 60 leaves (rollback), and then a tester that refuses.
    vi.spyOn(probe, "targets").mockImplementation(({ id }) => (id === a ? [b1, b2] : id === b1 || id === b2 ? [...leaves, done] : []));
    const echoes = vi.spyOn(probe, "echo");
    // A refused branch still spends the budget: b1 and its 60 leaves, then b2 and the 37 the budget has left.
    expect(await codeOf(t.run((ctx) => tester.send(ctx, a, { type: "PING" })))).toBe("LINK_BUDGET");
    expect(echoes.mock.calls.length).toBe(99);
  });

  test("a refused birth that an ignore link's receiver caught comes back with the budget too, so the step's limits stay on", async () => {
    const t = initFixtureTest();
    await t.run((ctx) => kit.create(ctx, { name: "empty" }, { type: "OPEN" }));
    const kitId = await created(t.run((ctx) => kit.create(ctx, { name: "kit" }, { type: "OPEN" })));
    const [a, ...others] = await makeTesters(t, 101);
    // The kit's FILL caught a part the empty kit's start refused and made its own, so its step fails as it returns: a refusal, ignored, its writes undone.
    expect(await t.run((ctx) => tester.send(ctx, a, { type: "STOCK" }))).toMatchObject({ status: "done" });
    expect(await t.run(async (ctx) => (await ctx.db.get("kits", kitId))!.state)).toEqual({ kind: "open" });
    expect(await ledger(t)).toEqual([]);
    expect((await history(t, "tester", a)).at(-1)).toMatchObject({
      kind: "ignored",
      reasons: [`kit ${kitId} refused FILL: kit created a part, and its start refused MADE: The kit is empty.`],
    });
    // With 100 echoes after it, 101 links. The delivery throws that failure itself, with the budget it left; left to its builder, it came back
    // without one, the tester's budget became undefined, and no link after it was counted, so all 101 ran.
    vi.spyOn(probe, "targets").mockImplementation(({ id }) => (id === a ? others : []));
    expect(await codeOf(t.run((ctx) => tester.send(ctx, a, { type: "STOCK" })))).toBe("LINK_BUDGET");
  });

  test("a bug a receiver's effect caught fails its step as the effect ends, so no refusal can pass the branch off as refused", async () => {
    const t = initFixtureTest();
    const empty = await created(t.run((ctx) => kit.create(ctx, { name: "empty" }, { type: "OPEN" })));
    const kitId = await created(t.run((ctx) => kit.create(ctx, { name: "kit" }, { type: "OPEN" })));
    const [a] = await makeTesters(t, 1);
    // A flaky part writes its charge and throws, a bug; the empty kit's part is refused by its start.
    const [bug, good] = [{ kitId, flaky: true, caught: true }, { kitId, flaky: false, caught: false }];
    const refusal = (caught: boolean) => ({ kitId: empty, flaky: false, caught });
    for (const parts of [
      // The effect catches the bug and makes a good part, and the kit's rollback link to its parts after it is refused.
      [bug, good],
      // A refusal it caught before the bug, and one it didn't catch after it: the bug is the failure either way.
      [refusal(true), bug, good],
      [bug, refusal(false)],
    ]) {
      const fill = vi.spyOn(probe, "fill").mockReturnValueOnce(parts);
      // The refusal mustn't stand for the branch, or the tester's step would be done and the card's error lost.
      expect(await codeOf(t.run((ctx) => tester.send(ctx, a, { type: "STOCK" }))), JSON.stringify(parts)).toContain("The card was declined.");
      expect(fill).toHaveBeenCalledTimes(1);
      fill.mockRestore();
    }
    // The kit's step failed before saving or sending anything, and the tester's with it.
    expect(await t.run(async (ctx) => (await ctx.db.get("kits", kitId))!.state)).toEqual({ kind: "open" });
    expect(await t.run((ctx) => ctx.db.query("parts").collect())).toEqual([]);
    expect(await ledger(t)).toEqual([]);
    expect(await testerState(t, a)).toMatchObject({ n: 0 });
  });

  test("a delivery holds a link's depth and budget to the limits as it arrives, so no caller can lift them", async () => {
    const t = initFixtureTest();
    const deliver = (args: ObjectType<typeof deliveryArgs>) => t.run(async (ctx) => machines.deliver(await internal(ctx), args));
    // From depth -100 the TAP cycle would run its ten hops; from 0, its fifth is too deep.
    const id = await created(t.run((ctx) => ping.create(ctx, {}, { type: "CREATE", stopAt: 10 })));
    expect(await codeOf(deliver({ machine: "ping", id, event: "TAP", link: { machine: "ping", id, depth: -100, budget: 100 } }))).toBe("LINK_DEPTH");
    // A budget above 100 is 100, and NaN is 0: an echo's 101 onward links are too many for either.
    const [a, ...others] = await makeTesters(t, 102);
    vi.spyOn(probe, "targets").mockImplementation(({ id }) => (id === a ? others : []));
    for (const budget of [1e9, NaN])
      expect(await codeOf(deliver({ machine: "tester", id: a, event: "ECHO", link: { machine: "tester", id: a, depth: 0, budget } })), `budget ${budget}`).toBe("LINK_BUDGET");
  });

  test("a rollback link's receiver steps inline: when it throws or refuses, the whole mutation fails, both steps or neither", async () => {
    const t = initFixtureTest();
    const [a, b] = await makeTesters(t, 2);
    vi.spyOn(probe, "targets").mockImplementation(({ id }) => (id === a ? b : []));
    vi.spyOn(probe, "echo").mockRejectedValueOnce(new Error("The echo broke."));
    expect(await codeOf(t.run((ctx) => tester.send(ctx, a, { type: "PUSH" })))).toContain("The echo broke.");
    await t.run((ctx) => tester.send(ctx, b, { type: "STOP" }));
    expect(await codeOf(t.run((ctx) => tester.send(ctx, a, { type: "PUSH" })))).toBe("LINK_REFUSED");
    expect(await testerState(t, a)).toMatchObject({ n: 0 });
  });

  test("a link's rows must be IDs of its receiver's table: anything else is LINK_TARGET, and nothing is half done", async () => {
    const t = initFixtureTest();
    const [a] = await makeTesters(t, 1);
    const kitId = await created(t.run((ctx) => kit.create(ctx, { name: "kit" }, { type: "OPEN" })));
    for (const wrong of [undefined, kitId, [a, "nonsense"]]) {
      vi.spyOn(probe, "targets").mockReturnValueOnce(wrong);
      expect(await codeOf(t.run((ctx) => tester.send(ctx, a, { type: "PING" })))).toBe("LINK_TARGET");
    }
    expect(await testerState(t, a)).toMatchObject({ n: 0 });
  });

  test("past the link budget, the step fails whatever its links' policy: an ignore link's limits are its sender's", async () => {
    const t = initFixtureTest();
    const roomId = await created(t.run((ctx) => room.create(ctx, { name: "Hall" }, { type: "OPEN", inside: 101 })));
    await t.run(async (ctx) => {
      for (let index = 0; index < 101; index++) await guest.create(ctx, { roomId, name: `g${index}` }, { type: "ARRIVE" });
    });
    // Recorded as ignored, the 101st would leave the room closed with a guest who never heard.
    expect(await codeOf(t.run((ctx) => room.send(ctx, roomId, { type: "CLOSE" })))).toBe("LINK_BUDGET");
    expect((await t.run(async (ctx) => (await ctx.db.get("rooms", roomId))!.state)).kind).toBe("open");
    const kinds = await t.run(async (ctx) => (await ctx.db.query("guests").collect()).map((row) => row.state.kind));
    expect(kinds.filter((kind) => kind === "inside")).toHaveLength(101);
  });

  test("a rollback cycle that ends runs to its end, four deep at most, and each hop sees the last one's state", async () => {
    const t = initFixtureTest();
    const id = await created(t.run((ctx) => ping.create(ctx, {}, { type: "CREATE", stopAt: 4 })));
    await t.run((ctx) => ping.send(ctx, id, { type: "KICK" }));
    expect(await t.run(async (ctx) => (await ctx.db.get("pings", id))!.state)).toEqual({ kind: "counting", hits: 4, stopAt: 4 });
    // Each step's row is written as it's saved, before its links run: in order.
    expect((await history(t, "ping", id)).map(({ event }) => event)).toEqual(["CREATE", "KICK", "HIT", "HIT", "HIT", "HIT"]);
  });

  test("an ignore cycle that ends runs to its end, each hop in its own sub-transaction, and the result's `to` is where its links left the row", async () => {
    const t = initFixtureTest();
    const id = await created(t.run((ctx) => ping.create(ctx, {}, { type: "CREATE", stopAt: 4 })));
    // NUDGE stays, and the last TAP stops the row: `to` is `stopped`, not `counting`, where the step went before its links.
    expect(await t.run((ctx) => ping.send(ctx, id, { type: "NUDGE" }))).toEqual({ status: "done", from: "counting", to: "stopped", created: {} });
    expect(await t.run(async (ctx) => (await ctx.db.get("pings", id))!.state)).toEqual({ kind: "stopped", hits: 4 });
    expect((await history(t, "ping", id)).map(({ event, to }) => `${event} ${to}`)).toEqual([
      "CREATE counting",
      "NUDGE counting",
      "TAP counting",
      "TAP counting",
      "TAP counting",
      "TAP stopped",
    ]);
  });

  test("a runaway ignore cycle isn't isolated: LINK_DEPTH fails the step that began it, and every hop rolls back", async () => {
    const t = initFixtureTest();
    for (const stopAt of [5, 1_000]) {
      const id = await created(t.run((ctx) => ping.create(ctx, {}, { type: "CREATE", stopAt })));
      expect(await codeOf(t.run((ctx) => ping.send(ctx, id, { type: "NUDGE" })))).toBe("LINK_DEPTH");
      expect(await t.run(async (ctx) => (await ctx.db.get("pings", id))!.state)).toEqual({ kind: "counting", hits: 0, stopAt });
    }
  });

  test("a runaway rollback cycle throws LINK_DEPTH, and rolls every hop back", async () => {
    const t = initFixtureTest();
    const id = await created(t.run((ctx) => ping.create(ctx, {}, { type: "CREATE", stopAt: 1_000 })));
    expect(await codeOf(t.run((ctx) => ping.send(ctx, id, { type: "KICK" })))).toBe("LINK_DEPTH");
    expect(await t.run(async (ctx) => (await ctx.db.get("pings", id))!.state.hits)).toBe(0);
  });

  test("a rollback fan-out within the budget is delivered; past it, LINK_BUDGET rolls it all back", async () => {
    const t = initFixtureTest();
    const make = (count: number) =>
      t.run(async (ctx) => {
        const ids = [];
        for (let index = 0; index < count; index++) ids.push(await created(ping.create(ctx, {}, { type: "CREATE", stopAt: 1 })));
        return ids;
      });
    const hits = () => t.run(async (ctx) => (await ctx.db.query("pings").collect()).map((row) => row.state.hits));
    const ids = await make(50);
    await t.run((ctx) => ping.send(ctx, ids[0], { type: "KICK_ALL" }));
    expect(await hits()).toEqual(Array(50).fill(1));
    await make(51);
    expect(await codeOf(t.run((ctx) => ping.send(ctx, ids[0], { type: "KICK_ALL" })))).toBe("LINK_BUDGET");
    expect((await hits()).slice(0, 50)).toEqual(Array(50).fill(1));
  });

  test("two sends on one ctx at once throw CONCURRENT_SEND: awaited in turn, both count", async () => {
    const t = initFixtureTest();
    const id = await created(t.run((ctx) => ping.create(ctx, {}, { type: "CREATE", stopAt: 1 })));
    const hits = () => t.run(async (ctx) => (await ctx.db.get("pings", id))!.state.hits);
    const settled = await t.run(async (ctx) =>
      (await Promise.allSettled([ping.send(ctx, id, { type: "KICK" }), ping.send(ctx, id, { type: "KICK" })])).map((item) =>
        item.status === "rejected" ? (item.reason as ConvexError<{ code: string }>).data.code : item.value.status,
      ),
    );
    expect(settled).toEqual(["done", "CONCURRENT_SEND"]);
    expect(await hits()).toBe(1);
    await t.run(async (ctx) => {
      await ping.send(ctx, id, { type: "KICK" });
      await ping.send(ctx, id, { type: "KICK" });
    });
    expect(await hits()).toBe(3);
  });
});

describe("purge and the operator's functions", () => {
  test("refuses a row that isn't in a final state unless forced, then cancels every timer on it, a stale one too, and records it", async () => {
    const t = initFixtureTest();
    const id = await startJob(t);
    // A timer a refactor left behind: no state has it any more.
    const stale = await t.run(async (ctx) => (ctx.scheduler.runAfter(MAX_RUN_MS, makeFunctionReference<"mutation">("fixtures/machines.fixture:deliver"), { machine: "job", id, event: "RENAMED", dueAt: 1 })));
    await t.run(async (ctx) => {
      const row = (await ctx.db.get("jobs", id))!;
      await ctx.db.patch("jobs", id, { stateTimers: [...row.stateTimers, { event: "RENAMED", dueAt: 1, job: stale }] });
    });
    expect(await timers(t, "job", id)).toHaveLength(3);
    expect(await pendingJobs(t)).toHaveLength(3);
    expect(await codeOf(t.run((ctx) => job.purge(ctx as never, id)))).toBe("INTERNAL_ONLY");
    expect(await codeOf(t.run(async (ctx) => job.purge(await internal(ctx), id)))).toBe("NOT_FINAL");
    await t.run(async (ctx) => job.purge(await internal(ctx), id, { force: true }));
    expect(await t.run((ctx) => ctx.db.get("jobs", id))).toBeNull();
    expect(await pendingJobs(t)).toEqual([]);
    expect((await history(t, "job", id)).at(-1)).toMatchObject({ kind: "purged", event: "", from: "running", to: "", by: "server", reasons: ["forced"] });
    await advance(t, MAX_RUN_MS + 1_000);
    expect(await history(t, "job", id)).toHaveLength(3);
  });

  test("pruning history is bounded, oldest first, and keeps what's newer", async () => {
    const t = initFixtureTest();
    const fact = { machine: "job", subject: "j", kind: "step" as const, event: "E", from: "a", to: "b", by: "server", reasons: [] };
    const write = (count: number) => t.run((ctx) => ctx.runMutation(components.stateMachines.lib.record, { facts: Array.from({ length: count }, () => fact) }));
    await write(601);
    vi.advanceTimersByTime(1_000);
    const before = Date.now();
    await write(5);
    const prune = () => t.run(async (ctx) => machines.pruneHistory(await internal(ctx), { before }));
    expect(await prune()).toEqual({ deleted: 500, more: true });
    expect(await prune()).toEqual({ deleted: 101, more: false });
    expect(await history(t, "job", "j")).toHaveLength(5);
  });

  test("the delivery mutation and the operator's functions need the internal brand, like purge", async () => {
    const t = initFixtureTest();
    const [id] = await makeTesters(t, 1);
    // A type error without the casts (types.check.ts), and INTERNAL_ONLY with them.
    const calls: ((ctx: Ctx) => Promise<unknown>)[] = [
      (ctx: Ctx) => machines.deliver(ctx as never, { machine: "tester", id, event: "DUE", dueAt: Date.now() + 60_000 }),
      (ctx: Ctx) => machines.rearmTimer(ctx as never, { machine: "tester", id, event: "DUE" }),
      (ctx: Ctx) => machines.failedTimers(ctx as never, {}),
      (ctx: Ctx) => machines.pruneHistory(ctx as never, { before: Date.now() }),
    ];
    for (const call of calls) expect(await codeOf(t.run((ctx) => call(ctx)))).toBe("INTERNAL_ONLY");
    expect(await codeOf(t.run(async (ctx) => machines.deliver(await internal(ctx), { machine: "nope", id, event: "DUE" })))).toContain(`No machine "nope" in the catalog.`);
  });
});

describe("the checks at definition and in the catalog", () => {
  const rest = [color, job, poll, room, guest, ping, kit, part, tester];

  test("every state field has exactly one machine, history and timers have their places, and a machine joins one catalog", () => {
    expect(thrown(() => defineMachines(schema, rest, builders))).toContain("lamps.powerState holds a state union, but no machine in the catalog is on it.");
    const rival = defineMachine(
      schema,
      {
        name: "rival",
        table: "lamps",
        field: "powerState",
        callers: { anyone: "" },
        events: { anyone: { INSTALL: {} } },
        states: { start: { on: { INSTALL: { to: "off" } } }, off: {}, on: {} },
      },
      { callers: { anyone: () => true } },
    );
    expect(thrown(() => defineMachines(schema, [power, rival, ...rest], builders))).toContain("lamps.powerState belongs to power and rival: a state field has one machine.");
    // A machine that keeps history needs the component, and one with timers its timer field.
    expect(thrown(() => defineMachines(schema, [power, ...rest], builders))).toContain("power keeps history, so install the stateMachines component and pass `component`");
    const untimed = defineSchema({ things: defineTable({ state: v.union(v.object({ kind: v.literal("here") }), v.object({ kind: v.literal("gone") })) }) });
    const expiring = { start: { on: { MAKE: { to: "here" } } }, here: { timers: { EXPIRE: { after: 1_000 } }, on: { EXPIRE: { to: "gone" } } }, gone: {} };
    expect(
      thrown(() => defineMachine(untimed, { name: "thing", table: "things", callers: { anyone: "" }, events: { anyone: { MAKE: {} } }, states: expiring } as never, { callers: { anyone: () => true } } as never)),
    ).toContain("it has timers, so things needs `stateTimers: machineTimers` beside state.");
    // The fixtures' catalog has them all already.
    expect(thrown(() => defineMachines(schema, [power, ...rest], builders))).toContain("power is already in a catalog");
  });

  test("machines on one row take the same start events from the same senders, however many transitions each has", () => {
    const colorStates = { white: {}, warm: {}, colored: {} };
    // Color born by the server's INSTALL, power by anyone's: a public create would throw halfway through the birth.
    const serverColor = defineMachine(schema, { name: "light", table: "lamps", field: "colorState", events: { server: { INSTALL: {} } }, states: { start: { on: { INSTALL: { to: "white" } } }, ...colorStates } }, {});
    expect(thrown(() => defineMachines(schema, [power, serverColor], builders))).toContain(
      "light and power share lamps, so their starts take the same events, from the same senders.",
    );
    // A guarded list is still one start event.
    const listColor = defineMachine(
      schema,
      {
        name: "light",
        table: "lamps",
        field: "colorState",
        callers: { anyone: "" },
        guards: { warmFirst: "It starts white." },
        events: { anyone: { INSTALL: {} } },
        states: { start: { on: { INSTALL: [{ to: "warm", guard: "warmFirst" }, { to: "white" }] } }, ...colorStates },
      },
      { callers: { anyone: () => true }, guards: { warmFirst: () => false } },
    );
    expect(thrown(() => defineMachines(schema, [power, listColor], builders))).not.toContain("share lamps");
  });

  test("names are plain and not reserved, and a role can't share a machine's name", () => {
    const named = (name: string, role: string, event: string) =>
      thrown(() =>
        defineMachine(
          tiny,
          { name, table: "things", callers: { [role]: "" }, events: { [role]: { [event]: {} } }, states: { start: { on: { [event]: { to: "here" } } }, here: {}, gone: {} } } as never,
          { callers: { [role]: () => true } } as never,
        ),
      );
    expect(named("server", "anyone", "MAKE")).toContain('"server" is reserved');
    expect(named("thing", "timer", "MAKE")).toContain('"timer" is reserved');
    expect(named("thing", "anyone", "start")).toContain('"start" is reserved');
    expect(named("thing", "anyone", "make-it")).toContain(`"make-it" isn't a plain name`);
    expect(named("my thing", "anyone", "MAKE")).toContain(`"my thing" isn't a plain name`);
    const things = defineSchema({ ...schema.tables, things: defineTable({ state: v.union(v.object({ kind: v.literal("here") })) }) });
    const thing = defineMachine(
      things,
      { name: "thing", table: "things", callers: { guest: "" }, events: { guest: { MAKE: {} } }, states: { start: { on: { MAKE: { to: "here" } } }, here: {} } },
      { callers: { guest: () => true } },
    );
    expect(thrown(() => defineMachines(things, [power, ...rest, thing], builders))).toContain(`thing's role "guest" is also a machine's name.`);
  });

  test("a payload field named `type`, a payload on a machine's event, two members with one kind, and an unguarded item before the end of a list are refused", () => {
    const states = { start: { on: { MAKE: { to: "here" } } }, here: { on: { DROP: { to: "gone" } } }, gone: {} };
    expect(defineThing({ events: { anyone: { MAKE: {}, DROP: { type: v.string() } } }, states })).toContain(
      `DROP's payload has a field named "type", which is the event's own: rename it.`,
    );
    // A link carries its event and `from`: the receiver reads the sender's row for the rest.
    expect(defineThing({ events: { anyone: { MAKE: {} }, other: { DROP: { why: v.string() } } }, states })).toContain(
      "DROP comes from the other machine: no payload, read its row by `from.id`.",
    );
    const twice = defineSchema({ things: defineTable({ state: v.union(v.object({ kind: v.literal("here") }), v.object({ kind: v.literal("here"), extra: v.number() })) }) });
    expect(
      thrown(() =>
        defineMachine(twice, { name: "thing", table: "things", callers: { anyone: "" }, events: { anyone: { MAKE: {} } }, states: { start: { on: { MAKE: { to: "here" } } }, here: {} } } as never, {
          callers: { anyone: () => true },
        } as never),
      ),
    ).toContain(`Two members of things.state's union have kind "here": each state has one.`);
    const list = { start: { on: { MAKE: { to: "here" } } }, here: { on: { DROP: [{ to: "gone" }, { to: "gone", guard: "ok" }] } }, gone: {} };
    expect(defineThing({ events: { anyone: { MAKE: {}, DROP: {} } }, guards: { ok: "" }, states: list }, { callers: { anyone: () => true }, guards: { ok: () => true } })).toContain(
      `"here" on DROP: item 1 has no guard, so the rest never run.`,
    );
  });

  test("`on: {}` and an empty list are refused, a start's too: the state would be a dead end that isn't final", () => {
    expect(defineThing({ states: { start: { on: { MAKE: { to: "here" } } }, here: { on: {} }, gone: {} } })).toContain(
      `"here" has \`on: {}\`: a final state, which takes no events, is written \`{}\`.`,
    );
    const events = { events: { anyone: { MAKE: {}, DROP: {} } } };
    expect(defineThing({ ...events, states: { start: { on: { MAKE: { to: "here" } } }, here: { on: { DROP: [] } }, gone: {} } })).toContain(`"here" on DROP is an empty list`);
    expect(defineThing({ states: { start: { on: { MAKE: [] } }, here: {}, gone: {} } })).toContain(`"start" on MAKE is an empty list`);
  });

  test("each link says what a refusal does, and a timer's transitions send with ignore", () => {
    const events = { events: { anyone: { MAKE: {} }, thing: { PING: {} } } };
    const code = { callers: { anyone: () => true }, links: { "thing.PING": () => [] } };
    const sending = (on: object) => ({
      states: { start: { on: { MAKE: { to: "here" } } }, here: { timers: { LATE: { after: 1_000 } }, on: { PING: { to: "gone" }, ...on } }, gone: {} },
      ...events,
    });
    expect(defineThing(sending({ LATE: { to: "gone", sends: [{ machine: "thing", event: "PING" }] } }), code)).toContain(
      `"here" on LATE sends PING to thing: say \`onRefused: "rollback"\` or \`"ignore"\`.`,
    );
    expect(defineThing(sending({ LATE: { to: "gone", sends: [{ machine: "thing", event: "PING", onRefused: "rollback" }] } }), code)).toContain(
      `"here" on LATE is a timer's: its link sends with \`onRefused: "ignore"\``,
    );
  });

  test("an `at` timer must name a required number field: an optional one is refused", () => {
    const loose = defineSchema({
      tasks: defineTable({ state: v.union(v.object({ kind: v.literal("waiting"), retryAt: v.optional(v.number()) }), v.object({ kind: v.literal("done") })), stateTimers: machineTimers }),
    });
    const rules = {
      name: "task",
      table: "tasks",
      callers: { anyone: "" },
      events: { anyone: { MAKE: {} } },
      states: { start: { on: { MAKE: { to: "waiting" } } }, waiting: { timers: { DUE: { at: "retryAt" } }, on: { DUE: { to: "done" } } }, done: {} },
    };
    expect(thrown(() => defineMachine(loose, rules as never, { callers: { anyone: () => true } } as never))).toContain(
      `"waiting"'s timer DUE is at "retryAt", not a required number in its data.`,
    );
  });
});

describe("diagrams", () => {
  test("a state diagram draws how a row is born, who sends each event with its payload's fields, each link with its policy, and a list in its order", () => {
    expect(stateDiagram(room.manifest)).toContain("open --> closed : CLOSE (anyone) / close, sends ROOM_CLOSED to guest (ignore)");
    expect(stateDiagram(room.manifest)).toContain("open --> open : GUEST_LEFT from guest / countOut");
    const jobs = stateDiagram(job.manifest);
    expect(jobs).toContain("[*] --> waiting : SUBMIT(retryAt?) (owner) [1. later] / wait");
    expect(jobs).toContain("[*] --> queued : SUBMIT(retryAt?) (owner) [else]");
    expect(jobs).toContain("running --> waiting : STALLED at deadline [1. retriesLeft] / backOff");
    expect(jobs).toContain("running --> failed : STALLED at deadline [else] / giveUp");
    expect(jobs).toContain("running --> running : HEARTBEAT(note) (server) / beat");
    // A fragment spread into two states is two edges: the diagram draws what runs.
    expect(jobs).toContain("queued --> failed : CANCEL (owner) / cancel");
    expect(jobs).toContain("waiting --> failed : CANCEL (owner) / cancel");
    // An effect may create several rows, and a stay-put timer fires again.
    expect(stateDiagram(kit.manifest)).toContain("open --> built : BUILD(count, retry) (anyone) / build, creates 1+ part by MADE");
    expect(stateDiagram(poll.manifest)).toContain("watching --> watching : TICK after 1 second [more] / tick");
  });

  test("optional state data draws with `?`, and machines on one row are drawn born together", () => {
    expect(stateDiagram(room.manifest)).toContain("open : inside, lastLeft?");
    expect(stateDiagram(power.manifest, machines.manifests)).toContain("[*] --> off : INSTALL (anyone), born with color");
    expect(stateDiagram(color.manifest, machines.manifests)).toContain("[*] --> white : INSTALL (anyone), born with power");
  });

  test("the linked diagram is an overview: every machine as a box, with its links and creates", () => {
    expect(linkedDiagram([room.manifest, guest.manifest, kit.manifest, part.manifest]).split("\n")).toEqual([
      "flowchart LR",
      `  room["room<br/>rooms.state"]`,
      `  guest["guest<br/>guests.state"]`,
      `  kit["kit<br/>kits.state"]`,
      `  part["part<br/>parts.state"]`,
      `  room -.->|"ROOM_CLOSED (ignore)"| guest`,
      `  guest -.->|"GUEST_LEFT (ignore)"| room`,
      `  kit -->|"creates 1+ by MADE"| part`,
      `  kit -.->|"MADE (rollback)"| part`,
    ]);
  });

  test("durations read as people say them", () => {
    expect([20_000, 1_209_600_000, 90_000, 3_600_000, 1_500].map(duration)).toEqual(["20 seconds", "14 days", "90 seconds", "1 hour", "1500 ms"]);
  });
});
