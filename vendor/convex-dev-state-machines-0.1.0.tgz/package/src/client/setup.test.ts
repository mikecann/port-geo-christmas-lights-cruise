/// <reference types="vite/client" />
import { convexTest } from "convex-test";
import { componentsGeneric, type GenericDataModel, type GenericQueryCtx } from "convex/server";
import { test } from "vitest";
import type { ComponentApi } from "../component/_generated/component.js";
import { historyOf as readHistory, register } from "../test.js";
import schema from "./fixtures/schema.fixture.js";

// The library's tests run on the fixtures' schema and machines (./fixtures),
// with the component registered as an app would have it.
export const modules = import.meta.glob("./**/*.*s");
export const components = componentsGeneric() as unknown as { stateMachines: ComponentApi };

export function initFixtureTest() {
  const t = convexTest(schema, modules);
  register(t);
  return t;
}

/** A row's history, oldest first. */
export const historyOf = (t: { run<R>(fn: (ctx: { runQuery: GenericQueryCtx<GenericDataModel>["runQuery"] }) => Promise<R>): Promise<R> }, machine: string, subject: string) =>
  readHistory(t, components.stateMachines, machine, subject);

export { advance, asInternal, throughInternal } from "../test.js";

test("setup", () => {});
